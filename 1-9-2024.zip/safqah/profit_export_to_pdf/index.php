<?php
require_once('tcpdf/tcpdf.php');
// Include the TCPDF library

// Database connection information
$servername = "89.117.188.103";
$username = "u266894635_safqah";
$password = "0;[iSbCI=Bx";
$dbname = "u266894635_safqah";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Include Bootstrap CSS via CD
// Fetch data from the database
$query = "SELECT * FROM profit";

$result = $conn->query($query);

// Create a new PDF document
$pdf = new TCPDF();

$pdf->SetAutoPageBreak(true, PDF_MARGIN_BOTTOM);

// Add a page to the PDF
$pdf->AddPage();

$pdf->writeHTML('<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />', true, false, true, false, '');

// Set font
$pdf->SetFont('helvetica', '', 12);

// Add a heading
$pdf->Cell(0, 10, 'Profit Percentage', 0, 1, 'C');

// Add a table with borders to the PDF
$html = '<table cellpadding="5" cellspacing="0" border="1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Invoice Number</th>
                    <th>Customer Name</th>
                    <th>Product Name</th>
                    <th>SKU</th>
                    <th>Product Qty</th>
                    <th>Product Cost</th>
                    <th>Selling Price</th>
                    <th>Profit</th>
                    <th>Total Price</th>
                </tr>
            </thead>
            <tbody>';

// Set the line style for table borders
$pdf->SetLineStyle(array('width' => 0.3, 'color' => array(0, 0, 0)));

while ($row = $result->fetch_assoc()) {
    $html .= '<tr>
                <td>' . $row['id'] . '</td>
                <td>' . $row['invoice_number'] . '</td>
                <td>' . $row['customer_name'] . '</td>
                <td>' . $row['product_name'] . '</td>
                <td>' . $row['sku'] . '</td>
                <td>' . $row['product_qty'] . '</td>
                <td>' . $row['product_cost'] . '</td>
                <td>' . $row['selling_price'] . '</td>
                <td>' . $row['profit'] . '</td>
                <td>' . $row['total_price'] . '</td>
            </tr>';
}

$html .= '</tbody></table>';

$pdf->writeHTML($html, true, false, true, false, '');


$name=rand();


// Output PDF to the browser or save to a file
$pdf->Output('profit_report_'.$name.'.pdf', 'D');

// Close the database connection
$conn->close();
