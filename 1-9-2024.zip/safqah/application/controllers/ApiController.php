<?php
defined('BASEPATH') OR exit('No direct script access allowed');



class ApiController extends CI_Controller
{

    public function __construct() {
		/*call CodeIgniter's default Constructor*/
		parent::__construct();

		/*load model*/
		$this->load->model('Sales_model');
        $this->load->model('Category_model');
        $this->load->model('Customer_model');
        $this->load->model('Supplier_model');
        $this->load->model('Vehicle_model');
        $this->load->model('Stocktransfer_model');
	}

    public function index()
    {


        $book=["Status"];

        $this->output->set_content_type('application/json')->set_output(json_encode($book));

    }

    public function generate_invoice($id){

        $invoice_number=$id;

        $data['invoice_number']=$invoice_number;

        $sales = $this->db->query("SELECT * FROM `sales` WHERE `invoice_no`='$invoice_number'");

        $data['sales'] = $sales->result();

        $data['sales2'] = $sales->result();

        $this->load->view("invoice/invoice",$data);

    }



    public function generate_sales_return_invoice($id){

        $invoice_number=$id;

        $data['invoice_number']=$invoice_number;

        $sales = $this->db->query("SELECT * FROM `sales_return` WHERE `invoice_no`='$invoice_number'");

        $data['sales'] = $sales->result();

        $data['sales2'] = $sales->result();

        $this->load->view("invoice/s_invoice",$data);

    }

}