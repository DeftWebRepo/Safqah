<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {


	public function index()
	{
		

		$this->load->view('parts/header');
		//$this->load->view('parts/nav');
		//$this->load->view('parts/aside');
		$this->load->view('login');
		$this->load->view('parts/footer');
	}


}
