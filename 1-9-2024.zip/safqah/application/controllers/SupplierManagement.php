<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SupplierManagement extends CI_Controller {

	public function __construct() {
		/*call CodeIgniter's default Constructor*/
		parent::__construct();

		/*load model*/
		$this->load->model('Stock_model');
        $this->load->model('Category_model');
        $this->load->model('Supplier_model');
        $this->load->model('SupplierProduct_model');
		$this->load->model('Sales_model');
	}

	public function index()
	{
		$data['categories'] = $this->Category_model->getCategories();
		
		$data['suppliers'] = $this->Supplier_model->getSuppliers();

	}
	public function add()
	{
		$data['sales_count'] = $this->Sales_model->getSalesCount();
		$data['categories'] = $this->Category_model->getCategories();
		
		$data['suppliers'] = $this->Supplier_model->getSuppliers();
		
		$this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
        $this->load->view('AddSupplierManagement',$data);
        $this->load->view('parts/footer');
	}

public function save()
	{
		
		//var_dump($_POST);

		 $supplier_name=$this->input->post('supplier_name');
		 $company_name=$this->input->post('company_name');
		 $address=$this->input->post('address');
		 $phone_number=$this->input->post('phone_number');

		 $data = [
			'supplier_name'=> $supplier_name,
			'company_name'=> $company_name,
			'address'=> $address,
			'phone_number'=> $phone_number
		];

		$result = $this->Supplier_model->save($data);

		if($result) {
			$this->session->set_flashdata('hello', 'Data Saved !');
			redirect('supplier-management/add');
		} 
		else
		{
			echo "Wrong Entry";
		}


	}
public function view()
{
	$data['suppliers']=$this->Supplier_model->getSuppliers();

	$data['sales_count'] = $this->Sales_model->getSalesCount();
	$this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
        $this->load->view('ViewSupplierManagement',$data);
        $this->load->view('parts/footer');
}

public function edit($s_id)
{


	$data['supplierdetail']=$this->Supplier_model->editSuppliers($s_id);
    $data['sales_count'] = $this->Sales_model->getSalesCount();

	if ($data['supplierdetail']){

		$this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
        $this->load->view('EditSupplierManagement',$data);
        $this->load->view('parts/footer');
	}
	else {
		$this->session->set_flashdata('error', 'Item not found.');
            redirect('supplier-management/view');
	}

} 

public function update($s_id) {
    
		 $supplier_name=$this->input->post('supplier_name');
		 $company_name=$this->input->post('company_name');
		 $address=$this->input->post('address');
		 $phone_number=$this->input->post('phone_number');
   
       $updatedData = [
           'supplier_name'=> $supplier_name,
			'company_name'=> $company_name,
			'address'=> $address,
			'phone_number'=> $phone_number


       ];

    
        // Update the item in the database
        $this->Supplier_model->update($s_id, $updatedData);
    
        // Set a success message
        $this->session->set_flashdata('success', 'Supplier updated successfully.');
    
        // Redirect to the stock listing page
        redirect('supplier-management/view');
    }

    public function delete($s_id) {
    	$item = $this->Supplier_model->getSuppliers($s_id);
        if ($item) {
            // Item exists, proceed with deletion
            $this->Supplier_model->delete($s_id);
            $this->session->set_flashdata('Success', 'Item deleted successfully.');
        } else {
            // Item does not exist
            $this->session->set_flashdata('Error', 'Item not found.');
        }
    
        // Redirect to the stock listing page
        redirect('supplier-management/view');
    }

     public function saveproducts()
	{
		
		// var_dump($_POST);

		 $product_name=$this->input->post('product_name');
		 $product_code=$this->input->post('product_code');
		 $product_category=$this->input->post('product_category');
         $product_price=$this->input->post('product_price');
        
         $product_sku=$this->input->post('product_sku');
    
    
         $supplier_name=$this->input->post('supplier_name');


		 $data = [
			'product_name'=> $product_name,
			'product_code'=> $product_code,
		
			'product_category'=> $product_category,
            'product_price'=> $product_price,
            'product_sku'=> $product_sku,

            'supplier_name'=> $supplier_name,
        

		];

		$result = $this->Supplier_model->saveproducts($data);

		if($result) {
			redirect("SupplierManagement/add");
			
		} else {
			echo "Something went wrong";
			exit();
		}


	}
}
