<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class VehicletoWarehouse extends CI_Controller {

	public function __construct() {
		/*call CodeIgniter's default Constructor*/
		parent::__construct();

		/*load model*/
		$this->load->model('Sales_model');
        $this->load->model('Category_model');
        $this->load->model('Customer_model');
        $this->load->model('Supplier_model');
        $this->load->model('Vehicle_model');
        $this->load->model('Stocktransfer_model');
        $this->load->model('Stock_model');
	}

    public function vehicletowarehouse()
	{
		
        $data['categories'] = $this->Category_model->getCategories();
        $data['suppliers'] = $this->Supplier_model->getSuppliers();
        $data['vehicles'] = $this->Vehicle_model->getVehicleData();
        $data['sales_count'] = $this->Sales_model->getSalesCount();

		$this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside', $data);
        $this->load->view('vehicletowarehouse', $data);
        $this->load->view('parts/footer');

	}

    public function getcategorystocksss(){
        $category = $this->input->post('category');
        $vehicle = $this->input->post('vehicle_number');
        $result = $this->Stocktransfer_model->getstockssss($category,$vehicle);
        echo json_encode($result);


    }

    public function getProductdetails(){
        
        $selectedValue = $this->input->post('selectedValue');
        $result = $this->Stocktransfer_model->getStockItems($selectedValue);
        echo json_encode($result);
    }

    public function getsave(){

        $vehicle_number=$this->input->post('vehicle_number');
        $product_category=$this->input->post('product_category');
        $product_name =$this->Stocktransfer_model->getproductnamess($this->input->post('product_name'));
        $model_number = $this->input->post('model_number');
        $cost_price = $this->input->post('cost_price');
        $selling_price = $this->input->post('selling_price');
        $quantity = $this->input->post('quantity');
        $total_price = $this->input->post('total_price');
        $transferred_on = $this->input->post('transferred_on');

        $data = [
            'vehicle_number' => $vehicle_number,
            'product_category' => $product_category,
            'product_name' => $product_name,
            'model_number' => $model_number,
            'cost_price' => $cost_price,
            'transferred_on' => $transferred_on,
            'total_price' => $total_price,
            'selling_price' => $selling_price,
            'quantity' => $quantity,
        ];
        
        $vvstock_qty = $this->Stocktransfer_model->getstocksqtyssss($model_number,$vehicle_number);
        

        $v2shop_price =$this->Stocktransfer_model->get_vehicle_pricess($model_number,$vehicle_number);


        $vvshop_price = $v2shop_price - $total_price;
        

        $qty_news=$vvstock_qty - $quantity;

        if ($qty_news < 0){

            $this->session->set_flashdata('error', ' Not enough Quantity in Stock ');
            redirect("VehicletoWarehouse/vehicletowarehouse");
            exit();

        }

        if($qty_news == 0 ){
            $status="Out of stock";
        }
        else{
            $status="In Stock";
        }

        $updatedata = [
            'quantity'=>$qty_news,
            'stock_status'=>$status,
            'total_price'=>$vvshop_price

        ];

        $stocks_qty = $this->Stocktransfer_model->getstockstyu($model_number);

         $qty_stock = $stocks_qty + $quantity;

        $updatedata_to = [
            'item_quantity'=>$qty_stock,
        ];
        
            $this->Stocktransfer_model->updateStockQtysssss($model_number,$vehicle_number,$updatedata);

            $this->Stocktransfer_model->updateStockdetqty($model_number,$updatedata_to);




            $result = $this->db->insert('vehicletowarehouse',$data);
        if($result) {


            $this->session->set_flashdata('success', 'Data Saved !');
             redirect("VehicletoWarehouse/vehicletowarehouse");
 
             
         } else {
             echo "Something went wrong";
             exit();
         }
 
 
    }

    public function view() {

        $data['vehi'] = $this->Stocktransfer_model->getvehicleData();
        $data['sales_count'] = $this->Sales_model->getSalesCount();

        $this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
        $this->load->view('viewvehicletowarehouse', $data);
        $this->load->view('parts/footer');
    }

    public function getdelete($id) {
        // Load the stock model
        $this->load->model('Stocktransfer_model');
    
        // Check if the item with the given $pid exists
        $item = $this->Stocktransfer_model->getSalesItemss($id);
        if ($item) {
            // Item exists, proceed with deletion
            $this->Stocktransfer_model->deleteSalesItemsss($id);
            $this->session->set_flashdata('success', 'Item deleted successfully.');
        } else {
            // Item does not exist
            $this->session->set_flashdata('error', 'Item not found.');
        }
    
        // Redirect to the stock listing page
        redirect('VehicletoWarehouse/view');
    }


    public function vehicletoshop(){

        $data['categories'] = $this->Category_model->getCategories();
        $data['suppliers'] = $this->Supplier_model->getSuppliers();
        $data['vehicles'] = $this->Vehicle_model->getVehicleData();
        $data['sales_count'] = $this->Sales_model->getSalesCount();

		$this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside', $data);
        $this->load->view('vehicletoshop', $data);
        $this->load->view('parts/footer');

    }


    public function getshopsave(){

        $vehicle_number=$this->input->post('vehicle_number');
        $product_category=$this->input->post('product_category');
        $product_name =$this->Stocktransfer_model->getproductnamesss($this->input->post('product_name'));
        $model_number = $this->input->post('model_number');
        $cost_price = $this->input->post('cost_price');
        $selling_price = $this->input->post('selling_price');
        $quantity = $this->input->post('quantity');
        $total_price = $this->input->post('total_price');
        $transferred_on = $this->input->post('transferred_on');
        $shop ="shop";

        $data = [
            'vehicle_number' => $vehicle_number,
            'product_category' => $product_category,
            'product_name' => $product_name,
            'model_number' => $model_number,
            'cost_price' => $cost_price,
            'transferred_on' => $transferred_on,
            'total_price' => $total_price,
            'selling_price' => $selling_price,
            'quantity' => $quantity,
        ];
        
        $vvstock_qty = $this->Stocktransfer_model->getstocksqtyssssss($model_number,$vehicle_number);
        

        $v2shop_price =$this->Stocktransfer_model->get_vehicle_pricessss($model_number,$vehicle_number);


        $vvshop_price = $v2shop_price - $total_price;
        

        $qty_news=$vvstock_qty - $quantity;

        if ($qty_news < 0){

            $this->session->set_flashdata('error', ' Not enough Quantity in Stock ');
            redirect("VehicletoWarehouse/vehicletoshop");
            exit();

        }

        if($qty_news == 0 ){
            $status="Out of stock";
        }
        else{
            $status="In Stock";
        }

        $updatedata = [
            'quantity'=>$qty_news,
            'stock_status'=>$status,
            'total_price'=>$vvshop_price

        ];

        $this->Stocktransfer_model->updateStocktysssss($model_number,$vehicle_number,$updatedata);
         
        $stocks_qty = $this->Stocktransfer_model->getstockstyust($model_number);

        $toprice = $this->Stocktransfer_model->getstockstyusts($model_number);

        $skus = $this->Stocktransfer_model->get_sku($model_number);

        if($skus){
            
            $qty_stock = $stocks_qty + $quantity;

            $priceto = $toprice + $total_price;


            $updatedata_to = [
                'quantity'=>$qty_stock,
                'total_price'=>$priceto,
            ];

            $this->Stocktransfer_model->updateStockdetqtysss($model_number,$updatedata_to);


        }
        else{
        
    
            $status="In Stock";
    
            $datasas = [
		
                'product_category'=> $product_category,
                'product_name'=> $product_name,
                'model_number'=> $model_number,
                'cost_price'=> $cost_price,
                'selling_price'=> $selling_price,
                'stock_status'=>$status,
                'quantity'=> $quantity,
                'total_price'=> $total_price,
                'transferred_on'=> $transferred_on,
                'type'=> $shop,
    
            ];

            $this->db->insert('warehousetoshop',$datasas);

        }

        

            $result = $this->db->insert('vehicletoshop',$data);
        if($result) {


            $this->session->set_flashdata('success', 'Data Saved !');
             redirect("VehicletoWarehouse/vehicletoshop");
 
             
         } else {
             echo "Something went wrong";
             exit();
         } 
    }


    public function viewvehicletoshop() {

        $data['vehi'] = $this->Stocktransfer_model->getvehicleDatasss();
        $data['sales_count'] = $this->Sales_model->getSalesCount();

        $this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
        $this->load->view('viewvehicletoshop', $data);
        $this->load->view('parts/footer');
    }

    
    public function getshopdelete($id) {
        // Load the stock model
        $this->load->model('Stocktransfer_model');
    
        // Check if the item with the given $pid exists
        $item = $this->Stocktransfer_model->getSalesItemssss($id);
        if ($item) {
            // Item exists, proceed with deletion
            $this->Stocktransfer_model->deleteSalesItemssss($id);
            $this->session->set_flashdata('success', 'Item deleted successfully.');
        } else {
            // Item does not exist
            $this->session->set_flashdata('error', 'Item not found.');
        }
    
        // Redirect to the stock listing page
        redirect('VehicletoWarehouse/viewvehicletoshop');
    }
    
}