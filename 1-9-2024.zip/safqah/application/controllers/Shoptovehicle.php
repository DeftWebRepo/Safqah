<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Shoptovehicle extends CI_Controller {

	public function __construct() {
		/*call CodeIgniter's default Constructor*/
		parent::__construct();

		/*load model*/
		$this->load->model('Shoptovehicle_model');
        $this->load->model('Sales_model');
         $this->load->model('Category_model');
         $this->load->model('Vehicle_model');
         $this->load->model('Stocktransfer_model');
	}

    public function index()
	{
		
	
		

	}
	public function add()
	{    
         $data['vehicles'] = $this->Vehicle_model->getVehicleData();
        $data['categories'] = $this->Category_model->getCategories();
		$data['sales_count'] = $this->Sales_model->getSalesCount();
         $data['stock'] = $this->Stocktransfer_model->getWarehouseData();
		$this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
		$this->load->view('shoptovehicle');
        $this->load->view('parts/footer');
	}

    public function save()
	{
        $quantity = $this->input->post("quantity");
        $product_name=$this->Shoptovehicle_model->getstockhouseItem($this->input->post("product_name"));
        $model_number=$this->input->post("model_number");
        $cost_price=$this->input->post("cost_price");
        $selling_price=$this->input->post("selling_price");
        $total_price=$this->input->post("total_price");
        $transferred_on=$this->input->post("transferred_on");
        $product_category=$this->input->post("product_category");
        $vehicle_name=$this->input->post("vehicle_name");




		if($quantity == 0 ){
            $status="Out of stock";
        }
        else{
            $status="In Stock";
        }

        $data=[
            'stock_status'=>$status,
            'quantity'=>$quantity,
            'total_price'=>$total_price,
            'transferred_on'=>$transferred_on,
            'cost_price'=>$cost_price,
            'selling_price'=>$selling_price,
            'model_number'=>$model_number,
            'product_name'=>$product_name,
            'vehicle_name'=>$vehicle_name,
            'product_category'=>$product_category,
        ];


        $vstock_qty = $this->Shoptovehicle_model->getstocksqty($model_number);
        
        $price = $this->Shoptovehicle_model->getstocksqtysit($model_number);

        $prices = $price - $total_price;

        $qty_new = $vstock_qty - $quantity;

        if ($qty_new < 0){

			$this->session->set_flashdata('error', ' Not enough Quantity in Stock ');
			redirect("Shoptovehicle/add");
			exit();

		}

		if($qty_new == 0 ){
			$statuss="Out of stock";
		}
		else{
			$statuss="In Stock";
		}


        $updatedata = [
			'quantity'=>$qty_new,
			'stock_status'=>$statuss,
            'total_price'=>$prices,

		];

        $stock_qty = $this->Shoptovehicle_model->updateStockQty($model_number,$updatedata);




        $condition = array(
            'model_number' => $model_number,
            'vehicle_name' => $vehicle_name,
        );
        
        // Check if the record already exists in the 'stock_to_vehicle' table
        $hai = $this->db->get_where('stock_to_vehicle', $condition);
        
        if ($hai->num_rows() > 0) {
            // If the record exists, update quantity and total price
            $get_vehicle_to_qty = $this->Vehicle_model->get_vehicle_to_qty($model_number, $vehicle_name);
            $get_vehicle_to_price = $this->Vehicle_model->get_vehicle_to_price($model_number, $vehicle_name);
            $get_selling_price = $this->Vehicle_model->get_selling_price($model_number,$vehicle_name);
            $get_cost_price = $this->Vehicle_model->get_cost_price($model_number,$vehicle_name);
        
                    
        
                   if ($get_selling_price != $selling_price){
                         $to_qty_new = $get_vehicle_to_qty + $quantity;
                          $sells =  $selling_price * $quantity;
                          $to_margin =  $sells + $total_price;
                          $to_supdatedata = [
                            'quantity' => $to_qty_new,
                            'total_price' => $to_margin,
                            'cost_price'=>$cost_price,
                            'selling_price'=>$selling_price,
                        ];
                    }
                    else{
                      $to_qty_new = $get_vehicle_to_qty + $quantity;
                      $to_margin = $get_vehicle_to_price + $total_price;
                      $to_supdatedata = [
                        'quantity' => $to_qty_new,
                        'total_price' => $to_margin,
                       
                    ];
                   }
        
            
        
            // Update the existing record in the 'stock_to_vehicle' table
            $stock_qtys = $this->Vehicle_model->to_updateStockQty($model_number, $vehicle_name, $to_supdatedata);
        } else {
            // If the record does not exist, insert a new record
            $to_updatedata = [
                'stock_status'=>$status,
            'quantity'=>$quantity,
            'total_price'=>$total_price,
            'transferred_on'=>$transferred_on,
            'cost_price'=>$cost_price,
            'selling_price'=>$selling_price,
            'model_number'=>$model_number,
            'product_name'=>$product_name,
            'vehicle_name'=>$vehicle_name,
            'product_category'=>$product_category,
            ];
        
            // Insert a new record in the 'stock_to_vehicle' table
            $this->db->insert('stock_to_vehicle', $to_updatedata);
        }

        


       

        //$stock_qtys = $this->Vehicle_model->to_updateStockQty($product_data['model_number'],$product_data['vehicle_from_to'],$to_supdatedata);

        $this->session->set_flashdata('success', 'Data Saved !');

        redirect('Shoptovehicle/add','refresh');

    }
	

    public function view() {

        $query = $this->db->query("SELECT * FROM `stock_to_vehicle`");
        $data['warehouse'] = $query->result();
        $data['sales_count'] = $this->Sales_model->getSalesCount();
        $this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
        $this->load->view('viewshoptovehicle', $data);
        $this->load->view('parts/footer');

    }

	/*public function edit($id) {
        // Load the stock model
       // Get the item details for editing
        $data['item'] = $this->Shoptovehicle_model->getVehicleItem($id);
        $data['sales_count'] = $this->Sales_model->getSalesCount();
        if ($data['item']) {

            $this->load->view('parts/header');
            $this->load->view('parts/nav');
            $this->load->view('parts/aside',$data);
            $this->load->view('editVehicle', $data);
            $this->load->view('parts/footer');
           // Load the view for editing an item          
        } else {
           // Item not found, show an error message
            $this->session->set_flashdata('error', 'Item not found.');
            redirect('vehicle/view');
        }
    }*/


    public function get_stock_product_sku() {
        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];
        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `model_number` FROM warehousetoshop WHERE id = ?", array($pid));
        $data=$stock_query->result();
        $d= $data[0]->model_number;
        echo $d;

    }

 

    public function get_stock_item_price() {
        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];
        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `cost_price` FROM warehousetoshop WHERE id = ?", array($pid));
        $data=$stock_query->result();
        $d= $data[0]->cost_price;
        echo $d;

    }

    public function get_stock_item_selling_price() {
        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];
        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `selling_price` FROM warehousetoshop WHERE id = ?", array($pid));
        $data=$stock_query->result();
        $d= $data[0]->selling_price;
        echo $d;

    }

    public function delete_vehicle( $id ) {


        $stock_query = $this->db->query("DELETE FROM `stock_to_vehicle` WHERE `stock_to_vehicle`.`id` ='$id'");

    

        $this->session->set_flashdata('danger', 'Deleted Vehicle !');

        
        redirect('Shoptovehicle/view','refresh');
        




    }

    public function getcategorytopstock(){
            $category = $this->input->post('category');
            $result = $this->Shoptovehicle_model->getstocks($category);
            echo json_encode($result);
    }


}