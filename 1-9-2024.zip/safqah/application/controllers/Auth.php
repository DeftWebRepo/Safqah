<?php
class Auth extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('login_model'); // Load the Login_model
    }

    // User login
    public function login() {
        // Retrieve user input (email and password)
        $email = $this->input->post('email');
        $password = $this->input->post('password');

        // Check credentials
        $user = $this->login_model->check_credentials($email, $password);

        if ($user) {
            // Successful login, return user data as JSON response
            $this->output->set_output(json_encode(['success' => true, 'user' => $user]));
        } else {
            // Invalid login, return error message
            $this->output->set_output(json_encode(['success' => false, 'message' => 'Invalid credentials']));
        }
    }

    // User registration
    public function register() {
        // Retrieve user input (email, password, username, etc.)
        $data = [
            'uid' => $this->input->post('uid'),
            'email' => $this->input->post('email'),
            'username' => $this->input->post('username'),
            'password' => $this->input->post('password'),
            'lastlogin' => '',
            'date' => '',
            'status' => 1 // You can set an appropriate status value for registration
        ];

        // Create a new user
        $user_id = $this->login_model->create_user($data);

        if ($user_id) {
            // Successful registration, return user ID as JSON response
            $this->output->set_output(json_encode(['success' => true, 'user_id' => $user_id]));
        } else {
            // Registration failed, return error message
            $this->output->set_output(json_encode(['success' => false, 'message' => 'Registration failed']));
        }
    }

    public function logout() {
        // Destroy the user's session to log them out
        $this->session->sess_destroy();

        // Check if the session has been destroyed
        if (!$this->session->userdata('logged_in')) {
            // Redirect to the login page
            redirect('https://safqah.deftinnovations.in/');
        } else {
            // Handle the case where the session destruction failed
            // This might happen if the session library is not loaded, or if there's an issue destroying the session
            echo "Failed to destroy session. Please try again.";
        }
    }


}
