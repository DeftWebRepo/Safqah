<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('Login_model');
    }

    public function index() {
        $this->load->view('parts/header');
        //$this->load->view('parts/nav');
        //$this->load->view('parts/aside');
        $this->load->view('login');
        $this->load->view('parts/footer');
    }

    public function login_action() {
        $username = $this->input->post('username');
        $password = $this->input->post('password');

        $user = $this->Login_model->authenticate($username, $password);

        if ($user) {
            // Successful login, store user data in session if needed
            // Redirect to a dashboard or another page
              $userdata = array(
            'user_id' => $user->id,        // Change this to your user ID field name
            'username' => $user->username,
             'loggedin' =>true  // Change this to your username field name
        );
        $this->session->set_userdata($userdata);

         redirect("dashboard");



        } else {
           
              redirect("login");

        }
    }
}
