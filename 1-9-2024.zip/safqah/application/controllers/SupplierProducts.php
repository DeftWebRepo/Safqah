<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SupplierProducts extends CI_Controller {

	public function __construct() {
		/*call CodeIgniter's default Constructor*/
		parent::__construct();

		/*load model*/
	
        $this->load->model('Category_model');
		$this->load->model('SupplierProduct_model');
         $this->load->model('Supplier_model');
         $this->load->model('Sales_model');
	}

	public function index()
	{
		$data['suppliers'] = $this->Supplier_model->getSuppliers();
		$data['categories'] = $this->Category_model->getCategories();
		$data['sales_count'] = $this->Sales_model->getSalesCount();
		$this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
        $this->load->view('AddSupplierProducts',$data);
        $this->load->view('parts/footer');

	}
	public function add()
	{
        $data['suppliers'] = $this->Supplier_model->getSuppliers();
		$data['categories'] = $this->Category_model->getCategories();
		$data['sales_count'] = $this->Sales_model->getSalesCount();

		$this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
		$this->load->view('AddSupplierProducts',$data);
        $this->load->view('parts/footer');
	}

    public function save()
	{
		
		// var_dump($_POST);

		 $product_name=$this->input->post('product_name');
		 $product_sku=$this->input->post('product_sku');
		 $product_category=$this->input->post('product_category');
         $product_price=$this->input->post('product_price');
         $product_qty=$this->input->post('product_qty');
         $total_price=$this->input->post('total_price');
         $supplier_name=$this->input->post('supplier_name');
		 $data = [

			'product_name'=> $product_name,
			'product_sku'=> $product_sku,
			'product_category'=> $product_category,
            'product_price'=> $product_price,
            'product_qty'=> $product_qty,
            'total_price'=> $total_price,
            'supplier_name'=> $supplier_name,
		];

		$result = $this->SupplierProduct_model->save($data);

		if($result) {

            $this->session->set_flashdata('success', 'Data Saved !');
			redirect('supplier-management/add');
			
			
		} else {
			echo "Something went wrong";
			exit();
		}


	}

	public function view() {

        $data['products'] = $this->SupplierProduct_model->getProductData();
        
        $data['suppliers'] = $this->Supplier_model->getSuppliers();
        $data['sales_count'] = $this->Sales_model->getSalesCount();
        $this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
        $this->load->view('viewSupplierProduct', $data);
        $this->load->view('parts/footer');
    }


    public function edit($Pid) {
        // Load the stock model
   
    
       // Get the item details for editing
        $data['item'] = $this->SupplierProduct_model->getProductItem($Pid);
		$data['categories'] = $this->Category_model->getCategories();
		$data['suppliers'] = $this->Supplier_model->getSuppliers();
        $data['sales_count'] = $this->Sales_model->getSalesCount();
    
        if ($data['item']) {

            $this->load->view('parts/header');
            $this->load->view('parts/nav');
            $this->load->view('parts/aside',$data);
            $this->load->view('editSupplierProducts', $data);
            $this->load->view('parts/footer');
           // Load the view for editing an item
           
        } else {
           // Item not found, show an error message
            $this->session->set_flashdata('error', 'Item not found.');
            redirect('SupplierProducts/view');
        }
    }

    public function update($Pid) {
    
        $product_name=$this->input->post('product_name');
        $product_sku=$this->input->post('product_sku');
        $product_category=$this->input->post('product_category');
        $product_price=$this->input->post('product_price');
        $product_qty=$this->input->post('product_qty');
        $total_price=$this->input->post('total_price');
        $supplier_name=$this->input->post('supplier_name');

   
       $updatedData = [
        'product_name'=> $product_name,
        'product_sku'=> $product_sku,
        'product_category'=> $product_category,
        'product_price'=> $product_price,
        'product_qty'=> $product_qty,
        'total_price'=> $total_price,
        'supplier_name'=> $supplier_name,
   

       ];

    
        // Update the item in the database
        $this->SupplierProduct_model->updateProduct($Pid, $updatedData);
    
        // Set a success message
        $this->session->set_flashdata('success', 'Item updated successfully.');
    
        // Redirect to the stock listing page
        redirect('SupplierProducts/view');
    }


	public function delete($Pid) {
        // Load the stock model
        $this->load->model('SupplierProduct_model');
    
        // Check if the item with the given $pid exists
        $item = $this->SupplierProduct_model->getProductItem($Pid);
        if ($item) {
            // Item exists, proceed with deletion
            $this->SupplierProduct_model->deleteProductItem($Pid);
            $this->session->set_flashdata('success', 'Item deleted successfully.');
        } else {
            // Item does not exist
            $this->session->set_flashdata('error', 'Item not found.');
        }
    
        // Redirect to the stock listing page
        redirect('SupplierProducts/view');
    }


 }
