<?php
defined('BASEPATH') or exit('No direct script access allowed');

class SalesReturn extends CI_Controller
{

    public function __construct()
    {
        /*call CodeIgniter's default Constructor*/
        parent::__construct();

        /*load model*/
        $this->load->model('StockClearence_model');
        $this->load->model('Stock_model');
        $this->load->model('Product_Return_model');
    }

    public function index()
    {

        echo "";
    }


    public function add()
    {

        $stock = $this->db->query("SELECT * FROM `sales`");
        $data['stock'] = $stock->result();


        $this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside', $data);
        $this->load->view('sales_return/add');
        $this->load->view('parts/footer');
    }

    public function view()
    {

        $stock = $this->db->query("SELECT * FROM `sales_return`");
        $data['sales_return'] = $stock->result();

        $this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside', $data);
        $this->load->view('sales_return/view');
        $this->load->view('parts/footer');
    }


    public function invoice_no()
    {

        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];

        // Run the query to fetch stock information
        $sql = "SELECT `invoice_number` FROM `stock` WHERE `product_sku`='$pid';";

        $stock_query = $this->db->query($sql);

        $data = $stock_query->result();

        $d = $data[0]->invoice_number;

        echo $d;
    }

    public function get_sku()
    {

        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];

        // Run the query to fetch stock information
        $sql = "SELECT `product_sku` FROM `stock` WHERE `item_name`='$pid';";

        $stock_query = $this->db->query($sql);

        $data = $stock_query->result();

        $d = $data[0]->product_sku;

        echo $d;
    }

    public function get_product_name($id){
        return $this->db->where('invoice_no', $id)
                        ->get('sales')->row('product_name');

     }

    public function save()
    {

        //$data = $_POST;

        $product_name =$this->input->post('product_name');
        $sku = $this->input->post('sku');
        $product_qty = $this->input->post('product_qty');
        $customer = $this->input->post('customer');
        $total_price = $this->input->post('total_price');
        $invoice_no = $this->input->post('invoice_no');
        $cost = $this->input->post('cost');
        $amount = $this->input->post('amount');
        $remark = $this->input->post('remark');
        $product_return_date = $this->input->post('today_date');
        $vehicle = $this->input->post('vehicle_number');

        $data = array(
            'product_name' => $product_name,
            'sku' => $sku,
            'product_qty' => $product_qty,
            'customer' => $customer,
            'total_price' => $total_price,
            'invoice_no' => $invoice_no,
            'amount' => $amount,
            'remark' => $remark,
            'cost' => $cost,
            'product_return_date' => $product_return_date,
            'vehicle_number'=>$vehicle,

        );


        $invoice_no = $invoice_no;

        $sql = "SELECT `product_qty` FROM `sales` WHERE `invoice_no` = ?";
        $query = $this->db->query($sql, array($invoice_no));

        if ($query->num_rows() > 0) {
            $vstock_qty = $query->row()->product_qty;
        } else {
            // Handle the case where no rows are found
            $vstock_qty = 0; // or any default value
        }

       // $vstock_qty = $this->db->where('invoice_no',$invoice_no) ->get('sales')->row('product_qty'); 
        //$sql="SELECT `product_qty` FROM `sales` WHERE `invoice_no`='SAFQAH-S9562325';";
        $price_total = $this->db->where('invoice_no',$invoice_no) ->get('sales')->row('total_price');
        $cost_total = $this->db->where('invoice_no',$invoice_no) ->get('sales')->row('total_cost');

        $price_cost= $cost_total - $cost;
        $price_new =  $price_total - $total_price;
        $qty_new = $vstock_qty - $product_qty;

        // echo $product_qty;
        // echo $vstock_qty;

        // echo $qty_new ;
        // exit();

        if($qty_new < 0) {

            $this->session->set_flashdata('error', ' Not enough Quantity in Stock ' );

            echo '<script>alert("Not enough Quantity in Stock");
            window.location.href = "' . base_url('SalesReturn/add') . '";</script>';

          //  redirect("SalesReturn/add");

            exit();


        }

        if ($qty_new == 0) {
            $status = "Out of stock";
        } else {
            $status = "In Stock";
        }

        $updatedata = [
            'product_qty' => $qty_new,
            'sales_status' => $status,
            'total_price' => $price_new,
            'total_cost' =>$price_cost,

        ];

        $this->db->where('invoice_no',$invoice_no)->update('sales', $updatedata);

        $this->db->insert("sales_return", $data);

        $this->session->set_flashdata('success', 'Item inserted successfully.');

       // redirect("SalesReturn/add");

       $invoice_number=$invoice_no;

       $datay['invoice_number']=$invoice_number;

       $salesy = $this->db->query("SELECT * FROM `sales_return` WHERE `invoice_no`='$invoice_number'");

       $datay['sales'] = $salesy->result();

       $datay['sales2'] = $salesy->result();

       $this->load->view("invoice/d_invoice",$datay);

    }


    public function delete($id)
    {

        $id = $id;
        $this->db->where("id", $id);
        $this->db->delete("sales_return");

        $this->session->set_flashdata('success', 'Item Deleted successfully.');

        redirect("SalesReturn/view");
    }


    public function get_p_sku() {
        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];

        $pid = $_REQUEST['query'];

        $this->db->where("invoice_no",$pid);

        echo $this->db->get("sales")->row("sku");

    }

    public function product_qty() {
    
        $pid = $_REQUEST['query'];

        $this->db->where("invoice_no",$pid);

        echo $this->db->get("sales")->row("product_qty");


    }

    public function selling_price() {
    
        $pid = $_REQUEST['query'];

        $this->db->where("invoice_no",$pid);

        echo $this->db->get("sales")->row("selling_price");


    }


    public function transferred_on() {
    
        $pid = $_REQUEST['query'];

        $this->db->where("invoice_no",$pid);

        echo $this->db->get("sales")->row("transferred_on");


    }

    public function customer() {
    
        $pid = $_REQUEST['query'];

        $this->db->where("invoice_no",$pid);

        echo $this->db->get("sales")->row("customer_name");


    }
    public function product() {
    
        $pid = $_REQUEST['query'];

        $this->db->where("invoice_no",$pid);

        echo $this->db->get("sales")->row("product_name");


    }
    public function vehicle() {
    
        $pid = $_REQUEST['query'];

        $this->db->where("invoice_no",$pid);

        echo $this->db->get("sales")->row("vehicle");


    }

    public function cost() {
    
        $pid = $_REQUEST['query'];

        $this->db->where("invoice_no",$pid);

        echo $this->db->get("sales")->row("product_cost");


    }
    


    

    



}
