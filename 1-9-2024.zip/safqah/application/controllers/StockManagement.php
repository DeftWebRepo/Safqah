<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class StockManagement extends CI_Controller {

    public function __construct() {
		/*call CodeIgniter's default Constructor*/
		parent::__construct();

		/*load model*/
		$this->load->model('Stock_model');
        $this->load->model('Category_model');
        $this->load->model('Supplier_model');
        $this->load->model('Sales_model');
        $this->load->model('Lpo_model');
	}
   
   
    public function index() {

      
        $data['categories'] = $this->Category_model->getCategories();
        $data['sales_count'] = $this->Sales_model->getSalesCount();
        $this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
        $this->load->view('addStock',$data);
        $this->load->view('parts/footer');
    }
    
      public function add() {

     

        $data['categories'] = $this->Category_model->getCategories();

        $data['suppliers'] = $this->Supplier_model->getSuppliers();
        $data['sales_count'] = $this->Sales_model->getSalesCount();

        $this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
        $this->load->view('addStock',$data);
        $this->load->view('parts/footer');
    }
    
//     public function save(){

//     $item_name = $this->Stock_model->getWarehouseItemss($this->input->post("item_name"));
//     $product_sku = $this->input->post("product_sku");
//     $supplier_name = $this->input->post("supplier_name");
//     $invoice_number = $this->input->post("invoice_number");
//     $item_quantity = $this->input->post("item_quantity");
//     $item_price = $this->input->post("item_price");
//     $selling_price = $this->input->post("item_selling_price");
//     $category = $this->input->post("category");
//     $purchace_date = $this->input->post("purchace_date");
//     $total_cost_price = $this->input->post("total_cost_price");
//     $payment = $this->input->post('payment');

//     // Determine stock status based on item quantity
//     $status = ($item_quantity == 0) ? "Out of stock" : "In Stock";

//     $data = [
//         'item_name' => $item_name,
//         'product_sku' => $product_sku,
//         'item_selling_price' => $selling_price,
//         'item_price' => $item_price,
//         'supplier_name' => $supplier_name,
//         'invoice_number' => $invoice_number,
//         'item_quantity' => $item_quantity,
//         'category' => $category,
//         'purchace_date' => $purchace_date,
//         'total_cost_price' => $total_cost_price,
//         'stock_status' => $status,
//         'payment' => $payment,
//     ];

//     // Retrieve existing stock information
//     $current_stock_qty = $this->db->where('product_sku', $product_sku)->get('stock')->row('item_quantity');
//     $item_selling_price = $this->db->where('product_sku', $product_sku)->get('stock')->row('item_selling_price');
//     $new_item_price = $this->db->where('product_sku', $product_sku)->get('stock')->row('item_price');
//     $exits_product_sku = $this->db->where('product_sku', $product_sku)->get('stock')->row('product_sku');

//     $condition = ['product_sku' => $product_sku];

//     // Check if the record already exists in the 'stock' table
//     $exists_in_stock = $this->db->get_where('stock', $condition);

//     if ($exists_in_stock->num_rows() > 0) {
//         // If the record exists, update quantity and total price
//         $get_purchase_qty = $this->Lpo_model->get_vehicles_to_qty($product_sku);
//         $get_purchase_price = $this->Lpo_model->get_vehicles_to_price($product_sku);
//         $get_cost_price = $this->Lpo_model->get_costs_price($product_sku);

//         if ($get_cost_price != $item_price) {
//             $to_qty_new = $get_purchase_qty + $item_quantity;
//             $sell = $item_price * $item_quantity;
//             $to_margin = $sell + $total_cost_price;
//             $to_supdatedata = [
//                 'item_quantity' => $to_qty_new,
//                 'total_cost_price' => $to_margin,
//                 'item_price' => $item_price,
//             ];
//         } else {
//             $to_qty_new = $get_purchase_qty + $item_quantity;
//             $to_margin = $get_purchase_price + $total_cost_price;
//             $to_supdatedata = [
//                 'item_quantity' => $to_qty_new,
//                 'total_cost_price' => $to_margin,
//             ];
//         }

//         // Update the existing record in the 'stock' table
//         $result = $this->Lpo_model->to_updateStockQty($product_sku, $to_supdatedata);
//         $result = $this->Lpo_model->to_updateStockQtysssss($product_sku, $to_supdatedata);
//     } else {
//         if ($exits_product_sku == $product_sku) {
//             if ($item_selling_price != $selling_price || $new_item_price != $item_price) {
//                 $new_stock_qty = $current_stock_qty + $item_quantity;

//                 $u2 = [
//                     'item_quantity' => $new_stock_qty,
//                     'item_selling_price' => $selling_price,
//                     'item_price' => $item_price,
//                     'stock_status' => $status,
//                 ];

//                 $result = $this->db->where('product_sku', $product_sku)->update('stock', $u2);
//                 $result = $this->db->where('product_sku', $product_sku)->update('lpo', $u2);
//             } else {
//                 $new_stock_qty = $current_stock_qty + $item_quantity;
//                 $u3 = [
//                     'item_quantity' => $new_stock_qty,
//                     'stock_status' => $status,
//                 ];

//                 $result = $this->db->where('product_sku', $product_sku)->update('stock', $u3);
//                 $result = $this->db->where('product_sku', $product_sku)->update('lpo', $u3);
//             }
//         } else {
//             // Insert new records into the 'stock' and 'lpo' tables
//             $result = $this->Stock_model->save($data);
//             $result = $this->Lpo_model->save($data);
//         }
//     }

//     if ($result) {
//         $this->session->set_flashdata('success', 'Data Saved!');
//         redirect("Lpo/add");
//     } else {
//         echo "Something went wrong";
//         exit();
//     }
// }
    

public function save() {
    // Retrieve input data
    $item_name = $this->Stock_model->getWarehouseItemss($this->input->post("item_name"));
    $product_sku = $this->input->post("product_sku");
    $supplier_name = $this->input->post("supplier_name");
    $invoice_number = $this->input->post("invoice_number");
    $item_quantity = $this->input->post("item_quantity");
    $item_price = $this->input->post("item_price");
    $selling_price = $this->input->post("item_selling_price");
    $category = $this->input->post("category");
    $purchace_date = $this->input->post("purchace_date");
    $total_cost_price = $this->input->post("total_cost_price");
    $payment = $this->input->post('payment');
    $po_number = $this->input->post('po_number');
    
    // Determine stock status based on item quantity
    $status = ($item_quantity == 0) ? "Out of stock" : "In Stock";

    // Prepare data array
    $data = [
        'item_name' => $item_name,
        'product_sku' => $product_sku,
        'item_selling_price' => $selling_price,
        'item_price' => $item_price,
        'supplier_name' => $supplier_name,
        'invoice_number' => $invoice_number,
        'item_quantity' => $item_quantity,
        'category' => $category,
        'purchace_date' => $purchace_date,
        'total_cost_price' => $total_cost_price,
        'stock_status' => $status,
        'payment' => $payment,
        'po_number' => $po_number,
    ];

    // Retrieve existing stock information
    $existing_stock = $this->db->where('product_sku', $product_sku)->get('stock')->row();
    
    if ($existing_stock) {
        // If the record exists, update quantity and total price
        $get_purchase_qty = $this->Lpo_model->get_vehicle_to_qty($product_sku);
        $get_purchase_price = $this->Lpo_model->get_vehicle_to_price($product_sku);
        $get_cost_price = $this->Lpo_model->get_cost_price($product_sku);

        $to_qty_new = $get_purchase_qty + $item_quantity;
        $to_margin = ($get_cost_price != $item_price) ? $item_price * $item_quantity + $total_cost_price : $get_purchase_price + $total_cost_price;

        $to_supdatedata = [
            'item_quantity' => $to_qty_new,
            'total_cost_price' => $to_margin,
            'item_selling_price' => $selling_price,
            'item_price' => $item_price,
            'stock_status' => $status,
            'po_number' => $po_number,
        ];

        // Update the existing record in the 'stock' table
        
        $result = $this->Lpo_model->to_updateStockQty($product_sku, $to_supdatedata);
    } else {
        // Insert new records into the 'stock' and 'lpo' tables
        $result = $this->Stock_model->save($data);
        

        // Check if both inserts were successful
        
    }

    $result = $this->Lpo_model->save($data);
    // Handle the result
    if ($result) {
        $this->session->set_flashdata('success', 'Data Saved!');
        redirect("Lpo/add");


        // $invoice_number = $invoice_no;

        // $datax['invoice_number'] = $invoice_number;

        // $saless = $this->db->query("SELECT * FROM `lpo` WHERE `invoice_no`='$invoice_number'");

        // $datax['lpo'] = $saless->result();

        // $datax['lpo2'] = $saless->result();

        // $this->load->view("invoice/p_invoice",$datax);






    } else {
        echo "Something went wrong";
        exit();
    }
}


    public function view() {

        $data['stock'] = $this->Stock_model->getStockData();
        $data['sales_count'] = $this->Sales_model->getSalesCount();


        $this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
        $this->load->view('viewStock', $data);
        $this->load->view('parts/footer');
    }


    public function edit($pid) {
        // Load the stock model
        $this->load->model('Stock_model');
        
        $data['categories'] = $this->Category_model->getCategories();
        // Get the item details for editing
        $data['item'] = $this->Stock_model->getStockItem($pid);

        $data['suppliers'] = $this->Supplier_model->getSuppliers();
        $data['sales_count'] = $this->Sales_model->getSalesCount();
        if ($data['item']) {

            $this->load->view('parts/header');
            $this->load->view('parts/nav');
            $this->load->view('parts/aside',$data);
            $this->load->view('edit_stock', $data);
            $this->load->view('parts/footer');
            // Load the view for editing an item
           
        } else {
            // Item not found, show an error message
            $this->session->set_flashdata('error', 'Item not found.');
            redirect('stock-management/view');
        }
    }
    


    public function delete($pid) {
        // Load the stock model
        $this->load->model('Stock_model');
    
        // Check if the item with the given $pid exists
        $item = $this->Stock_model->getStockItem($pid);
        if ($item) {
            // Item exists, proceed with deletion
            $this->Stock_model->deleteStockItem($pid);
            $this->session->set_flashdata('success', 'Item deleted successfully.');
        } else {
            // Item does not exist
            $this->session->set_flashdata('error', 'Item not found.');
        }
    
        // Redirect to the stock listing page
        redirect('stock-management/view');
    }

    public function update($pid) {
    
        $item_name=$this->input->post("item_name");
       $product_sku=$this->input->post("product_sku");
      
       $supplier_name=$this->input->post("supplier_name");
       $po_number=$this->input->post("po_number");
       $invoice_number=$this->input->post("invoice_number");
       $item_quantity=$this->input->post("item_quantity");
       $category=$this->input->post("category");
       $item_price=$this->input->post("item_price");
       $selling_price=$this->input->post("item_selling_price");
       $purchace_date=$this->input->post("purchace_date");
       $total_cost_price=$this->input->post("total_cost_price");
       $payment=$this->input->post('payment');
       $updatedData = [
           'item_name'=> $item_name,
           'product_sku'=> $product_sku,
           'supplier_name'=> $supplier_name,
           'po_number'=> $po_number,
           'invoice_number'=> $invoice_number,
           'item_quantity'=> $item_quantity,
           'item_selling_price'=> $selling_price,
           'category'=> $category,
           'purchace_date'=> $purchace_date,
           'total_cost_price'=> $total_cost_price,
           'item_price'=> $item_price,
           'payment'=> $payment,

       ];

    
        // Update the item in the database
        $this->Stock_model->updateStockItem($pid, $updatedData);
    
        // Set a success message
        $this->session->set_flashdata('success', 'Item updated successfully.');
    
        // Redirect to the stock listing page
        redirect('stock-management/view');
    }

    public function getstockpurchasecat(){
        $category = $this->input->post('category');
        $result = $this->Stock_model->getstockqtypurchase($category);
        echo json_encode($result);

    }
    public function getstockinfopurchase(){
        
        $selectedValue = $this->input->post('selectedValue');
        $result = $this->Stock_model->getStockItemspurchase($selectedValue);
        echo json_encode($result);
    }
    
 
}


