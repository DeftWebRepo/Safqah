<?php
defined('BASEPATH') or exit('No direct script access allowed');

class StockReturn extends CI_Controller
{

    public function __construct()
    {
        /*call CodeIgniter's default Constructor*/
        parent::__construct();

        /*load model*/
 
        $this->load->model('Stock_model');
        $this->load->model('Stock_Return_model');
    }

    public function index()
    {

        echo "";
    }


    public function add()
    {

        $stock = $this->db->query("SELECT * FROM `sales`");
        $data['stock'] = $stock->result();


        $this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside', $data);
        $this->load->view('return_stock/add');
        $this->load->view('parts/footer');
    }

    public function view()
    {

        $stock = $this->db->query("SELECT * FROM `return_stock`");
        $data['return_stock'] = $stock->result();

        $this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside', $data);
        $this->load->view('return_stock/view');
        $this->load->view('parts/footer');
    }


    public function invoice_no()
    {

        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];

        // Run the query to fetch stock information
        $sql = "SELECT `invoice_number` FROM `stock` WHERE `product_sku`='$pid';";

        $stock_query = $this->db->query($sql);

        $data = $stock_query->result();

        $d = $data[0]->invoice_number;

        echo $d;
    }

    public function get_sku()
    {

        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];

        // Run the query to fetch stock information
        $sql = "SELECT `product_sku` FROM `stock` WHERE `item_name`='$pid';";

        $stock_query = $this->db->query($sql);

        $data = $stock_query->result();

        $d = $data[0]->product_sku;

        echo $d;
    }

    public function get_product_name($id){
        return $this->db->where('invoice_no', $id)
                        ->get('sales')->row('product_name');

     }

    public function save()
    {

        //$data = $_POST;

        $product_name =$this->input->post('product');
        $sku = $this->input->post('sku');
        $product_qty = $this->input->post('product_qty');
        $selling_price = $this->input->post('selling_price');
        $remark = $this->input->post('remark');
        $total_selling_pricing = $this->input->post('total_selling_pricing');
        $product_cost=$this->input->post('product_cost');
        $invoice=$this->input->post('invoice_no');
        $customer=$this->input->post('customer');
        $vehicle=$this->input->post('vehicle_number');

        $data = array(
            'product' => $product_name,
            'sku' => $sku,
            'product_qty' => $product_qty,
            'selling_price' => $selling_price,
            'remark' => $remark,
            'total_selling_pricing' =>$total_selling_pricing,
            'date'=>date("d/m/yy"),
            'invoice_no'=>$invoice,
            'customer'=>$customer,
            'vehicle_number'=>$vehicle,
        );
        
        

        


        $vstock_qty2 = $this->db->where('invoice_no',$invoice) ->get('sales')->row('product_qty');
        $price_total2 = $this->db->where('invoice_no',$invoice) ->get('sales')->row('total_price');
        $cost = $this->db->where('invoice_no',$invoice) ->get('sales')->row('total_cost');

        $tcost=$product_cost * $product_qty;
        $price_new =  $price_total2 - $total_selling_pricing;
        $qty_new = $vstock_qty2 - $product_qty;
        $total_costs = $cost - $tcost;
        
        
         if ($qty_new < 0) {
        
                    $this->session->set_flashdata('error', ' Not enough Quantity in Stock ' );
        
                    echo '<script>alert("Not enough Quantity in Stock");
                    window.location.href = "' . base_url('add-stock-return') . '";</script>';
        
                  //  redirect("SalesReturn/add");
        
                    exit();
        
        
                }
        
        
        if ($qty_new == 0) {
                    $status = "Out of stock";
                } else {
                    $status = "In Stock";
                }
        
        // if($vehicle=="shop"){

        //  $vstock_qty = $this->db->where('model_number',$sku) ->get("warehousetoshop")->row('quantity');
        //  $vstock_pricess = $this->db->where('model_number',$sku) ->get("warehousetoshop")->row('total_price');

        //  $update_qty=$product_qty+$vstock_qty;
        //  $update_prices = $total_selling_pricing + $vstock_pricess;

        //  $updatedata = [

        //     'quantity' => $update_qty,
        //     'total_price' => $update_prices,
 
        //  ];

        //  $this->db->where('model_number',$sku)->update('warehousetoshop', $updatedata);
    
        // }
        // else{

            $vstock_qty3 = $this->db->where(['vehicle_from_to'=>$vehicle,'model_number'=>$sku]) ->get('vehicle_to_vehicle')->row('quantity');
            $price_total3 = $this->db->where(['vehicle_from_to'=>$vehicle,'model_number'=>$sku]) ->get('vehicle_to_vehicle')->row('total_price');
           
            $update_qty3=$product_qty+$vstock_qty3;
            $update_prices3 = $total_selling_pricing + $price_total3;

            $updatedata3 = [

                'quantity' => $update_qty3,
                'total_price' => $update_prices3,
     
             ];

             $this->db->where(['vehicle_from_to'=>$vehicle,'model_number'=>$sku])->update('vehicle_to_vehicle', $updatedata3);
        // }
        
        $updatedata2 = [
                    'product_qty' => $qty_new,
                    'total_price' => $price_new,
                    'total_cost' => $total_costs,

        ];
        
        
        $this->db->where(['sku'=>$sku,'invoice_no'=>$invoice])->update('sales', $updatedata2);

       

        $this->db->insert('return_stock',$data);

        $this->session->set_flashdata('success', 'Item iserted successfully.');


        


         $invoice_number = $invoice;

         $datay['invoice_number']= $invoice_number;
  
         $salesy = $this->db->query("SELECT * FROM `return_stock` WHERE `invoice_no`='$invoice_number'");
  
         $datay['sales'] = $salesy->result();
  
         $datay['sales2'] = $salesy->result();
  
         $this->load->view("invoice/s_invoice",$datay);
    }


    public function delete($id)
    {

        $id = $id;
        $this->db->where("id", $id);
        $this->db->delete("return_stock");

        $this->session->set_flashdata('success', 'Item Deleted successfully.');

        redirect("view-stock-return");
    }

    public function delete_StockReturn($id)
    {

        $id = $id;
        $this->db->where("id", $id);
        $this->db->delete("return_stock");

        $this->session->set_flashdata('success', 'Item Deleted successfully.');

       redirect("view-stock-return");
    }

    


    public function get_p_sku() {
        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];

        $pid = $_REQUEST['query'];

        $this->db->where("invoice_no",$pid);

        echo $this->db->get("sales")->row("sku");

    }

    public function product_qty() {
    
        $pid = $_REQUEST['query'];

        $this->db->where("invoice_no",$pid);

        echo $this->db->get("sales")->row("product_qty");


    }

    public function selling_price() {
    
        $pid = $_REQUEST['query'];

        $this->db->where("invoice_no",$pid);

        echo $this->db->get("sales")->row("selling_price");


    }


    public function transferred_on() {
    
        $pid = $_REQUEST['query'];

        $this->db->where("invoice_no",$pid);

        echo $this->db->get("sales")->row("transferred_on");


    }

    public function customer() {
    
        $pid = $_REQUEST['query'];

        $this->db->where("invoice_no",$pid);

        echo $this->db->get("sales")->row("customer_name");


    }


    public function cost() {
    
        $pid = $_REQUEST['query'];

        $this->db->where("invoice_no",$pid);

        echo $this->db->get("sales")->row("product_cost");


    }
    
    
    public function sku() {
        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];
        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `sku` FROM sales WHERE invoice_no = ?", array($pid));
        $data=$stock_query->result();
        $d= $data[0]->sku;
        echo $d;

    }

    public function pqty() {
        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];
        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `product_qty` FROM sales WHERE invoice_no = ?", array($pid));
        $data=$stock_query->result();
        $d= $data[0]->product_qty;
        echo $d;

    }
    public function selling_p_rice() {
        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];
        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `selling_price` FROM sales WHERE invoice_no = ?", array($pid));
        $data=$stock_query->result();
        $d= $data[0]->selling_price;
        echo $d;

    }

    public function product_cost(){

        $pid = $_REQUEST['query'];
        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `product_cost` FROM sales WHERE invoice_no = ?", array($pid));
        $data=$stock_query->result();
        $d= $data[0]->product_cost;
        echo $d;

    }

    public function product(){

        $pid = $_REQUEST['query'];
        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `product_name` FROM sales WHERE invoice_no = ?", array($pid));
        $data=$stock_query->result();
        $d= $data[0]->product_name;
        echo $d;

    }

    public function vehicle(){

        $pid = $_REQUEST['query'];
        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `vehicle` FROM sales WHERE invoice_no = ?", array($pid));
        $data=$stock_query->result();
        $d= $data[0]->vehicle;
        echo $d;

    }
    



}
