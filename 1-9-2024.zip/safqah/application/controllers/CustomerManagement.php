<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CustomerManagement extends CI_Controller {

    public function __construct() {
		/*call CodeIgniter's default Constructor*/
		parent::__construct();

		/*load model*/
		$this->load->model('Stock_model');
        $this->load->model('Category_model');
        $this->load->model('Customer_model');
        $this->load->model('Sales_model');

	}
   
   
    public function index() {


        echo "Landed";
      
       
    }
    
      public function addCustomer() {

        $data['customers'] = $this->Customer_model->getCustomers();
        $data['sales_count'] = $this->Sales_model->getSalesCount();

        $this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
        $this->load->view('addCustomer');
        $this->load->view('parts/footer');
    }
    
    public function save(){


       $customer_name=$this->input->post("customer_name");
       $company_name=$this->input->post("company_name");
       $address=$this->input->post("address");
       $email=$this->input->post("email");
       $phone_number=$this->input->post("phone_number");
       $date=$this->input->post("date");
   
       $data = [
           'customer_name'=> $customer_name,
           'company_name'=> $company_name,
           'address'=> $address,
           'email'=> $email,
           'phone_number'=> $phone_number,
           'date'=> $date,

       ];

       $result = $this->Customer_model->save($data);
       if($result) {
        $this->session->set_flashdata('success', 'Data Saved !');
      
        redirect('CustomerManagement/addCustomer');

       } else {
           echo "Something went wrong";
           exit();
       }
    }

    public function viewCustomer() {
        $data['customers'] = $this->Customer_model->getCustomers();
        $data['stock'] = $this->Customer_model->getStockData();
       
        $data['sales_count'] = $this->Sales_model->getSalesCount();

        $this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside', $data);
        $this->load->view('viewCustomer', $data);
        $this->load->view('parts/footer');
    }


    public function edit($cid) {
        // Load the stock model
      
    
        // Get the item details for editing
        $data['item'] = $this->Customer_model->getStockItem($cid);
        $data['sales_count'] = $this->Sales_model->getSalesCount();
        $data['customers'] = $this->Customer_model->getCustomers();
        if ($data['item']) {

            $this->load->view('parts/header');
            $this->load->view('parts/nav');
            $this->load->view('parts/aside',$data);
            $this->load->view('EditCustomer', $data);
            $this->load->view('parts/footer');
            // Load the view for editing an item
           
        } else {
            // Item not found, show an error message
            $this->session->set_flashdata('error', 'Item not found.');
            redirect('CustomerManagement/viewCustomer');
        }
    }
    


    public function delete($cid) {
        // Load the stock model
  
        // Check if the item with the given $pid exists
        $item = $this->Customer_model->getStockItem($cid);
        if ($item) {
            // Item exists, proceed with deletion
            $this->Customer_model->deleteStockItem($cid);
            $this->session->set_flashdata('success', 'Item deleted successfully.');
        } else {
            // Item does not exist
            $this->session->set_flashdata('error', 'Item not found.');
        }
    
        // Redirect to the stock listing page
        redirect('CustomerManagement/viewCustomer');
    }

    public function update($cid) {
    
        $customer_name=$this->input->post("customer_name");
        $company_name=$this->input->post("company_name");
        $address=$this->input->post("address");
        $email=$this->input->post("email");
        $phone_number=$this->input->post("phone_number");
   
        $date=$this->input->post("date");;
    
        $updatedData = [
            'customer_name'=> $customer_name,
            'company_name'=> $company_name,
            'address'=> $address,
            'email'=> $email,
            'phone_number'=> $phone_number,
   
            'date'=> $date
 
        ];

    
        // Update the item in the database
        $this->Customer_model->updateStockItem($cid, $updatedData);
    
        // Set a success message
        $this->session->set_flashdata('success', 'Item updated successfully.');
    
        // Redirect to the stock listing page
        redirect('CustomerManagement/viewCustomer');
    }
 
}


