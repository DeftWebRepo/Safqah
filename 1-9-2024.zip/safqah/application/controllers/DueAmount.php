<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DueAmount extends CI_Controller {
    public function __construct() {
		/*call CodeIgniter's default Constructor*/
		parent::__construct();

		/*load model*/
		$this->load->model('Sales_model');
        $this->load->model('Category_model');
        $this->load->model('Customer_model');
        $this->load->model('Supplier_model');
        $this->load->model('Vehicle_model');
        $this->load->model('Stocktransfer_model');
        $this->load->model('DueAmount_model');
	}

    public function index(){
        $data['customers'] = $this->Customer_model->getCustomerss();
        $data['categories'] = $this->Category_model->getCategories();
        $data['suppliers'] = $this->Supplier_model->getSupplierss();
        $data['vehicles'] = $this->Vehicle_model->getVehicleData();
        $data['sales_count'] = $this->Sales_model->getSalesCount();

		$this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
        $this->load->view('addDue',$data);
        $this->load->view('parts/footer');

	}

    // public function getsupllierdetailss() {
      
    //     $supplier = $this->input->post('supplier');
    //     $result = $this->DueAmount_model->getsupplierItems($supplier);
    //     echo json_encode($result);
    
    // }

    public function getsupllierdetailss() {
		
        $supplier = $this->input->post('supplier');
        $payss = $this->input->post('payss');
		$result =$this->DueAmount_model->getsupplierItems($supplier,$payss);

        echo json_encode($result);
	}
    public function purchasedue_save(){
        $supplier_name=$this->input->post('supplier_name');
         $total_price=$this->input->post('total_price');
         $price_transfer=$this->input->post('price_transfer');
         $due=$this->input->post('due');

         $data = [
		
			'supplier_name'=> $supplier_name,
            'total_price'=> $total_price,
            'price_transfer'=> $price_transfer,
            'due'=> $due,
		];

        $result = $this->DueAmount_model->save($data);

		if($result) {
            $this->session->set_flashdata('success', 'Data Saved !');
			redirect("DueAmount");
			
		} else {
			echo "Something went wrong";
			exit();
		}

    }

    public function getpricetransfer(){
        $suppliers = $this->input->post('suppliers');
        $result =$this->DueAmount_model->getpricetransferItems($suppliers);
        
        echo json_encode($result);
    }


    public function getcustomerdetailss(){

        $customer = $this->input->post('customer');
        $pay = $this->input->post('pay');
		$result =$this->DueAmount_model->getcustomerItems($customer,$pay);
        echo json_encode($result);
    }

    public function salesdue_save(){

        $customer_name=$this->input->post('customer_name');
        $total_price=$this->input->post('total_price');
        $transfer_price=$this->input->post('transfer_price');
        $due=$this->input->post('due');

        $data = [
       
           'customer_name'=> $customer_name,
           'total_price'=> $total_price,
           'transfer_price'=> $transfer_price,
           'due'=> $due,
       ];

       $result = $this->DueAmount_model->savedue($data);

       if($result) {
           $this->session->set_flashdata('hello', 'Data Saved !');
           redirect("DueAmount");
           
       } else {
           echo "Something went wrong";
           exit();
       }



    }
    public function getamounttransfer(){
        $customers = $this->input->post('customers');
        $result =$this->DueAmount_model->getamounttransferItems($customers);
        
        echo json_encode($result);
    }

    public function profits(){
        $result =$this->DueAmount_model->gettransfer();
        echo json_encode($result);
    }

    public function supplierlist(){
        $result =$this->DueAmount_model->getstransfers();
        echo json_encode($result);
    }

    public function stocklist(){
        $result =$this->DueAmount_model->getstockttransfers();
        echo json_encode($result);
    }
    public function stocklists(){
        $result =$this->DueAmount_model->getstockttransfersss();
        echo json_encode($result);
    }
    
}