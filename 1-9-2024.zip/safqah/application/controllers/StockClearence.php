<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class StockClearence extends CI_Controller {

	public function __construct() {
		/*call CodeIgniter's default Constructor*/
		parent::__construct();

		/*load model*/
		$this->load->model('StockClearence_model');
		$this->load->model('Stock_model');
        $this->load->model('Sales_model');
        $this->load->model('Lpo_model');
        $this->load->model('Product_Return_model');

	}

	public function index()
	{
		
		echo "";

	}
	public function add()
	{
		  $data['sales_count'] = $this->Sales_model->getSalesCount();
		  $this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
        $this->load->view('AddStockClearence');
        $this->load->view('parts/footer');
	}



	public function save()
	{
		
		// var_dump($_POST);

		 $product=$this->input->post('product');
		 $sku=$this->input->post('sku');
		 $date=$this->input->post('date');
		 $invoice_no=$this->input->post('invoice_no');
         $amount=$this->input->post('amount');
         $status=$this->input->post('status');
         $remark=$this->input->post('remark');
         $today_date=$this->input->post('today_date');
         $product_qty=$this->input->post('product_qty');


		 $data = [
			'product'=> $product,
			'sku'=> $sku,
			'date'=> $date,
			'invoice_no'=> $invoice_no,
            'amount'=> $amount,
            'status'=> $status,
            'remark'=> $remark,
            'today_date'=> $today_date,
			'product_qty'=>$product_qty,
          

		];

      

		$result = $this->StockClearence_model->save($data);

		if($result) {
			redirect("stock-clearence/view");
			
		} else {
			echo "Something went wrong";
			exit();
		}


	}

	public function view() {

        $data['clearences'] = $this->StockClearence_model->getClearenceData();
        
        $data['sales_count'] = $this->Sales_model->getSalesCount();

        $this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside', $data);
        $this->load->view('viewstockclearence', $data);
        $this->load->view('parts/footer');
    }



	public function edit($sc_id) {
        // Load the stock model
   
    
       // Get the item details for editing
        $data['item'] = $this->StockClearence_model->getClearenceItem($sc_id);
	
        $data['sales_count'] = $this->Sales_model->getSalesCount();
    
        if ($data['item']) {

            $this->load->view('parts/header');
            $this->load->view('parts/nav');
            $this->load->view('parts/aside',$data);
            $this->load->view('editClearence', $data);
            $this->load->view('parts/footer');
           // Load the view for editing an item
           
        } else {
           // Item not found, show an error message
            $this->session->set_flashdata('error', 'Item not found.');
            redirect('stock-clearence/view');
        }
    }


       public function get_product_name($id) {
        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];
        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `item_name` FROM stock WHERE pid = ?", array($pid));
        $data=$stock_query->result();
        $d= $data[0]->item_name;
        echo $d;
        }
     

	public function update($sc_id) {
    
		$product=$this->input->post('product');
		$sku=$this->input->post('sku');
		$date=$this->input->post('date');
		$invoice_no=$this->input->post('invoice_no');
		$amount=$this->input->post('amount');
		$status=$this->input->post('status');
		$remark=$this->input->post('remark');
		$today_date=$this->input->post('today_date');
		$product_qty=$this->input->post('product_qty');
   
       $updatedData = [
		'product'=>$product,
		'sku'=> $sku,
		'date'=> $date,
		'invoice_no'=> $invoice_no,
		'amount'=> $amount,
		'status'=> $status,
		'remark'=> $remark,
		'today_date'=> $today_date,
		'product_qty'=>$product_qty,


       ];

    
        // Update the item in the database
        $this->StockClearence_model->updateClearence($sc_id, $updatedData);
    
        // Set a success message
        $this->session->set_flashdata('success', 'Item updated successfully.');
    
        // Redirect to the stock listing page
        redirect('stock-clearence/view');
    }


	public function delete($sc_id) {
        // Load the stock model
        $this->load->model('StockClearence_model');
    
        // Check if the item with the given $pid exists
        $item = $this->StockClearence_model->getClearenceItem($sc_id);
        if ($item) {
            // Item exists, proceed with deletion;
            $this->StockClearence_model->deleteClearenceItem($sc_id);
            $this->session->set_flashdata('success', 'Item deleted successfully.');
        } else {
            // Item does not exist
            $this->session->set_flashdata('error', 'Item not found.');
        }
    
        // Redirect to the stock listing page
        redirect('stock-clearence/view');
    }

/************ Stock Return ****************************************/


	public function add_stock_return()
	{

		$stock = $this->db->query("SELECT * FROM lpo");
		$data['stock'] = $stock->result();
		$data['sales_count'] = $this->Sales_model->getSalesCount();

		$this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
        $this->load->view('stock_return/add_stock_return',$data);
        $this->load->view('parts/footer');
	}


    public function save_stock_return(){
    
    	    $data['product'] = $this->input->post('product');
            $data['sku'] = $this->input->post('sku');
            $data['product_qty'] = $this->input->post('product_qty');
            $data['po_number'] = $this->input->post('po_number');
            $data['supplier_name'] = $this->input->post('supplier_name');
            $data['selling_price'] = $this->input->post('selling_price');
            $data['remark'] = $this->input->post('remark');
     
            $data['total_selling_pricing'] = $this->input->post('total_selling_pricing');


            $vstock_qty = $this->Product_Return_model->getstocksqty($data['sku']);

            $vlstock_qty = $this->Product_Return_model->getstocksqtyss($data['po_number']);

            $vlstock_price = $this->Product_Return_model->getstockspricess($data['po_number']);

            $price_total = $vlstock_price - $data['total_selling_pricing'];

            $qty_newss=$vlstock_qty - $data['product_qty'];

            $qty_new=$vstock_qty - $data['product_qty'];

            if ($qty_newss < 0){
                $this->session->set_flashdata('error', ' Not enough Quantity in Stock ');
                redirect("StockClearence/add_stock_return");
                exit();
            }
            if ($qty_new < 0){
    
                 $this->session->set_flashdata('error', ' Not enough Quantity in Stock ');
                redirect("StockClearence/add_stock_return");
                exit();
    
            }
    
            if($qty_new == 0 ){
                $status="Out of stock";
            }
            else{
                $status="In Stock";
            }


            if($qty_newss == 0 ){
                $status="Out of stock";
            }
            else{
                $status="In Stock";
            }

    
            $updatedata = [
                'item_quantity'=>$qty_new,
                'stock_status'=>$status,
    
            ];

            $updatedatass = [
                'item_quantity'=>$qty_newss,
                'stock_status'=>$status,
                'total_cost_price'=>$price_total,
    
            ];

    
            $stock_qty = $this->Product_Return_model->updateStockQty($data['sku'],$updatedata);

            $stock_qtyss = $this->Product_Return_model->updateStockQtyss($data['po_number'],$updatedatass);

    	    $result = $this->db->insert("stock_return",$data);

        if ($result) {
    	// $this->session->set_flashdata('success', 'Your success message here.');

    	// redirect("StockClearence/add_stock_return");



        $invoice_number = $data['po_number'];

        $datax['invoice_number'] = $invoice_number;

        $saless = $this->db->query("SELECT * FROM `stock_return` WHERE `po_number`='$invoice_number'");

        $datax['lpo'] = $saless->result();

        $datax['lpo2'] = $saless->result();

        $this->load->view("invoice/p_invoice",$datax);

        }
        else {
            echo "Something went wrong";
            exit();
        }
    }


       public function sku() {
        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];
        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `product_sku` FROM lpo WHERE po_number = ?", array($pid));
        $data=$stock_query->result();
        $d= $data[0]->product_sku;
        echo $d;

    }

       public function purchace_date() {
        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];
        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `purchace_date` FROM lpo WHERE po_number = ?", array($pid));
        $data=$stock_query->result();
        $d= $data[0]->purchace_date;
        echo $d;

    }


       public function item_selling_price() {
        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];
        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `item_selling_price` FROM lpo WHERE po_number = ?", array($pid));
        $data=$stock_query->result();
        $d= $data[0]->item_selling_price;
        echo $d;

    }

    public function item_price() {
        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];
        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `item_price` FROM lpo WHERE po_number = ?", array($pid));
        $data=$stock_query->result();
        $d= $data[0]->item_price;
        echo $d;

    }

    public function product() {
        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];
        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `item_name` FROM lpo WHERE po_number = ?", array($pid));
        $data=$stock_query->result();
        $d= $data[0]->item_name;
        echo $d;
    }

    public function supplier_name() {
        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];
        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `supplier_name` FROM lpo WHERE po_number = ?", array($pid));
        $data=$stock_query->result();
        $d= $data[0]->supplier_name;
        echo $d;

    }


    


    public function view_return(){

    //view_return

    	$stock_return = $this->db->query("SELECT * FROM `stock_return`");
		$data['_return'] = $stock_return->result();
        $data['sales_count'] = $this->Sales_model->getSalesCount();

    	$this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
        $this->load->view('stock_return/view_return', $data);
        $this->load->view('parts/footer');


    }

public function delete_StockClearence($id){

    $q = $this->db->query("DELETE FROM `stock_return` WHERE `stock_return`.`id` = $id");

    if ($q) {
        // Item deleted successfully
        $this->session->set_flashdata('success', 'Item deleted successfully.');
          redirect("StockClearence/view_return");
    } else {
        // Unable to delete item
        $this->session->set_flashdata('error', 'Item not found or could not be deleted.');
          redirect("StockClearence/view_return");
    }

  
}




    




}
