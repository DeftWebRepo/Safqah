<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends CI_Controller {

	public function __construct() {
		/*call CodeIgniter's default Constructor*/
		parent::__construct();

		/*load model*/
	
        $this->load->model('Category_model');
		$this->load->model('Products_model');
        
	}

	public function index()
	{
	
		$data['categories'] = $this->Category_model->getCategories();
		
		$this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
        $this->load->view('AddProducts',$data);
        $this->load->view('parts/footer');

	}
	public function add()
	{
        
       
		$data['categories'] = $this->Category_model->getCategories();
		

		$this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
		$this->load->view('AddProducts',$data);
        $this->load->view('parts/footer');
	}

    public function save()
	{
		
		// var_dump($_POST);

		 $product_name=$this->input->post('product_name');
		 $product_sku=$this->input->post('product_sku');
		 $product_category=$this->input->post('product_category');
         $cost_price=$this->input->post('cost_price');
         $selling_price=$this->input->post('selling_price');
		 $data = [

			'product_name'=> $product_name,
			'product_sku'=> $product_sku,
			'product_category'=> $product_category,
            'cost_price'=> $cost_price,
            'selling_price'=> $selling_price,
            
		];

		$result = $this->Products_model->save($data);

		if($result) {

            $this->session->set_flashdata('success', 'Data Saved !');
			redirect('Products/add');
			
			
		} else {
			echo "Something went wrong";
			exit();
		}


	}

	public function view() {

        $data['products'] = $this->Products_model->getProductData();
        
       
        $this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
        $this->load->view('viewProducts', $data);
        $this->load->view('parts/footer');
    }


    public function edit($Pid) {
        // Load the stock model
   
    
       // Get the item details for editing
        $data['item'] = $this->Products_model->getProductItem($Pid);
		$data['categories'] = $this->Category_model->getCategories();
		
    
        if ($data['item']) {

            $this->load->view('parts/header');
            $this->load->view('parts/nav');
            $this->load->view('parts/aside',$data);
            $this->load->view('editProducts', $data);
            $this->load->view('parts/footer');
           // Load the view for editing an item
           
        } else {
           // Item not found, show an error message
            $this->session->set_flashdata('error', 'Item not found.');
            redirect('Products/view');
        }
    }

    public function update($Pid) {
    
        $product_name=$this->input->post('product_name');
        $product_sku=$this->input->post('product_sku');
        $product_category=$this->input->post('product_category');
        $cost_price=$this->input->post('cost_price');
        $selling_price=$this->input->post('selling_price');

      $updatedData = [
        'product_name'=> $product_name,
        'product_sku'=> $product_sku,
        'product_category'=> $product_category,
        'cost_price'=> $cost_price,
        'selling_price'=> $selling_price,
       ];

    
        // Update the item in the database
        $this->Products_model->updateProduct($Pid, $updatedData);
    
        // Set a success message
        $this->session->set_flashdata('success', 'Item updated successfully.');
    
        // Redirect to the stock listing page
        redirect('Products/view');
    }


	public function delete($Pid) {
        // Load the stock model
        $this->load->model('Products_model');
    
        // Check if the item with the given $pid exists
        $item = $this->Products_model->getProductItem($Pid);
        if ($item) {
            // Item exists, proceed with deletion
            $this->Products_model->deleteProductItem($Pid);
            $this->session->set_flashdata('success', 'Item deleted successfully.');
        } else {
            // Item does not exist
            $this->session->set_flashdata('error', 'Item not found.');
        }
    
        // Redirect to the stock listing page
        redirect('Products/view');
    }


 }
