<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Shoptowarehouse extends CI_Controller
{

    public function __construct()
    {
        /*call CodeIgniter's default Constructor*/
        parent::__construct();

        /*load model*/
 
    
        $this->load->model('Shoptowarehouse_model');
        $this->load->model('Sales_model');
        $this->load->model('Category_model');
        $this->load->model('Customer_model');
        $this->load->model('Supplier_model');
        $this->load->model('Vehicle_model');
        $this->load->model('Stocktransfer_model');
        $this->load->model('Stock_model');
    }

    public function index()
    {

        echo "";
    }
    public function getcategorystocksss(){
        $category = $this->input->post('category');
        $result = $this->Stock_model->getstockssssss($category);
        echo json_encode($result);


    }
    public function getProductdetails(){
        
        $selectedValue = $this->input->post('selectedValue');
        $result = $this->Stock_model->getStockItemsssss($selectedValue);
        echo json_encode($result);
    }

    public function add()
    {

        
        $data['categories'] = $this->Category_model->getCategories();
        $data['sales_count'] = $this->Sales_model->getSalesCount();
        $this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside', $data);
        $this->load->view('shoptowarehouse',$data);
        $this->load->view('parts/footer');
    }

    public function save(){

        $product_category=$this->input->post('product_category');
        $product_name =$this->Stocktransfer_model->getproductnamessss($this->input->post('product_name'));
        $model_number = $this->input->post('model_number');
        $cost_price = $this->input->post('cost_price');
        $selling_price = $this->input->post('selling_price');
        $quantity = $this->input->post('quantity');
        $total_price = $this->input->post('total_price');
        $transferred_on = $this->input->post('transferred_on');

        $data = [
            
            'product_category' => $product_category,
            'product_name' => $product_name,
            'model_number' => $model_number,
            'cost_price' => $cost_price,
            'transferred_on' => $transferred_on,
            'total_price' => $total_price,
            'selling_price' => $selling_price,
            'quantity' => $quantity,
        ];
        
        $vvstock_qty = $this->Stocktransfer_model->getstocksqtytyssss($model_number);

        $qty_news=$vvstock_qty - $quantity;
        

        $v2shop_price =$this->Stocktransfer_model->get_shopl_pricess($model_number);


        $vvshop_price = $v2shop_price - $total_price;
        

        // $qty_news=$vvstock_qty - $quantity;

        if ($qty_news < 0){

            $this->session->set_flashdata('error', ' Not enough Quantity in Stock ');
            redirect("Shoptowarehouse/add");
            exit();

        }

        if($qty_news == 0 ){
            $status="Out of stock";
        }
        else{
            $status="In Stock";
        }

        $updatedata = [
            'quantity'=>$qty_news,
            'stock_status'=>$status,
            'total_price'=>$vvshop_price

        ];

        $this->Stocktransfer_model->updateshopQtysssss($model_number,$updatedata);

        $stocks_qty = $this->Stocktransfer_model->getshopstyu($model_number);

         $qty_stock = $stocks_qty + $quantity;

        $updatedata_to = [
            'item_quantity'=>$qty_stock,
        ];
             

        $this->Stocktransfer_model->updateshopdetqtys($model_number,$updatedata_to);




        $result = $this->db->insert('shoptowarehouse',$data);
        if($result) {


            $this->session->set_flashdata('success', 'Data Saved !');
             redirect("Shoptowarehouse/add");
 
             
         } else {
             echo "Something went wrong";
             exit();
         }
 
 
    }

    public function view()
    {

        $stock = $this->db->query("SELECT * FROM `shoptowarehouse`");
        $data['back_to_stock'] = $stock->result();

        $this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside', $data);
        $this->load->view('viewshoptowarehouse',$data);
        $this->load->view('parts/footer');
    }


    

    public function get_sku()
    {

        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];

        // Run the query to fetch stock information
        $sql = "SELECT `product_sku` FROM `shoptowarehouse` WHERE `item_name`='$pid';";

        $stock_query = $this->db->query($sql);

        $data = $stock_query->result();

        $d = $data[0]->product_sku;

        echo $d;
    }

   
   


    public function delete($id)
    {

        $id = $id;
        $this->db->where("id", $id);
        $this->db->delete("shoptowarehouse");

        $this->session->set_flashdata('success', 'Item Deleted successfully.');

        redirect("Shoptowarehouse/view");
    }
}
