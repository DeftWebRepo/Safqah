<?php
defined('BASEPATH') or exit('No direct script access allowed');

class ProfitPercentage extends CI_Controller
{

    public function __construct()
    {
        /*call CodeIgniter's default Constructor*/
        parent::__construct();

        /*load model*/
        $this->load->model('Profitpercentage_model');
        $this->load->model('Sales_model');
    }

    public function index()
    {
    }
    public function add()
    {

        $data['sales'] = $this->Sales_model->getSalesData();

        $this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside', $data);
        $this->load->view('profit');
        $this->load->view('parts/footer');
    }

    public function save()
    {
        $invoice_number = $this->input->post("invoice_number");
        $customer_name = $this->input->post("customer_name");
        $product_name = $this->input->post("product_name");
        $sku = $this->input->post("sku");
        $product_qty = $this->input->post("product_qty");
        $product_cost = $this->input->post("product_cost");
        $selling_price = $this->input->post("selling_price");
        $profit = $this->input->post("profit");
        $total_price = $this->input->post("total_price");


        $data = [
            'invoice_number' => $invoice_number,
            'customer_name' => $customer_name,
            'product_name' => $product_name,
            'sku' => $sku,
            'product_qty' => $product_qty,
            'product_cost' => $product_cost,
            'selling_price' => $selling_price,
            'profit' => $profit,
            'total_price' => $total_price,
        ];



        $this->db->insert('profit', $data);

        $this->session->set_flashdata('success', 'Data Saved !');

        redirect('ProfitPercentage/add', 'refresh');
    }

    public function view()
    {

        $query = $this->db->query("SELECT * FROM `profit`");
        $data['finance'] = $query->result();
        $this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside', $data);
        $this->load->view('viewprofit', $data);
        $this->load->view('parts/footer');
    }

    /*public function edit($id) {
        // Load the stock model
       // Get the item details for editing
        $data['item'] = $this->Shoptovehicle_model->getVehicleItem($id);
        $data['sales_count'] = $this->Sales_model->getSalesCount();
        if ($data['item']) {

            $this->load->view('parts/header');
            $this->load->view('parts/nav');
            $this->load->view('parts/aside',$data);
            $this->load->view('editVehicle', $data);
            $this->load->view('parts/footer');
           // Load the view for editing an item          
        } else {
           // Item not found, show an error message
            $this->session->set_flashdata('error', 'Item not found.');
            redirect('vehicle/view');
        }
    }*/


    public function get_sales_product_sku()
    {
        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];

        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `sku` FROM sales WHERE invoice_no = ?", array($pid));
        $data = $stock_query->result();

        // Check if any result is returned
        if (!empty($data)) {
            $sku = $data[0]->sku;
            echo $sku;
        } else {
            echo 'SKU not found'; // Handle the case when no SKU is found
        }
    }


    public function get_sales_item_price()
    {
        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];
        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `product_cost` FROM sales WHERE invoice_no = ?", array($pid));
        $data = $stock_query->result();
        $d = $data[0]->product_cost;
        echo $d;
    }

    public function get_sales_item_selling_price()
    {
        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];
        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `selling_price` FROM sales WHERE invoice_no = ?", array($pid));
        $data = $stock_query->result();
        $d = $data[0]->selling_price;
        echo $d;
    }
    public function get_sales_customer_name()
    {
        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];
        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `customer_name` FROM sales WHERE invoice_no = ?", array($pid));
        $data = $stock_query->result();
        $d = $data[0]->customer_name;
        echo $d;
    }
    public function get_sales_product_name()
    {
        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];
        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `product_name` FROM sales WHERE invoice_no = ?", array($pid));
        $data = $stock_query->result();
        $d = $data[0]->product_name;
        echo $d;
    }
    public function get_sales_item_quantity()
    {
        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];
        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `product_qty` FROM sales WHERE invoice_no = ?", array($pid));
        $data = $stock_query->result();
        $d = $data[0]->product_qty;
        echo $d;
    }

    public function get_sales_total_price()
    {
        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];
        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `total_price` FROM sales WHERE invoice_no = ?", array($pid));
        $data = $stock_query->result();
        $d = $data[0]->total_price;
        echo $d;
    }
    public function delete_profit($id)
    {


        $stock_query = $this->db->query("DELETE FROM `profit` WHERE `profit`.`id` ='$id'");



        $this->session->set_flashdata('danger', 'Deleted Record !');


        redirect('ProfitPercentage/view', 'refresh');
    }
}
