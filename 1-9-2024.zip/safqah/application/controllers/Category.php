<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category extends CI_Controller {

    public function __construct() {
		/*call CodeIgniter's default Constructor*/
		parent::__construct();

		/*load model*/
		$this->load->model('Category_model');
        $this->load->model('Sales_model');
	}

   
    public function index() {
        $data['sales_count'] = $this->Sales_model->getSalesCount();
        $this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
        $this->load->view('add_category');
        $this->load->view('parts/footer');
    }
    
    //   public function add() {
    //     $this->load->view('parts/header');
    //     $this->load->view('parts/nav');
    //     $this->load->view('parts/aside');
    //     $this->load->view('addStock');
    //     $this->load->view('parts/footer');
    // }
    
    public function save(){


       $name=$this->input->post("name");
     
     
   
       $data = [
           'name'=> $name,
       

       ];



       $existingCategory = $this->db->where('name',$name)
       ->get('category')
       ->row();

   if ($existingCategory) {
       // Category already exists, show a JavaScript alert
       $this->session->set_flashdata('error', 'Category already exists!');
       redirect('category');
      
   } else {
       // Category does not exist, proceed with the insertion
       $result = $this->Category_model->save($data);
       if($result) {
        
       
        $this->session->set_flashdata('success', 'Data Saved !');
        redirect('category');

       } else {
        
           exit();
       }

       return true;
   }




      
    }

    public function view() {

        $data['stock'] = $this->Category_model->getStockData();
       

        $data['sales_count'] = $this->Sales_model->getSalesCount();

        $this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
        $this->load->view('view_category', $data);
        $this->load->view('parts/footer');
    }


    public function edit($pid) {
        // Load the stock model
       
        // Get the item details for editing
        $data['item'] = $this->Category_model->getStockItem($pid);

        $data['sales_count'] = $this->Sales_model->getSalesCount();
    
        if ($data['item']) {

           

            $this->load->view('parts/header');
            $this->load->view('parts/nav');
            $this->load->view('parts/aside',$data);
            $this->load->view('edit_category', $data);
            $this->load->view('parts/footer');
            // Load the view for editing an item
           
        } else {
            // Item not found, show an error message
            $this->session->set_flashdata('error', 'Item not found.');
            redirect('category/view');
        }
    }
    


    public function delete($pid) {
        // Load the stock model
      
        // Check if the item with the given $pid exists
        $item = $this->Category_model->getStockItem($pid);
        if ($item) {
            // Item exists, proceed with deletion
            $this->Category_model->deleteStockItem($pid);
            $this->session->set_flashdata('success', 'Item deleted successfully.');
        } else {
            // Item does not exist
            $this->session->set_flashdata('error', 'Item not found.');
        }
    
        // Redirect to the stock listing page
        redirect('category/view');
    }

    public function create_seo_friendly_url($text) {
        // Convert the text to a URL-friendly format
        $seo_url = url_title($text, 'dash', true);
    
        return $seo_url;
    }

    public function update($cid) {
    
        $name=$this->input->post("name");
      
    
        $data = [
            'name'=> $name,
        
        ];
    
        // Update the item in the database
        $this->Category_model->updateStockItem($cid, $data);
    
        // Set a success message
        $this->session->set_flashdata('success', 'Item updated successfully.');
    
        // Redirect to the stock listing page
        redirect('category/view');
    }


 
}
