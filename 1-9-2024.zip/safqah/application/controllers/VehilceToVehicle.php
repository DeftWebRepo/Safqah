<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class VehilceToVehicle extends CI_Controller {

	public function __construct() {
		/*call CodeIgniter's default Constructor*/
		parent::__construct();

		/*load model*/
		$this->load->model('Vehicle_model');
        $this->load->model('Sales_model');
	}

    public function index()
	{
		
	
		// $this->load->view('parts/header');
        // $this->load->view('parts/nav');
        // $this->load->view('parts/aside');
        // $this->load->view('Addvehicle');
        // $this->load->view('parts/footer');

        echo "test";



	}
	public function add()
	{
		$data['sales_count'] = $this->Sales_model->getSalesCount();
		$this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
		$this->load->view('Addvehicle');
        $this->load->view('parts/footer');
	}

    public function save()
	{
		

        $formname= $this->input->post('vehicle_from_name');
        $toname=$this->input->post('vehicle_from_to');

        if($formname=="SAFQAH"){

            $product_datas = array(
                'vehicle_from_name' => $this->input->post('vehicle_from_name'),
                'vehicle_from_to' => $this->input->post('vehicle_from_to'),
                'product_category' => $this->input->post('product_category'),
                'model_number' => $this->input->post('model_number'),
                 'product_name' => $this->Vehicle_model->getproductnamess($this->input->post('product_name')),
                  'cost_price' => $this->input->post('cost_price'),
                   'selling_price' => $this->input->post('selling_price'),
                    'quantity' => $this->input->post('quantity'),

                     'total_price' =>$this->input->post('selling_price')*$this->input->post('quantity'),
                      'transferred_on' => $this->input->post('transferred_on')
            
            
            );

            $vstocks_qty = $this->Vehicle_model->getstocksqtyss($product_datas['model_number'],$product_datas['product_name']);
            $vstocks_cost_price = $this->Vehicle_model->getstocksqtysss($product_datas['model_number'],$product_datas['product_name']);

            


            $cost=$this->input->post('quantity')*$this->input->post('cost_price');

            $margins=$vstocks_cost_price - $cost;

 
             $qty_newss=$vstocks_qty - $product_datas['quantity'];

            // echo $vstocks_qty;
            // echo $qty_newss;
            // exit();


                        if ($qty_newss < 0){
    
                            $this->session->set_flashdata('error', ' Not enough Quantity in Stock ');
                            redirect("StockTransfer/vehicletovehicle");
                            exit();
                
                        }
                
                        if($qty_newss == 0 ){
                            $status="Out of stock";
                        }
                        else{
                            $status="In Stock";
                        }

                        $updatedatas = [
                                        'item_quantity'=>$qty_newss,
                                        'stock_status'=>$status,
                                        'total_cost_price'=>$margins
                            
                                    ];
                        
                        
                     $stocks_qtys = $this->Vehicle_model->updateStockQtyss($product_datas['model_number'],$product_datas['product_name'],$updatedatas);  

                     $this->session->set_flashdata('success', 'Data Saved !');   
                     
                     

                    //  $get_vehicle_to_qtyss=$this->Vehicle_model->get_vehicle_to_qtys($product_datas['model_number'],$product_datas['vehicle_from_to'],$product_datas['product_name']);
                    //  $get_vehicle_to_pricess=$this->Vehicle_model->get_vehicle_to_prices($product_datas['model_number'],$product_datas['vehicle_from_to'],$product_datas['product_name']);

                    //  $to_qty_new=$get_vehicle_to_qtyss + $product_datas['quantity'];

                    //  $to_margin=$get_vehicle_to_pricess + $product_datas['total_price'];

                     $condition = array(
                                    'model_number' => $product_datas['model_number'],
                                    'vehicle_from_to' => $product_datas['vehicle_from_to'],
                                    'product_name' => $product_datas['product_name'],
        
                    
                                );

                                $hai = $this->db->get_where('vehicle_to_vehicle', $condition);
            
                                        if ($hai->num_rows() > 0) {
                                            // If the record exists, update quantity and total price
                                            $get_vehicle_to_qty = $this->Vehicle_model->get_vehicle_to_qtys($product_datas['model_number'], $product_datas['vehicle_from_to'],$product_datas['product_name']);
                                            $get_vehicle_to_price = $this->Vehicle_model->get_vehicle_to_prices($product_datas['model_number'], $product_datas['vehicle_from_to'],$product_datas['product_name']);
                            
                                            $get_selling_price = $this->Vehicle_model->get_selling_prices($product_datas['model_number'], $product_datas['vehicle_from_to'],$product_datas['product_name']);
                                            $get_cost_price = $this->Vehicle_model->get_cost_prices($product_datas['model_number'], $product_datas['vehicle_from_to'],$product_datas['product_name']);
                                        
                                            
                            
                                            if ($get_selling_price != $product_datas['selling_price']){
                                                        $to_qty_new = $get_vehicle_to_qty + $product_datas['quantity'];
                                                        $sells =  $product_datas['selling_price'] *  $product_datas['quantity'] ;
                                                        $to_margin =  $sells + $product_datas['total_price'] ;
                            
                                                        $to_supdatedata = [
                                                            'quantity' => $to_qty_new,
                                                            'total_price' => $to_margin,
                                                            'cost_price' => $product_datas['cost_price'],
                                                            'selling_price' => $product_datas['selling_price'],
                                                        ];
                                                }
                                                else{
                                                    $to_qty_new = $get_vehicle_to_qty + $product_datas['quantity'];
                                                    $to_margin = $get_vehicle_to_price + $product_datas['total_price'];
                            
                                                    $to_supdatedata = [
                                                        'quantity' => $to_qty_new,
                                                        'total_price' => $to_margin,
                
                                                    ];
                                                }
                                        

                
                                                
                                            // Update the existing record in the 'stock_to_vehicle' table
                                            $stock_qtys = $this->Vehicle_model->to_updateStockQtyss($product_datas['model_number'],$product_datas['vehicle_from_to'],$product_datas['product_name'],$to_supdatedata);
                                        } else {
                                            // If the record does not exist, insert a new recor
                                            // Insert a new record in the 'stock_to_vehicle' table
                                            $this->db->insert('vehicle_to_vehicle', $product_datas);
                                        }


         }
        else if($toname=="SAFQAH"){

            $product_data = array(
                'vehicle_from_name' => $this->input->post('vehicle_from_name'),
                'vehicle_from_to' => $this->input->post('vehicle_from_to'),
                'product_category' => $this->input->post('product_category'),
                'model_number' => $this->input->post('model_number'),
                 'product_name' => $this->Vehicle_model->getproductnames($this->input->post('product_name')),
                  'cost_price' => $this->input->post('cost_price'),
                   'selling_price' => $this->input->post('selling_price'),
                    'quantity' => $this->input->post('quantity'),

                     'total_price' =>$this->input->post('selling_price')*$this->input->post('quantity'),
                      'transferred_on' => $this->input->post('transferred_on')
            
            
            );

            $vstocks_qty = $this->Vehicle_model->getstocksqtyss($product_data['model_number'],$product_data['product_name'],);
            $vstocks_cost_price = $this->Vehicle_model->getstocksqtysss($product_data['model_number'],$product_data['product_name']);

            


            $cost=$this->input->post('quantity')*$this->input->post('cost_price');

            $margins=$vstocks_cost_price + $cost;

 
             $qty_newss=$vstocks_qty + $product_data['quantity'];

            // echo $vstocks_qty;
            // echo $qty_newss;
            // exit();


                        if ($qty_newss < 0){
    
                            $this->session->set_flashdata('error', ' Not enough Quantity in Stock ');
                            redirect("StockTransfer/vehicletovehicle");
                            exit();
                
                        }
                
                        if($qty_newss == 0 ){
                            $status="Out of stock";
                        }
                        else{
                            $status="In Stock";
                        }

                        $updatedatasss = [
                                        'item_quantity'=>$qty_newss,
                                        'stock_status'=>$status,
                                        'total_cost_price'=>$margins
                            
                                    ];
                        
                        
                     $stocks_qtys = $this->Vehicle_model->updateStockQtysss($product_data['model_number'],$product_data['product_name'],$updatedatasss);  

                     $this->session->set_flashdata('success', 'Data Saved !'); 
                     
                     

                     $condition = array(
                        'model_number' => $product_data['model_number'],
                        'vehicle_from_to' => $product_data['vehicle_from_name'],
                        'product_name' => $product_data['product_name'],

        
                    );

                    $hai = $this->db->get_where('vehicle_to_vehicle', $condition);

                            if ($hai->num_rows() > 0) {
                                // If the record exists, update quantity and total price
                                $get_vehicle_to_qty = $this->Vehicle_model->get_vehicle_to_qtysss($product_data['model_number'], $product_data['vehicle_from_name'],$product_data['product_name']);
                                $get_vehicle_to_price = $this->Vehicle_model->get_vehicle_to_pricesss($product_data['model_number'], $product_data['vehicle_from_name'],$product_data['product_name']);
                
                                $get_selling_price = $this->Vehicle_model->get_selling_prices($product_data['model_number'], $product_data['vehicle_from_name'],$product_data['product_name']);
                                $get_cost_price = $this->Vehicle_model->get_cost_prices($product_data['model_number'], $product_data['vehicle_from_name'],$product_data['product_name']);
                             
                                
                                
                                if ($get_selling_price != $product_data['selling_price']){
                                            $to_qty_new =$product_data['quantity'] - $get_vehicle_to_qty ;
                                            $sells =  $product_data['selling_price'] * $product_data['quantity'] ;
                                            $to_margin = $product_data['total_price'] - $sells ;
                
                                            $to_supdatedatass = [
                                                'quantity' => $to_qty_new,
                                                'total_price' => $to_margin,
                                                'cost_price' => $product_data['cost_price'],
                                                'selling_price' => $product_data['selling_price'],
                                            ];
                                            // echo $to_qty_new;
                                            // echo $to_margin;
                                            // exit();
                                        }else{
                                
                                        $to_qty_new = $get_vehicle_to_qty - $product_data['quantity'];
                                        $to_margin = $get_vehicle_to_price - $product_data['total_price'];
                
                                        $to_supdatedatass = [
                                            'quantity' => $to_qty_new,
                                            'total_price' => $to_margin,
                                          
                                        ];
                                        // echo $to_qty_new;
                                        // echo $to_margin;
                                        // exit();
                                  
                            

                                  

                                    }    
                                // Update the existing record in the 'stock_to_vehicle' table
                                     $stock_qtys = $this->Vehicle_model->to_updateStockQtyssss($product_data['model_number'],$product_data['vehicle_from_name'],$product_data['product_name'],$to_supdatedatass);

       
        }
    }
        else{


            $product_datass = array(
                'vehicle_from_name' => $this->input->post('vehicle_from_name'),
                'vehicle_from_to' => $this->input->post('vehicle_from_to'),
                'product_category' => $this->input->post('product_category'),
                'model_number' => $this->input->post('model_number'),
                 'product_name' => $this->Vehicle_model->getproductnames($this->input->post('product_name')),
                  'cost_price' => $this->input->post('cost_price'),
                   'selling_price' => $this->input->post('selling_price'),
                    'quantity' => $this->input->post('quantity'),
                     'total_price' =>$this->input->post('selling_price')*$this->input->post('quantity'),
                      'transferred_on' => $this->input->post('transferred_on')
            
            
            );


            $vstock_qty = $this->Vehicle_model->getstocksqty($product_datass['model_number'],$product_datass['vehicle_from_name'],$product_datass['product_name']);

            $getstock_price=$this->Vehicle_model->getstock_price($product_datass['model_number'],$product_datass['vehicle_from_name'],$product_datass['product_name']);

            $get_vehicle_to_qty=$this->Vehicle_model->get_vehicle_to_qty($product_datass['model_number'],$product_datass['vehicle_from_to'],$product_datass['product_name']);

                    $get_vehicle_to_price=$this->Vehicle_model->get_vehicle_to_price($product_datass['model_number'],$product_datass['vehicle_from_to'],$product_datass['product_name']);
        
        
                    $margin=$getstock_price - $product_datass['total_price'];
        
        
                     $qty_new=$vstock_qty - $product_datass['quantity'];
        
                    // echo $margin;
                    // echo $qty_new;
                    // echo $vstock_qty;
                    // echo $getstock_price;
                    // exit();
        
                    //  if ($to_qty_new < 0){
            
                    //     $this->session->set_flashdata('error', ' Not enough Quantity in Stock ');
                    //     redirect("StockTransfer/vehicletovehicle");
                    //     exit();
            
                    // }
        
        
            
                    if ($qty_new < 0){
            
                        $this->session->set_flashdata('error', ' Not enough Quantity in Stock ');
                        redirect("StockTransfer/vehicletovehicle");
                        exit();
            
                    }
            
                    if($qty_new == 0 ){
                        $status="Out of stock";
                    }
                    else{
                        $status="In Stock";
                    }
            
                    $updatedata = [
                        'quantity'=>$qty_new,
                        'stock_status'=>$status,
                        'total_price'=>$margin
            
                    ];
        
                    // $get_vehicle_to_qty=$this->Vehicle_model->get_vehicle_to_qty($product_data['model_number'],$product_data['vehicle_from_to']);
        
                    // $get_vehicle_to_price=$this->Vehicle_model->get_vehicle_to_price($product_data['model_number'],$product_data['vehicle_from_to']);
        
                    // $to_qty_new=$get_vehicle_to_qty + $product_data['quantity'];
        
                    // $to_margin=$get_vehicle_to_price + $product_data['total_price'];
        
        
                    $condition = array(
                        'model_number' => $product_datass['model_number'],
                        'vehicle_from_to' => $product_datass['vehicle_from_to'],
                        'product_name' => $product_datass['product_name'],
        
                    );
                    
                    // Check if the record already exists in the 'stock_to_vehicle' table
                    $hai = $this->db->get_where('vehicle_to_vehicle', $condition);
                    
                    if ($hai->num_rows() > 0) {
                        // If the record exists, update quantity and total price
                        $get_vehicle_to_qty = $this->Vehicle_model->get_vehicle_to_qty($product_datass['model_number'], $product_datass['vehicle_from_to'],$product_datass['product_name']);
                        $get_vehicle_to_price = $this->Vehicle_model->get_vehicle_to_price($product_datass['model_number'], $product_datass['vehicle_from_to'],$product_datass['product_name']);
        
                        $get_selling_price = $this->Vehicle_model->get_selling_price($product_datass['model_number'], $product_datass['vehicle_from_to'],$product_datass['product_name']);
                        $get_cost_price = $this->Vehicle_model->get_cost_price($product_datass['model_number'], $product_datass['vehicle_from_to'],$product_datass['product_name']);
                    
                        
        
                        if ($get_selling_price != $product_data['selling_price']){
                                    $to_qty_new = $get_vehicle_to_qty + $product_datass['quantity'];
                                    $sells =  $product_datass['selling_price'] *  $product_datass['quantity'] ;
                                    $to_margin =  $sells + $product_datass['total_price'] ;
        
                                    $to_supdatedata = [
                                        'quantity' => $to_qty_new,
                                        'total_price' => $to_margin,
                                        'cost_price' => $product_datass['cost_price'],
                                        'selling_price' => $product_datass['selling_price'],
                                    ];
                            }
                            else{
                                $to_qty_new = $get_vehicle_to_qty + $product_datass['quantity'];
                                $to_margin = $get_vehicle_to_price + $product_datass['total_price'];
        
                                $to_supdatedata = [
                                    'quantity' => $to_qty_new,
                                    'total_price' => $to_margin,
                                  
                                ];
                            }
                    
                        // Update the existing record in the 'stock_to_vehicle' table
                        $stock_qtys = $this->Vehicle_model->to_updateStockQty($product_datass['model_number'], $product_datass['vehicle_from_to'],$product_datass['product_name'], $to_supdatedata);
                    } else {
                        // If the record does not exist, insert a new record
                        
                        // Insert a new record in the 'stock_to_vehicle' table
                        $this->db->insert('vehicle_to_vehicle', $to_updatedata);
                    }


        }
    

   
          

		    // $this->db->insert('vehicle_to_vehicle',$product_datas);


         


        $this->session->set_flashdata('success', 'Data Saved !');

       redirect('StockTransfer/vehicletovehicle','refresh');
       
	}

    public function view() {

        $query = $this->db->query("SELECT * FROM `vehicle_to_vehicle`");
        $data['warehouse'] = $query->result();
        $data['sales_count'] = $this->Sales_model->getSalesCount();
        $this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
        $this->load->view('view_vehicle_to_vehicle/view_vehicle_to_vehicle', $data);
        $this->load->view('parts/footer');
    }

	public function edit($id) {
        // Load the stock model
       // Get the item details for editing
        $data['item'] = $this->Vehicle_model->getVehicleItem($id);
        $data['sales_count'] = $this->Sales_model->getSalesCount();
        if ($data['item']) {

            $this->load->view('parts/header');
            $this->load->view('parts/nav');
            $this->load->view('parts/aside',$data);
            $this->load->view('editVehicle', $data);
            $this->load->view('parts/footer');
           // Load the view for editing an item          
        } else {
           // Item not found, show an error message
            $this->session->set_flashdata('error', 'Item not found.');
            redirect('vehicle/view');
        }
    }


    public function get_stock_product_sku() {
        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];
        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `product_sku` FROM stock WHERE pid = ?", array($pid));
        $data=$stock_query->result();
        $d= $data[0]->product_sku;
        echo $d;

    }

    public function get_stock_product_skus() {
        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];
        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `product_sku` FROM stock WHERE pid = ?", array($pid));
        $data=$stock_query->result();
        $d= $data[0]->product_sku;
        echo $d;

    }

    public function get_stock_item_price() {
        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];
        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `item_price` FROM stock WHERE pid = ?", array($pid));
        $data=$stock_query->result();
        $d= $data[0]->item_price;
        echo $d;

    }

    public function get_stock_item_selling_price() {
        // Get the product ID from the POST data
        $pid = $_REQUEST['query'];
        // Run the query to fetch stock information
        $stock_query = $this->db->query("SELECT `item_selling_price` FROM stock WHERE pid = ?", array($pid));
        $data=$stock_query->result();
        $d= $data[0]->item_selling_price;
        echo $d;

    }

    public function delete_vehicle( $id ) {


        $stock_query = $this->db->query("DELETE FROM `vehicle_to_vehicle` WHERE `vehicle_to_vehicle`.`id` ='$id'");

        $this->session->set_flashdata('danger', 'Deleted Vehicle !');

        
        redirect('VehilceToVehicle/view','refresh');
        

    }

    public function get_product_names(){

        $product_category=$_REQUEST['product_category'];

        $vehicle_from_name=$_REQUEST['vehicle_from_name'];

   // SQL query to get product names
    $sql = "SELECT `model_number`,`product_name` FROM `vehicle_to_vehicle` WHERE `vehicle_from_to`= '$vehicle_from_name' AND `product_category`='$product_category';";



    // Execute the query
    $query = $this->db->query($sql);

    // Check if the query was successful
    if ($query) {
        // Fetch the result as an array of objects
        $productNames = $query->result();

        // Initialize the Bootstrap Select dropdown
        $select = '<select class="selectpicker temp1 form-control mySelect" name="product_name" onchange="get_vehicle_to_vehicle_product(this.value);" id="productNamesSelect" data-live-search="true">';
          $select .= '<option value="">Please Select</option>';
        // Loop through the product names and add them as options
        foreach ($productNames as $product) {
            $select .= '<option value="' . $product->model_number . '">' . $product->product_name . '</option>';
        }

        // Close the select tag
        $select .= '</select>';

        // Return the HTML for the Bootstrap Select dropdown
        echo  $select;
        
    } else {
        // Return false or handle the error as needed
        return false;
    }



    }



    public function get_product_namess(){

        $product_category=$_REQUEST['product_category'];

        

   // SQL query to get product names
    $sql = "SELECT * FROM `stock` WHERE `category`='$product_category';";



    // Execute the query
    $query = $this->db->query($sql);

    // Check if the query was successful
    if ($query) {
        // Fetch the result as an array of objects
        $productNames = $query->result();

        // Initialize the Bootstrap Select dropdown
        $select = '<select class="selectpicker temp1 form-control mySelect" name="product_name" onchange="get_vehicle_to_vehicle_product(this.value);" id="productNamesSelect" data-live-search="true">';
          $select .= '<option value="">Please Select</option>';
        // Loop through the product names and add them as options
        foreach ($productNames as $product) {
            $select .= '<option value="' . $product->product_sku . '">' . $product->item_name . '</option>';
        }

        // Close the select tag
        $select .= '</select>';

        // Return the HTML for the Bootstrap Select dropdown
        echo  $select;
        
    } else {
        // Return false or handle the error as needed
        return false;
    }



    }





    public function model_number_input(){


        $query=$_REQUEST['query'];

        $this->db->where("model_number",$query);

        echo $this->db->get("vehicle_to_vehicle")->row("model_number");


    }


    public function cost_price(){


        $id=$_REQUEST['query'];

        // $this->db->where("model_number",$query);
        // echo $this->db->get("vehicle_to_vehicle")->row("cost_price");
       // Run the query to fetch stock information


        $stock_query = $this->db->query("SELECT `cost_price` FROM `vehicle_to_vehicle` WHERE `model_number`='$id';");
        $data=$stock_query->result();
        $d= $data[0]->cost_price;
        echo $d;


    }

    public function cost_prices(){


        $id=$_REQUEST['query'];

        // $this->db->where("model_number",$query);
        // echo $this->db->get("vehicle_to_vehicle")->row("cost_price");
       // Run the query to fetch stock information


        $stock_query = $this->db->query("SELECT `item_price` FROM `stock` WHERE `product_sku`='$id';");
        $data=$stock_query->result();
        $d= $data[0]->item_price;
        echo $d;


    }

        public function selling_price_input(){

        $id=$_REQUEST['query'];

        $stock_query = $this->db->query("SELECT `selling_price` FROM `vehicle_to_vehicle` WHERE `model_number`='$id';");
        $data=$stock_query->result();
        $d= $data[0]->selling_price;
        echo $d; 

        }


        public function selling_price_inputs(){

            $id=$_REQUEST['query'];
    
            $stock_query = $this->db->query("SELECT `item_selling_price` FROM `stock` WHERE `product_sku`='$id';");
            $data=$stock_query->result();
            $d= $data[0]->item_selling_price;
            echo $d; 
    
            }
    


    



}