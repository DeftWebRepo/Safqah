<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
    

	public function index()
	{

		
		$this->load->model('Sales_model');
		
		$data['sales_count'] = $this->Sales_model->getSalesCount();
		  if ($this->session->userdata('loggedin') === true) {

		$this->load->view('parts/header');
		$this->load->view('parts/nav');
	     $this->load->view('parts/aside',$data);
		$this->load->view('app/dashboard');
		$this->load->view('parts/dfooter');
       

    } else {
        // User is not logged in, handle accordingly
        // For example, you can redirect to the login page
        redirect('login'); // Replace 'login' with your login route
    }
}
			


}
