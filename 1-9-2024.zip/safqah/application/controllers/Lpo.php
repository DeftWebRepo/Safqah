<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lpo extends CI_Controller {

	public function __construct() {
		/*call CodeIgniter's default Constructor*/
		parent::__construct();

		/*load model*/
		
		$this->load->model('Category_model');
		$this->load->model('Lpo_model');
        $this->load->model('Supplier_model');
	}

	public function index()
	{
		
		$data['categories'] = $this->Category_model->getCategories();
		$data['suppliers'] = $this->Supplier_model->getSuppliers();
		$this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside');
        $this->load->view('AddLpo',$data);
        $this->load->view('parts/footer');

	}
	public function add()
	{
		$data['categories'] = $this->Category_model->getCategories();
		$data['suppliers'] = $this->Supplier_model->getSuppliers();

		$this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside');
		$this->load->view('AddLpo',$data);
        $this->load->view('parts/footer');
	}

    public function save()
	{
		
		// var_dump($_POST);
        $supplier_name=$this->input->post('supplier_name');
        $product_category=$this->input->post('product_category');
        $product_name=$this->Lpo_model->getproductItems($this->input->post('product_name'));
        $product_sku=$this->input->post('product_sku');
		$product_qty=$this->input->post('product_qty');
		$cost_price=$this->input->post('cost_price');
        $total_cost_price=$this->input->post('total_cost_price');
        $purchase_date=$this->input->post('purchase_date');
        $invoice = $this->input->post('invoice');
        $payment=$this->input->post('payment');

		$data = [

            'supplier_name'=>$supplier_name,
			'product_category'=> $product_category,
            'product_name'=>$product_name,
            'product_sku'=>$product_sku,
			'product_qty'=> $product_qty,
			'cost_price'=> $cost_price,
            'total_cost_price'=>$total_cost_price,
            'purchase_date'=> $purchase_date,
            'invoice'=> $invoice,
            'payment'=> $payment,

		];



        $condition = array(
            'product_sku' => $product_sku,
            
           );
        
        // Check if the record already exists in the 'stock_to_vehicle' table
           $hai = $this->db->get_where('lpo', $condition);
        
           if ($hai->num_rows() > 0) {
            // If the record exists, update quantity and total price
            $get_purchase_qty = $this->Lpo_model->get_vehicle_to_qty($product_sku);

            $get_purchase_price = $this->Lpo_model->get_vehicle_to_price($product_sku);
            $get_cost_price = $this->Lpo_model->get_cost_price($product_sku);
    
            
    
                
    
                if ($get_cost_price != $cost_price){
                    $to_qty_new = $get_purchase_qty + $product_qty;
                      $sell =  $cost_price * $product_qty;
                      $to_margin =  $sell + $total_cost_price;
                      $to_supdatedata = [
                        'product_qty' => $to_qty_new,
                        'total_cost_price' => $to_margin,
                        'cost_price'=> $cost_price,
                    ];
                }
                else{
                  $to_qty_new = $get_purchase_qty + $product_qty;
                  $to_margin = $get_purchase_price + $total_cost_price;
                  $to_supdatedata = [
                    'product_qty' => $to_qty_new,
                    'total_cost_price' => $to_margin,
                   
                ];
                }
                
        
               
                        
                            // Update the existing record in the 'stock_to_vehicle' table
                $stock_qtys = $this->Lpo_model->to_updateStockQty($product_sku,$to_supdatedata);
                        
            } 
            else {
                // If the record does not exist, insert a new record
                $to_updatedata = [
                    'supplier_name'=>$supplier_name,
                    'product_category'=> $product_category,
                    'product_name'=>$product_name,
                    'product_sku'=>$product_sku,
                    'product_qty'=> $product_qty,
                    'cost_price'=> $cost_price,
                    'total_cost_price'=>$total_cost_price,
                    'purchase_date'=> $purchase_date,
                    'invoice'=> $invoice,
                    'payment'=> $payment,
                ];
            
                // Insert a new record in the 'stock_to_vehicle' table
                $this->db->insert('lpo', $to_updatedata);
               
            }  
    

            $this->session->set_flashdata('success', 'Data Saved !');
            redirect("Lpo/add");
	

		

	}

	public function view() {

        $data['products'] = $this->Lpo_model->getProductData();
        
        $data['suppliers'] = $this->Supplier_model->getSuppliers();


        $this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside');
        $this->load->view('viewLpo', $data);
        $this->load->view('parts/footer');
    }


    public function edit($id) {
        // Load the stock model
   
    
       // Get the item details for editing
        $data['item'] = $this->Lpo_model->getProductItem($id);
		$data['categories'] = $this->Category_model->getCategories();
	
$data['suppliers'] = $this->Supplier_model->getSuppliers();
    
        if ($data['item']) {

            $this->load->view('parts/header');
            $this->load->view('parts/nav');
            $this->load->view('parts/aside');
            $this->load->view('editLpo', $data);
            $this->load->view('parts/footer');
           // Load the view for editing an item
           
        } else {
           // Item not found, show an error message
            $this->session->set_flashdata('Error', 'Item not found.');
            redirect('Lpo/view');
        }
    }

    public function update($id) {
    
         $product_category=$this->input->post('product_category');
        $product_name=$this->input->post('product_name');
        $product_sku=$this->input->post('product_sku');
        $product_qty=$this->input->post('product_qty');
        $cost_price=$this->input->post('cost_price');
        $total_cost_price=$this->input->post('total_cost_price');
        $delivery_date=$this->input->post('delivery_date');
        $payment=$this->input->post('payment');
   
       $updatedData = [
        'product_category'=> $product_category,
            'product_name'=>$product_name,
            'product_sku'=>$product_sku,
            'product_qty'=> $product_qty,
            'cost_price'=> $cost_price,
            'total_cost_price'=>$total_cost_price,
            'purchase_date'=> $purchase_date,
            'supplier_name'=>$supplier_name,
            'payment'=> $payment,

       ];

    
        // Update the item in the database
        $this->Lpo_model->updateProduct($id, $updatedData);
    
        // Set a success message
        $this->session->set_flashdata('Success', 'Item updated successfully.');
    
        // Redirect to the stock listing page
        redirect('Lpo/view');
    }


	public function delete($id) {
        // Load the stock model
        $this->load->model('Lpo_model');
    
        // Check if the item with the given $pid exists
        $item = $this->Lpo_model->getProductItem($id);
        if ($item) {
            // Item exists, proceed with deletion
            $this->Lpo_model->deleteProductItem($id);
            $this->session->set_flashdata('success', 'Item deleted successfully.');
        } else {
            // Item does not exist
            $this->session->set_flashdata('error', 'Item not found.');
        }
    
        // Redirect to the stock listing page
        redirect('Lpo/view');
    }



    public function getcategorypurchase(){
        $category = $this->input->post('category');
        $result = $this->Lpo_model->getstocks($category);
        echo json_encode($result);


    }

    public function getProductpurchasedetails(){
        
        $selectedValue = $this->input->post('selectedValue');
        $result = $this->Lpo_model->getStockItemspurchase($selectedValue);
        echo json_encode($result);
    }


 }
