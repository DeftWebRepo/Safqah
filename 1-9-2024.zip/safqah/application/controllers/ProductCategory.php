<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProductCategory extends CI_Controller {

    public function __construct() {
        parent::__construct();
        // Load necessary libraries and models here
        // Make sure you load the session library
        $this->load->library('session');
    }

    public function add() {
      
    }

     public function view() {
      
    }

     public function edit() {
      
    }

     public function update() {
      
    }

     public function delete() {
      
    }

   

}
