<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sales extends CI_Controller {

	public function __construct() {
		/*call CodeIgniter's default Constructor*/
		parent::__construct();

		/*load model*/
		$this->load->model('Sales_model');
        $this->load->model('Category_model');
        $this->load->model('Customer_model');
        $this->load->model('Supplier_model');
        $this->load->model('Vehicle_model');
        $this->load->model('Stocktransfer_model');
	}

	public function index(){
        $data['categories'] = $this->Category_model->getCategories();
        $data['suppliers'] = $this->Supplier_model->getSuppliers();
        $data['vehicles'] = $this->Vehicle_model->getVehicleData();
        $data['sales_count'] = $this->Sales_model->getSalesCount();
        $data['customers'] = $this->Customer_model->getCustomers();

		$this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
        $this->load->view('AddSales',$data);
        $this->load->view('parts/footer');

	}
    public function add()
	{
	
        $data['categories'] = $this->Category_model->getCategories();
        $data['customers'] = $this->Customer_model->getCustomers();
        $data['suppliers'] = $this->Supplier_model->getSuppliers();
        $data['vehicles'] = $this->Vehicle_model->getVehicleData();
        $data['customers'] = $this->Customer_model->getCustomers();
        $data['sales_count'] = $this->Sales_model->getSalesCount();

		$this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
		$this->load->view('AddSales',$data);
        $this->load->view('parts/footer');
	}
    public function getcustomer() {
        $this->load->model('Customer_model');
        $selectedValue = $this->input->post('selectedValue');
        $result = $this->Customer_model->getStockItems($selectedValue);
        echo json_encode($result);
    
    }


    public function save()
	{
		
		// var_dump($_POST);

		
		 $invoice_no=$this->input->post('invoice_no');
         $customer_name=$this->Sales_model->getstockCustomerItem($this->input->post('customer_name'));
         $company=$this->input->post('company');
         $vehicle=$this->input->post('vehicle');
       
        $product_name=$this->Sales_model->getstockVehicleItem($this->input->post('product_name'));
		 $category=$this->input->post('category');
         $sku=$this->input->post('sku');

         $cost_price=$this->input->post('cost_price');
         $selling_price=$this->input->post('selling_price');
         $product_qty=$this->input->post('product_qty');
         $transferred_on=$this->input->post('transferred_on');
        
         $total_price=$this->input->post('total_price');

         $total_cost = $cost_price * $product_qty;
        
        


		$data = [
		
			'invoice_no'=> $invoice_no,
            'customer_name'=> $customer_name,
            'company'=> $company,
            'vehicle'=> $vehicle,
            'product_name'=> $product_name,
			
			'category'=> $category,
            'sku'=> $sku,
            'product_cost'=> $cost_price,
            'selling_price'=>$selling_price,
            'product_qty'=> $product_qty,
            'transferred_on'=> $transferred_on,
    
            'total_price'=>$total_price,
            'total_cost'=>$total_cost,
            'payment_terms'=>$this->input->post('payment_terms')
            

		];


        if($selling_price <= $cost_price){

            $this->session->set_flashdata('error', ' Invalid Selling Pricing ');
			redirect("Sales/add");
        
            exit();
        }

        
        // if($vehicle=='shop'){

        //     $vstock_qty = $this->Sales_model->getstockshopqty($sku);

        //      $vshop_price=$this->Sales_model->getstockshop_price($sku);

        //     $shop_price=$vshop_price-$total_price;



        //     $qty_new=$vstock_qty - $product_qty;

        //     if ($qty_new < 0){

        //          $this->session->set_flashdata('error', ' Not enough Quantity in Stock ');
        //          redirect("Sales/add");
        //          exit();

        //     }
  
        //    if($qty_new == 0 ){
        //      $status="Out of stock";
        //    }
        //    else{
        //      $status="In Stock";
        //    }


        //    $updatedatas = [
        //     'quantity'=>$qty_new,
        //     'stock_status'=>$status,
        //     'total_price'=>$shop_price

        //    ];




        //     $stock_qty = $this->Sales_model->updateStockshopQty($sku,$updatedatas);





        // }
        // else{

            $vvstock_qty = $this->Sales_model->getstocksqty($sku,$vehicle);

            // echo $vvstock_qty;
            // exit();
             

             $v2shop_price =$this->Sales_model->get_vehicle_price($sku,$vehicle);

            $vvshop_price = $v2shop_price - $total_price;

            $qty_news=$vvstock_qty - $product_qty;

            if ($qty_news < 0){

                $this->session->set_flashdata('error', ' Not enough Quantity in Stock ');
                redirect("Sales/add");
                exit();

            }

            if($qty_news == 0 ){
                $status="Out of stock";
            }
            else{
                $status="In Stock";
            }


            $updatedata = [
                'quantity'=>$qty_news,
                'stock_status'=>$status,
                 'total_price'=>$vvshop_price

            ];




            $stock_qty = $this->Sales_model->updateStockQty($sku,$vehicle,$updatedata);


        // }

		$result = $this->Sales_model->save($data);

		if($result) {
           // $this->session->set_flashdata('success', 'Data Saved !');
			//redirect("sales/add");


        $invoice_number=$invoice_no;

        $datax['invoice_number']=$invoice_number;

        $saless = $this->db->query("SELECT * FROM `sales` WHERE `invoice_no`='$invoice_number'");

        $datax['sales'] = $saless->result();

        $datax['sales2'] = $saless->result();

        $this->load->view("invoice/invoice",$datax);


			
		} else {
			echo "Something went wrong";
			exit();
		}






	}

    public function view() {

        $data['sales'] = $this->Sales_model->getSalesData();
        $data['customers'] = $this->Customer_model->getCustomers();

        $data['sales_count'] = $this->Sales_model->getSalesCount();

        $this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
        $this->load->view('viewSales', $data);
        $this->load->view('parts/footer');
    }


    public function edit($s_id) {
        // Load the stock model
   
    
       // Get the item details for editing
        $data['item'] = $this->Sales_model->getSalesItem($s_id);
        $data['categories'] = $this->Category_model->getCategories();
        $data['customers'] = $this->Customer_model->getCustomers();
        $data['suppliers'] = $this->Supplier_model->getSuppliers();
        $data['sales_count'] = $this->Sales_model->getSalesCount();
    
        if ($data['item']) {

            $this->load->view('parts/header');
            $this->load->view('parts/nav');
            $this->load->view('parts/aside',$data);
            $this->load->view('editsales', $data);
            $this->load->view('parts/footer');
           // Load the view for editing an item
           
        } else {
           // Item not found, show an error message
            $this->session->set_flashdata('error', 'Item not found.');
            redirect('sales/view');
        }
    }

    public function update($s_id) {
    
        $product_name=$this->input->post('product_name');
        $product_code=$this->input->post('product_code');
        $product_details=$this->input->post('product_details');
        $category=$this->input->post('category');
        $product_cost=$this->input->post('product_cost');
        $product_qty=$this->input->post('product_qty');
        $source=$this->input->post('source');
        $status=$this->input->post('status');
        $sku=$this->input->post('sku');
        $customer_name=$this->input->post('customer_name');
        $company=$this->input->post('company');
        
        $updatedData = [

        'product_name'=> $product_name,
		'product_code'=> $product_code,
		'product_details'=> $product_details,
		'category'=> $category,
        'product_cost'=> $product_cost,
        'product_qty'=> $product_qty,
        'source'=> $source,
        'status'=> $status,
        'sku'=> $sku,
        'customer_name'=> $customer_name,
        'company'=> $company,

    ];

    
        // Update the item in the database
        $this->Sales_model->updateSales($s_id, $updatedData);
    
        // Set a success message
        $this->session->set_flashdata('success', 'Item updated successfully.');
    
        // Redirect to the stock listing page
        redirect('sales/view');
    }

    public function delete($s_id) {
        // Load the stock model
        $this->load->model('Sales_model');
    
        // Check if the item with the given $pid exists
        $item = $this->Sales_model->getSalesItem($s_id);
        if ($item) {
            // Item exists, proceed with deletion
            $this->Sales_model->deleteSalesItem($s_id);
            $this->session->set_flashdata('success', 'Item deleted successfully.');
        } else {
            // Item does not exist
            $this->session->set_flashdata('error', 'Item not found.');
        }
    
        // Redirect to the stock listing page
        redirect('sales/view');
    }

    public function getvehiclesstock(){
		$category =$this->input->post('category');
        $vehicle_number =$this->input->post('vehicle_number');
		$result =$this->Sales_model->getVehicles($category,$vehicle_number);
        echo json_encode($result);
	}
    public function getvehicledetails() {
        $this->load->model('Sales_model');
        $selectedValue = $this->input->post('selectedValue');
        $result = $this->Sales_model->getvehiclesItems($selectedValue);
        echo json_encode($result);
    
    }


      public function get_shop_stock() {
        $category =$this->input->post('category');
        $vehicle_number =$this->input->post('vehicle_number');
        $result =$this->Sales_model->getShop($category,$vehicle_number);
        echo json_encode($result);
    }


      public function getshopdetails() {
        $this->load->model('Sales_model');
        $selectedValue = $this->input->post('selectedValue');
        $result = $this->Sales_model->get_shop_items($selectedValue);
        echo json_encode($result);
    
    }



}