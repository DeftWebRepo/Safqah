<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class StockTransfer extends CI_Controller {

	public function __construct() {
		/*call CodeIgniter's default Constructor*/
		parent::__construct();

		/*load model*/
		$this->load->model('Sales_model');
        $this->load->model('Category_model');
        $this->load->model('Customer_model');
        $this->load->model('Supplier_model');
        $this->load->model('Vehicle_model');
        $this->load->model('Stocktransfer_model');
        $this->load->model('Stock_model');
	}

	public function getcategorystock(){
        $category = $this->input->post('category');
        $result = $this->Stock_model->getstocks($category);
        echo json_encode($result);


    }

    

    public function getProductdetails(){
        
        $selectedValue = $this->input->post('selectedValue');
        $result = $this->Stock_model->getStockItems($selectedValue);
        echo json_encode($result);
    }

    public function warehousetoshop()
	{
		
        $data['categories'] = $this->Category_model->getCategories();
        $data['suppliers'] = $this->Supplier_model->getSuppliers();
        $data['vehicles'] = $this->Vehicle_model->getVehicleData();
        $data['sales_count'] = $this->Sales_model->getSalesCount();

		$this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside', $data);
        $this->load->view('warehousetoshop', $data);
        $this->load->view('parts/footer');

	}

    public function warehousetovehicle()
	{
		
        $data['categories'] = $this->Category_model->getCategories();
        $data['suppliers'] = $this->Supplier_model->getSuppliers();
        $data['vehicles'] = $this->Vehicle_model->getVehicleData();
        $data['sales_count'] = $this->Sales_model->getSalesCount();

		$this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside', $data);
        $this->load->view('warehousetovehicle', $data);
        $this->load->view('parts/footer');

	}
	
	public function vehicletovehicle()
	{

        $vehicle = $this->db->query("SELECT * FROM vehicle");
        $data['vehicle'] = $vehicle->result();

		$stock = $this->db->query("SELECT * FROM stock");
        $data['stock'] = $stock->result();

        $category = $this->db->query("SELECT * FROM category");
        $data['category'] = $category->result();

        $data['sales_count'] = $this->Sales_model->getSalesCount();

		$this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
		$this->load->view('vehicletovehicle',$data);
        $this->load->view('parts/footer');
	}







    public function warehousetoshop_save(){
         
         $product_category=$this->input->post('product_category');
         $product_name=$this->Stocktransfer_model->getWarehouseItem($this->input->post('product_name'));
         $model_number=$this->input->post('model_number');
         $cost_price=$this->input->post('cost_price');
      
		 
		 $selling_price=$this->input->post('selling_price');
         $quantity=$this->input->post('quantity');

         $total_price=$this->input->post('total_price');
      
         $transferred_on=$this->input->post('transferred_on');
        $shop ="shop";
      
         if($quantity == 0 ){
            $status="Out of stock";
        }
        else{
            $status="In Stock";
        }
   

     $data = [
		
        'product_category'=> $product_category,
        'product_name'=> $product_name,
        'model_number'=> $model_number,
        'cost_price'=> $cost_price,
        'selling_price'=> $selling_price,
        'stock_status'=>$status,
        'quantity'=> $quantity,
        'total_price'=> $total_price,
        'transferred_on'=> $transferred_on,
        'type'=> $shop,
       
  
       
        

    ];

    

    $stock_qty = $this->Stock_model->getstocksqty($model_number);

    $qty_new=$stock_qty - $quantity;

    if ($qty_new < 0){

        $this->session->set_flashdata('error', ' Not enough Quantity in Stock .Only ' . $stock_qty . ' items in Stock');
        redirect("StockTransfer/warehousetoshop");
        exit();

    }

    if($qty_new == 0 ){
        $status="Out of stock";
    }
    else{
        $status="In Stock";
    }


    $updatedata = [
        'item_quantity'=>$qty_new,
        'stock_status'=>$status,

    ];

    $stock_qty = $this->Stock_model->updateStockQty($model_number,$updatedata);




       $condition = array(
        'model_number' => $model_number,
       );
    
    // Check if the record already exists in the 'stock_to_vehicle' table
       $hai = $this->db->get_where('warehousetoshop', $condition);
    
       if ($hai->num_rows() > 0) {
        // If the record exists, update quantity and total price
        $get_vehicle_to_qty = $this->Stocktransfer_model->get_vehicle_to_qty($model_number);
        $get_vehicle_to_price = $this->Stocktransfer_model->get_vehicle_to_price($model_number);
        $get_selling_price = $this->Stocktransfer_model->get_selling_price($model_number);
        $get_cost_price = $this->Stocktransfer_model->get_cost_price($model_number);

        

            

            if ($get_selling_price != $selling_price){
                $to_qty_new = $get_vehicle_to_qty + $quantity;
                  $sell =  $selling_price * $quantity;
                  $to_margin =  $sell + $total_price;
                  $to_supdatedata = [
                    'quantity' => $to_qty_new,
                    'total_price' => $to_margin,
                    'cost_price'=> $cost_price,
                    'selling_price'=> $selling_price,
                    'type'=> $shop,
                ];
            }
            else{
              $to_qty_new = $get_vehicle_to_qty + $quantity;
              $to_margin = $get_vehicle_to_price + $total_price;
              $to_supdatedata = [
                'quantity' => $to_qty_new,
                'total_price' => $to_margin,
                'type'=> $shop,
            ];
            }
            
    
           
                    
                        // Update the existing record in the 'stock_to_vehicle' table
            $stock_qtys = $this->Stocktransfer_model->to_updateStockQty($model_number,$to_supdatedata);
                    
        } 
        else {
            // If the record does not exist, insert a new record
            $to_updatedata = [
                'product_category'=> $product_category,
                'product_name'=> $product_name,
                'model_number'=> $model_number,
                'cost_price'=> $cost_price,
                'selling_price'=> $selling_price,
                'stock_status'=>$status,
                'quantity'=> $quantity,
                'total_price'=> $total_price,
                'transferred_on'=> $transferred_on,
                'type'=> $shop,
            
            ];
        
            // Insert a new record in the 'stock_to_vehicle' table
            $this->db->insert('warehousetoshop', $to_updatedata);
        }  




         $this->session->set_flashdata('success', 'Data Saved !');
         redirect("StockTransfer/warehousetoshop");
    
    
    
    
    
    












    // $result = $this->Stocktransfer_model->save($data);

    // if($result) {
    //     $this->session->set_flashdata('success', 'Data Saved !');
    //     redirect("StockTransfer/warehousetoshop");
        
    // } else {
    //     echo "Something went wrong";
    //     exit();
    // }

    // }



    }








    public function warehousetovehicle_save(){

        $vehicle_number = $this->input->post('vehicle_number');
        $product_category=$this->input->post('product_category');
        $product_name=$this->Stocktransfer_model->getWarehouseItem($this->input->post('product_name'));
        $model_number=$this->input->post('model_number');
        $cost_price=$this->input->post('cost_price');
     
        
        $selling_price=$this->input->post('selling_price');
        $quantity=$this->input->post('quantity');

        $total_price=$this->input->post('total_price');
     
        $transferred_on=$this->input->post('transferred_on');
       
     
        if($quantity == 0 ){
           $status="Out of stock";
       }
       else{
           $status="In Stock";
       }
  

    $data = [
       'vehicle_name'=>$vehicle_number,
       'product_category'=> $product_category,
       'product_name'=> $product_name,
       'model_number'=> $model_number,
       'cost_price'=> $cost_price,
       'selling_price'=> $selling_price,
       'stock_status'=>$status,
       'quantity'=> $quantity,
       'total_price'=> $total_price,
       'transferred_on'=> $transferred_on,
      
   ];

   

   $stock_qty = $this->Stock_model->getstocksqty($model_number);

   $qty_new=$stock_qty - $quantity;

   if ($qty_new < 0){

       $this->session->set_flashdata('error', ' Not enough Quantity in Stock .Only ' . $stock_qty . ' items in Stock');
       redirect("StockTransfer/warehousetovehicle");
       exit();

   }

   if($qty_new == 0 ){
       $status="Out of stock";
   }
   else{
       $status="In Stock";
   }


   $updatedata = [
       'item_quantity'=>$qty_new,
       'stock_status'=>$status,

   ];

   $stock_qty = $this->Stock_model->updateStockQty($model_number,$updatedata);


   $condition = array(
    'model_number' => $model_number,
    'vehicle_name' => $vehicle_number,
   );

// Check if the record already exists in the 'stock_to_vehicle' table
   $hai = $this->db->get_where('stock_to_vehicle', $condition);

   if ($hai->num_rows() > 0) {
    // If the record exists, update quantity and total price
    $get_vehicle_to_qty = $this->Vehicle_model->get_vehicle_to_qty($model_number,$vehicle_number);
    $get_vehicle_to_price = $this->Vehicle_model->get_vehicle_to_price($model_number, $vehicle_number);
    $get_selling_price = $this->Vehicle_model->get_selling_price($model_number,$vehicle_number);
    $get_cost_price = $this->Vehicle_model->get_cost_price($model_number,$vehicle_number);

            $to_qty_new = $get_vehicle_to_qty + $quantity;

           if ($get_selling_price != $selling_price){
                  $to_qty_new = $get_vehicle_to_qty + $quantity;
                  $sells =  $selling_price * $quantity;
                  $to_margin =  $sells + $total_price;

                  $to_supdatedata = [
                    'quantity' => $to_qty_new,
                    'total_price' => $to_margin,
                    'cost_price'=> $cost_price,
                    'selling_price'=> $selling_price,
                ];
            }
            else{
              $to_qty_new = $get_vehicle_to_qty + $quantity;
              $to_margin = $get_vehicle_to_price + $total_price;
              $to_supdatedata = [
                'quantity' => $to_qty_new,
                'total_price' => $to_margin,
            ];

            }

    

    // Update the existing record in the 'stock_to_vehicle' table
    $stock_qtys = $this->Vehicle_model->to_updateStockQty($model_number, $vehicle_number, $to_supdatedata);

    } else {
    // If the record does not exist, insert a new record
    $to_updatedata = [
        'vehicle_name'=>$vehicle_number,
        'product_category'=> $product_category,
        'product_name'=> $product_name,
        'model_number'=> $model_number,
        'cost_price'=> $cost_price,
        'selling_price'=> $selling_price,
        'stock_status'=>$status,
        'quantity'=> $quantity,
        'total_price'=> $total_price,
        'transferred_on'=> $transferred_on,
    ];

    // Insert a new record in the 'stock_to_vehicle' table
    $this->db->insert('stock_to_vehicle', $to_updatedata);
    }


    $this->db->insert('warehouse_to_vehicle', $data);








        $this->session->set_flashdata('success', 'Data Saved !');

        redirect('StockTransfer/warehousetovehicle','refresh');






   }

   public function warehousetovehicle_view(){

    $data['sales_count'] = $this->Sales_model->getSalesCount();
    $data['warehouses']=$this->Stocktransfer_model->getWarehousevehicleData();

    $this->load->view('parts/header');
    $this->load->view('parts/nav');
    $this->load->view('parts/aside', $data);
    $this->load->view('viewWarehousetovehicle', $data);
    $this->load->view('parts/footer');


   }



    public function warehousetoshop_view(){

        $data['sales_count'] = $this->Sales_model->getSalesCount();
        $data['warehouse']=$this->Stocktransfer_model->getWarehouseData();

		$this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside', $data);
        $this->load->view('viewWarehouseto', $data);
        $this->load->view('parts/footer');

    }


    public function warehousetoshop_delete($id) {
        // Load the stock model
      
    
        // Check if the item with the given $pid exists
        $item = $this->Stocktransfer_model->getWarehouseData($id);
        if ($item) {
            // Item exists, proceed with deletion
            $this->Stocktransfer_model->deletetWarehouseItem($id);
            $this->session->set_flashdata('success', 'Item deleted successfully.');
        } else {
            // Item does not exist
            $this->session->set_flashdata('error', 'Item not found.');
        }
    
        // Redirect to the stock listing page
        redirect('StockTransfer/warehousetoshop_view');
    }

    public function  getsdeletes($id) {
        // Load the stock model
      
    
        // Check if the item with the given $pid exists
        $item = $this->Stocktransfer_model->getWarehousevehicleData($id);
        if ($item) {
            // Item exists, proceed with deletion
            $this->Stocktransfer_model->deletetWarehousevehicleItem($id);
            $this->session->set_flashdata('success', 'Item deleted successfully.');
        } else {
            // Item does not exist
            $this->session->set_flashdata('error', 'Item not found.');
        }
    
        // Redirect to the stock listing page
        redirect('StockTransfer/warehousetovehicle_view');
    }
   


    public function View_Shop_Stock(){

        $data['sales_count'] = $this->Sales_model->getSalesCount();
        $data['warehouse']=$this->Stocktransfer_model->getWarehouseData();

		$this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside', $data);
        $this->load->view('View_Shop_Stock', $data);
        $this->load->view('parts/footer');

    }


    public function View_Vehicle_Stock(){

        $this->load->model('Sales_model');

        $query = $this->db->query("SELECT * FROM `stock_to_vehicle`");
        $data['warehouse'] = $query->result();
        $data['sales_count'] = $this->Sales_model->getSalesCount();

		$this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside', $data);
        $this->load->view('View_Vehicle_Stock', $data);
        $this->load->view('parts/footer');

    }

   
}