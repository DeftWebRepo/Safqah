<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UserController extends CI_Controller {

    public function __construct() {
        parent::__construct();
        // Load necessary libraries and models here
        // Make sure you load the session library
        $this->load->library('session');
    }

    public function logout() {
        // Destroy the user's session to log them out
       $this->session->sess_destroy();

        // Check if the session has been destroyed
        if (!$this->session->userdata('logged_in')) {
            // Redirect to the login page
            redirect('https://safqah.deftinnovations.in/');
        } else {
            // Handle the case where the session destruction failed
            // This might happen if the session library is not loaded, or if there's an issue destroying the session
            echo "Failed to destroy session. Please try again.";
        } // Change 'login' to your desired URL
    }

    // Other controller methods for your application

}
