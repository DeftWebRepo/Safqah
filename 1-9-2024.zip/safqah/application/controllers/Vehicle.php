<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vehicle extends CI_Controller {

	public function __construct() {
		/*call CodeIgniter's default Constructor*/
		parent::__construct();

		/*load model*/
		$this->load->model('Vehicle_model');
        $this->load->model('Sales_model');
	}

    public function index()
	{
		
        $data['sales_count'] = $this->Sales_model->getSalesCount();
		$this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
        $this->load->view('Addvehicle');
        $this->load->view('parts/footer');

	}
	public function add()
	{
		$data['sales_count'] = $this->Sales_model->getSalesCount();
		$this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
		$this->load->view('Addvehicle');
        $this->load->view('parts/footer');
	}

    public function save()
	{
		
		// var_dump($_POST);

		
		 $vehicle_number=$this->input->post('vehicle_number');
		 $vehicle_route=$this->input->post('vehicle_route');
		 $driver=$this->input->post('driver');
         $driver_contact=$this->input->post('driver_contact');
         $date=$this->input->post('date');
     


		 $data = [
		
			'vehicle_number'=> $vehicle_number,
			'vehicle_route'=> $vehicle_route,
			'driver'=> $driver,
            'driver_contact'=> $driver_contact,
            'date'=> $date,
   
          
		];

		$result = $this->Vehicle_model->save($data);

		if($result) {
            $this->session->set_flashdata('success', 'Data Saved !');
			redirect("vehicle/add");
			
		} else {
			echo "Something went wrong";
			exit();
		}


	}

    public function view() {

        $data['vehicles'] = $this->Vehicle_model->getVehicleData();
        $data['sales_count'] = $this->Sales_model->getSalesCount();

        $this->load->view('parts/header');
        $this->load->view('parts/nav');
        $this->load->view('parts/aside',$data);
        $this->load->view('viewVehicle', $data);
        $this->load->view('parts/footer');
    }

	public function edit($id) {
        // Load the stock model
   
    
       // Get the item details for editing
        $data['item'] = $this->Vehicle_model->getVehicleItem($id);
	
        $data['sales_count'] = $this->Sales_model->getSalesCount();
    
        if ($data['item']) {

            $this->load->view('parts/header');
            $this->load->view('parts/nav');
            $this->load->view('parts/aside',$data);
            $this->load->view('editVehicle', $data);
            $this->load->view('parts/footer');
           // Load the view for editing an item
           
        } else {
           // Item not found, show an error message
            $this->session->set_flashdata('error', 'Item not found.');
            redirect('vehicle/view');
        }
    }

	public function update($id) {
    
	
		$vehicle_number=$this->input->post('vehicle_number');
		$vehicle_route=$this->input->post('vehicle_route');
		$driver=$this->input->post('driver');
		$driver_contact=$this->input->post('driver_contact');
        $date=$this->input->post('date');
   
       $updatedData = [
		'vehicle_number'=> $vehicle_number,
		'vehicle_route'=> $vehicle_route,
		'driver'=> $driver,
		'driver_contact'=> $driver_contact,
	    'date'=> $date,

       ];

    
        // Update the item in the database
        $this->Vehicle_model->updateVehicle($id, $updatedData);
    
        // Set a success message
        $this->session->set_flashdata('success', 'Item updated successfully.');
    
        // Redirect to the stock listing page
        redirect('vehicle/view');
    }

	public function delete($id) {
        // Load the stock model
        $this->load->model('Vehicle_model');
    
        // Check if the item with the given $pid exists
        $item = $this->Vehicle_model->getVehicleItem($id);
        if ($item) {
            // Item exists, proceed with deletion
            $this->Vehicle_model->deleteVehicleItem($id);
            $this->session->set_flashdata('success', 'Item deleted successfully.');
        } else {
            // Item does not exist
            $this->session->set_flashdata('error', 'Item not found.');
        }
    
        // Redirect to the stock listing page
        redirect('vehicle/view');
    }

}