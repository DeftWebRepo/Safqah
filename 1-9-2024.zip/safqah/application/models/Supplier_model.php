<?php
class Supplier_model extends CI_Model {
    public function __construct() {
        parent::__construct();
    }

    public function save($data) {
		return $this->db->insert('supplier',$data);
	}
    public function getSuppliers() {
        $query = $this->db->query('SELECT * FROM supplier');
        return $query->result();
    }
    public function getSupplierss() {
        $query = $this->db->query('SELECT DISTINCT `supplier_name` FROM `lpo` WHERE `payment` = "credit" ' );
        return $query->result();
    }
    public function editSuppliers($s_id){
        return $this->db->where('s_id',$s_id)
                        ->get('supplier')
                        ->row();
    }

     public function update($s_id, $updatedData) {
        $this->db->where('s_id', $s_id)
                 ->update('supplier', $updatedData);
    }


    public function delete($s_id) {
        $this->db->where('s_id', $s_id)
                 ->delete('supplier');
    }

     public function saveproducts($data) {
        return $this->db->insert('supplierproducts',$data);
    }
}

