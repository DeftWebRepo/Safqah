<?php
class Products_model extends CI_Model {
    public function __construct() {
        parent::__construct();
    }

    public function save($data) {
		return $this->db->insert('products',$data);
	}
    public function getProductData() {
        return $this->db->get('products')->result();
    }
    public function getProductItem($Pid) {
        return $this->db->where('Pid', $Pid)
                        ->get('products')
                        ->row();
    }

    public function updateProduct($Pid , $updatedData ) {
        return $this->db->where('Pid', $Pid)
                        ->update('products', $updatedData );
    }

    public function deleteProductItem($pid) {
        $this->db->where('pid', $pid)
                 ->delete('products');
    }
}