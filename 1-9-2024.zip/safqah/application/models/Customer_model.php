<?php
class Customer_model extends CI_Model {
    public function __construct() {
        parent::__construct();
    }

   function save($data) {
		return $this->db->insert('customers',$data);
	}

    public function getStockData() {
        return $this->db->get('customers')->result();
    }

    public function getStockItem($cid) {
        return $this->db->where('cid', $cid)
                        ->get('customers')
                        ->row();
    }

    public function deleteStockItem($cid) {
        $this->db->where('cid', $cid)
                 ->delete('customers');
    }

    public function updateStockItem($cid, $data) {
        $this->db->where('cid', $cid)
                 ->update('customers', $data);
    }

    public function getCategories() {
        $query = $this->db->query('SELECT * FROM category');
        return $query->result();
    }
    public function getCustomers() {
        $query = $this->db->query('SELECT * FROM customers');
        return $query->result();
    }

    public function getCustomerss() {
        $query = $this->db->query('SELECT DISTINCT `customer_name` FROM `sales` WHERE `payment_terms` = "credit"');
        return $query->result();
    }
  
    public function getStockItems($cid) {
        return $this->db->where('cid', $cid)
                        ->get('customers')
                        ->row('company_name');
    }

	
}

