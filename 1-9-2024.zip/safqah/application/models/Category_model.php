<?php
class Category_model extends CI_Model {
    public function __construct() {
        parent::__construct();
    }

   function save($data) {
		return $this->db->insert('category',$data);
	}

    public function getStockData() {
        return $this->db->get('category')->result();
    }

    public function getStockItem($cid) {
        return $this->db->where('cid', $cid)
                        ->get('category')
                        ->row();
    }

    public function deleteStockItem($cid) {
        $this->db->where('cid', $cid)
                 ->delete('category');
    }

    public function updateStockItem($cid, $data) {
        $this->db->where('cid', $cid)
                 ->update('category', $data);
    }

    public function getCategories() {
        $query = $this->db->query('SELECT * FROM category');
        return $query->result();
    }

    

	
}

