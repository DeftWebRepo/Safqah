<?php
class Stocktransfer_model extends CI_Model {
    public function __construct() {
        parent::__construct();
    }

    public function save($data) {
		return $this->db->insert('warehousetoshop',$data);
	}

    public function getWarehouseData() {
        return $this->db->get('warehousetoshop')->result();
    }
    public function getvehicleData(){
        return $this->db->get('vehicletowarehouse')->result();
    }
    public function getvehicleDatasss(){
        return $this->db->get('vehicletoshop')->result();
    }

    public function getWarehouseItem($pid) {
        return $this->db->where('pid', $pid)
                        ->get('stock')
                        ->row('item_name');
    }

    public function deletetWarehouseItem($id) {
        $this->db->where('id', $id)
                 ->delete('warehousetoshop');
    }

    public function get_vehicle_to_qty($sku){
        return $this->db->where('model_number', $sku)
                        ->get('warehousetoshop')
                        ->row("quantity");



  }
  public function get_selling_price($sku){
    return $this->db->where('model_number', $sku)
                    ->get('warehousetoshop')
                    ->row("selling_price");

  }

  public function get_cost_price($sku){
    return $this->db->where('model_number', $sku)
                    ->get('warehousetoshop')
                    ->row("cost_price");

  }
  public function get_vehicle_to_price($sku){

    return $this->db->where('model_number', $sku)
                    ->get('warehousetoshop')
                    ->row("total_price");



}
public function to_updateStockQty($sku,$to_supdatedata){

    return $this->db->where('model_number', $sku)
                    ->update('warehousetoshop',$to_supdatedata);


}

public function getstockssss($category,$vehicle) {
    return $this->db->where('product_category', $category)
                    ->where('vehicle_name', $vehicle)
                    ->get('stock_to_vehicle')->result();
}

public function getStockItems($pid) {
    return $this->db->where('id', $pid)
                    ->get('stock_to_vehicle')
                    ->row();
}

public function getstocks($category) {
        return $this->db->where('product_category', $category)
                        ->get('warehousetoshop')->result();
    }

    public function getstocksqtyssss($model_number,$vehicle_number) {
        return $this->db->where('model_number', $model_number)
                        ->where('vehicle_name',$vehicle_number)
                        ->get('stock_to_vehicle')->row('quantity');
    }

    public function getstockstyu($model_number) {
        return $this->db->where('product_sku', $model_number)
                        ->get('stock')->row('item_quantity');
    }
    

    public function get_vehicle_pricess($model_number,$vehicle_number) {
        return $this->db->where('model_number', $model_number)
                        ->where('vehicle_name',$vehicle_number)
                        ->get('stock_to_vehicle')->row('total_price');
    }

    public function updateStockQtysssss($model_number,$vehicle_number, $updatedata) {
        $this->db->where('model_number', $model_number)
                 ->where('vehicle_name',$vehicle_number)
                 ->update('stock_to_vehicle', $updatedata);
    }

    public function updateStockdetqty($model_number, $updatedata_to) {
        $this->db->where('product_sku', $model_number)
                 ->update('stock', $updatedata_to);
    }

    public function getSalesItemss($id) {
        return $this->db->where('id', $id)
                        ->get('vehicletowarehouse')
                        ->row();
    }

    public function deleteSalesItemsss($id) {
        $this->db->where('id', $id)
                 ->delete('vehicletowarehouse');
    }

    public function getproductnamess($id) {
        return $this->db->where('id', $id)
                        ->get('stock_to_vehicle')
                        ->row('product_name');
    }

    public function getproductnamessss($id) {
        return $this->db->where('id', $id)
                        ->get('warehousetoshop')
                        ->row('product_name');
    }

    public function getproductnamesss($id) {
        return $this->db->where('id', $id)
                        ->get('stock_to_vehicle')
                        ->row('product_name');
    }
    

    public function getstocksqtyssssss($model_number,$vehicle_number) {
        return $this->db->where('model_number', $model_number)
                        ->where('vehicle_name',$vehicle_number)
                        ->get('stock_to_vehicle')->row('quantity');
    }


    public function get_vehicle_pricessss($model_number,$vehicle_number) {
        return $this->db->where('model_number', $model_number)
                        ->where('vehicle_name',$vehicle_number)
                        ->get('stock_to_vehicle')->row('total_price');
    }

    public function updateStocktysssss($model_number,$vehicle_number, $updatedata) {
        $this->db->where('model_number', $model_number)
                 ->where('vehicle_name',$vehicle_number)
                 ->update('stock_to_vehicle', $updatedata);
    }

    public function getstockstyust($model_number) {
        return $this->db->where('model_number', $model_number)
                        ->get('warehousetoshop')->row('quantity');
    }

    public function get_sku($model_number) {
        return $this->db->where('model_number', $model_number)
                        ->get('warehousetoshop')->row('model_number');
    }
    
    public function getstockstyusts($model_number) {
        return $this->db->where('model_number', $model_number)
                        ->get('warehousetoshop')->row('total_price');
    }

    public function updateStockdetqtysss($model_number, $updatedata_to) {
        $this->db->where('model_number', $model_number)
                 ->update('warehousetoshop', $updatedata_to);
    }

    public function getSalesItemssss($id) {
        return $this->db->where('id', $id)
                        ->get('vehicletoshop')
                        ->row();
    }

    public function deleteSalesItemssss($id) {
        $this->db->where('id', $id)
                 ->delete('vehicletoshop');
    }


    public function getstocksqtytyssss($model_number) {
        return $this->db->where('model_number', $model_number)
                        ->get('warehousetoshop')->row('quantity');
    }


    public function get_shopl_pricess($model_number) {
        return $this->db->where('model_number', $model_number)
                        ->get('warehousetoshop')->row('total_price');
    }

    public function updateshopQtysssss($model_number, $updatedata) {
        $this->db->where('model_number', $model_number)
                 ->update('warehousetoshop', $updatedata);
    }

    public function getshopstyu($model_number) {
        return $this->db->where('product_sku', $model_number)
                        ->get('stock')->row('item_quantity');
    }


    public function updateshopdetqtys($model_number, $updatedata_to) {
        $this->db->where('product_sku', $model_number)
                 ->update('stock', $updatedata_to);
    }

    public function getWarehousevehicleData() {
        return $this->db->get('warehouse_to_vehicle')->result();
    }
    
    public function deletetWarehousevehicleItem($id) {
        $this->db->where('id', $id)
                 ->delete('warehouse_to_vehicle');
    }

}
