<?php
class DueAmount_model extends CI_Model {
    public function __construct() {
        parent::__construct();
    }

    // public function getsupplierItems($supplier) {
    //     return $this->db->where('supplier_name', $supplier)
    //                     ->get('supplierproducts')
    //                     ->result();
    // }


    public function getsupplierItems($supplier,$payss) {
        return $this->db->where('supplier_name', $supplier)
                        ->where('payment',$payss)
                        ->get('lpo')
                        ->result();
                        
    }

    public function save($data) {
		return $this->db->insert('purchase_due',$data);
	}

    public function savedue($data) {
		return $this->db->insert('sales_due',$data);
	}

    public function getpricetransferItems($suppliers) {
        return $this->db->where('supplier_name', $suppliers)
                        ->get('purchase_due')
                        ->result();
    }

    public function getcustomerItems($customer,$pay){
        return $this->db->where('customer_name', $customer)
                        ->where('payment_terms',$pay)
                        ->get('sales')
                        ->result();

    }

    public function getamounttransferItems($customers){
        return $this->db->where('customer_name', $customers)
                        ->get('sales_due')
                        ->result();
    }
    public function gettransfer(){
        return $this->db->get('sales')
                        ->result();
    }

    public function getstransfers(){

        return $this->db->get('lpo')
                        ->result();

    }
    public function getstockttransfers(){
        return $this->db->get('stock_return')
                        ->result();
    }

    public function getstockttransfersss(){
        return $this->db->get('sales_return')
                        ->result();
    }


}