<?php
class Stock_Return_model extends CI_Model {
    public function __construct() {
        parent::__construct();
    }

   public function save($data) {
		return $this->db->insert('stock',$data);
	}

    public function getStockData() {
        return $this->db->get('stock')->result();
    }

    public function getstocks($category) {
        return $this->db->where('category', $category)
                        ->get('stock')->result();
    }
    

    public function getStockItem($pid) {
        return $this->db->where('pid', $pid)
                        ->get('stock')
                        ->row();
    }

    public function deleteStockItem($pid) {
        $this->db->where('pid', $pid)
                 ->delete('stock');
    }

    public function updateStockItem($pid, $data) {
        $this->db->where('pid', $pid)
                 ->update('stock', $data);
    }

    public function getStockItems($pid) {
        return $this->db->where('pid', $pid)
                        ->get('stock')
                        ->row();
    }

    public function getstocksqty($model_number) {
        return $this->db->where('product_sku', $model_number)
                        ->get('stock')->row('item_quantity');
    }


    public function updateStockQty($model_number, $updatedata) {
        $this->db->where('product_sku', $model_number)
                 ->update('stock', $updatedata);
    }
   
	
    

    public function getstockstem($pid){
        return $this->db->where('pid', $pid)
                        ->get('stock')
                        ->row('item_name');
    }

    public function getstockqtypurchase($category) {
        return $this->db->where('product_category', $category)
                        ->get('lpo')->result();
    }
    public function getStockItemspurchase($Pid) {
        return $this->db->where('id', $Pid)
                        ->get('lpo')
                        ->row();
    }
    public function getWarehouseItemss($id) {
        return $this->db->where('id', $id)
                        ->get('lpo')
                        ->row('product_name');
    }

    
}

