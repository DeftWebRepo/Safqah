<?php
class Lpo_model extends CI_Model {
    public function __construct() {
        parent::__construct();
    }

    public function save($data) {
		return $this->db->insert('lpo',$data);
	}
    public function getProductData() {
        return $this->db->get('lpo')->result();
    }
    public function getProductItem($id) {
        return $this->db->where('id', $id)
                        ->get('lpo')
                        ->row();
    }

    public function updateProduct($id , $updatedData ) {
        return $this->db->where('id', $id)
                        ->update('lpo', $updatedData );
    }

    public function deleteProductItem($id) {
        $this->db->where('id', $id)
                 ->delete('lpo');
    }
    public function getstocks($category) {
        return $this->db->where('product_category', $category)
                        ->get('products')->result();
    }

    public function getStockItemspurchase($Pid) {
        return $this->db->where('Pid', $Pid)
                        ->get('products')
                        ->row();
    }

    public function getproductItems($pid) {
        return $this->db->where('Pid', $pid)
                        ->get('products')
                        ->row('product_name');
    }

    public function get_vehicle_to_qty($sku){
        return $this->db->where('product_sku', $sku)
                        ->get('stock')
                        ->row("item_quantity");
    }

    public function get_vehicle_to_price($sku){

        return $this->db->where('product_sku', $sku)
                        ->get('stock')
                        ->row("total_cost_price");

    }


    public function get_cost_price($sku){
        return $this->db->where('product_sku', $sku)
                        ->get('stock')
                        ->row("item_price");
    
      }

      public function to_updateStockQty($sku,$to_supdatedata){

        return $this->db->where('product_sku', $sku)
                        ->update('stock',$to_supdatedata);
    
    
    }


    public function get_vehicles_to_qty($sku){
        return $this->db->where('product_sku', $sku)
                        ->get('lpo')
                        ->row("item_quantity");
    }

    public function get_vehicles_to_price($sku){

        return $this->db->where('product_sku', $sku)
                        ->get('lpo')
                        ->row("total_cost_price");

    }


    public function get_costs_price($sku){
        return $this->db->where('product_sku', $sku)
                        ->get('lpo')
                        ->row("item_price");
    
      }

      public function to_updateStockQtysssss($sku,$to_supdatedata){

        return $this->db->where('product_sku', $sku)
                        ->update('lpo',$to_supdatedata);
    
    
    }

    public function getstockstem($pid){
        return $this->db->where('id', $pid)
                        ->get('lpo')
                        ->row('item_name');
    }
   
}