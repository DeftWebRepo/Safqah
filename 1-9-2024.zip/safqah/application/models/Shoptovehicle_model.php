<?php
class Shoptovehicle_model extends CI_Model {
    public function __construct() {
        parent::__construct();
    }

    public function save($data) {
		return $this->db->insert('stock_to_vehicle',$data);
	}
    public function getVehicleData() {
        return $this->db->get('stock_to_vehicle')->result();
    }


    public function getVehicleItem($id) {
        return $this->db->where('id', $id)
                        ->get('stock_to_vehicle')
                        ->row();
    }

    public function updateVehicle($id , $updatedData ) {
        return $this->db->where('id', $id)
                        ->update('stock_to_vehicle', $updatedData );
    }

    public function deleteVehicleItem($id) {
        $this->db->where('id', $id)
                 ->delete('stock_to_vehicle');
    }

    public function getstocks($category){
        return $this->db->where('product_category',$category)
                        ->get('warehousetoshop')->result();
    }

    public function getstockhouseItem($id) {
        return $this->db->where('id', $id)
                        ->get('warehousetoshop')
                        ->row('product_name');
    }

    public function getstocksqty($model_number){
        return $this->db->where('model_number', $model_number)
                        ->get('warehousetoshop')->row('quantity');

    }


    public function getstocksqtysit($model_number){
        return $this->db->where('model_number', $model_number)
                        ->get('warehousetoshop')->row('total_price');
    }


    public function updateStockQty($model_number, $updatedata) {
        $this->db->where('model_number', $model_number)
                 ->update('warehousetoshop', $updatedata);
    }

}