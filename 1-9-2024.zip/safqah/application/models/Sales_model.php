<?php
class Sales_model extends CI_Model {
    public function __construct() {
        parent::__construct();
    }

    public function save($data) {
		return $this->db->insert('sales',$data);
	}

    public function getSalesData() {
        return $this->db->get('sales')->result();
    }

    public function getSalesItem($s_id) {
        return $this->db->where('s_id', $s_id)
                        ->get('sales')
                        ->row();
    }

    public function updateSales($s_id , $updatedData ) {
        return $this->db->where('s_id', $s_id)
                        ->update('sales', $updatedData );
    }


    public function deleteSalesItem($s_id) {
        $this->db->where('s_id', $s_id)
                 ->delete('sales');
    }

    public function getVehicles($category, $vehicle_number) {
        return $this->db->where('product_category', $category)
                        ->where('vehicle_from_to', $vehicle_number)
                        ->get('vehicle_to_vehicle')->result();
                        
    }

    // public function getVehicles($category, $vehicle_number) {
    //     return $this->db->select('*')
    //                     ->from('stock_to_vehicle')
    //                     ->join('vehicle_to_vehicle', 'stock_to_vehicle.vehicle_name = vehicle_to_vehicle.vehicle_from_name')
    //                     ->where('stock_to_vehicle.product_category', $category)
    //                     ->where('vehicle_to_vehicle.vehicle_from_to', $vehicle_number)
    //                     ->get()
    //                     ->result();
    // }

    public function getVehiclesItems($id) {
        return $this->db->where('id', $id)
                        ->get('vehicle_to_vehicle')
                        ->row();
    }

    public function getstockVehicleItem($id) {
        return $this->db->where('id', $id)
                        ->get('vehicle_to_vehicle')
                        ->row('product_name');
    }

    public function getstockCustomerItem($cid) {
        return $this->db->where('cid', $cid)
                        ->get('customers')
                        ->row('customer_name');
    }

    public function getstocksqty($sku,$vehicle) {
        return $this->db->where('model_number', $sku)
                        ->where('vehicle_from_to',$vehicle)
                        ->get('vehicle_to_vehicle')->row('quantity');
    }

    public function updateStockQty($sku,$vehicle, $updatedata) {
        $this->db->where('model_number', $sku)
                 ->where('vehicle_from_to',$vehicle)
                 ->update('vehicle_to_vehicle', $updatedata);
    }
    public function getSalesCount() {
        // Perform a database query to get the count from your 'sales' table
        $query = $this->db->get('sales');
        return $query->num_rows(); // Return the count
    }


     public function getShop($category, $vehicle_number) {
        return $this->db->where('product_category', $category)
                        ->where('type', $vehicle_number)
                        ->get('warehousetoshop')->result();
                        
    }

       public function get_shop_items($id) {
        return $this->db->where('id', $id)
                        ->get('warehousetoshop')
                        ->row();
    }

    public function getstockshopItem($id) {
        return $this->db->where('id', $id)
                        ->get('warehousetoshop')
                        ->row('product_name');
    }

    public function getstockshopqty($sku) {
        return $this->db->where('model_number', $sku)
                        ->get('warehousetoshop')->row('quantity');
    }

    public function updateStockshopQty($sku, $updatedatas) {
        $this->db->where('model_number', $sku)
                 ->update('warehousetoshop', $updatedatas);
    }


     public function getstockshop_price($sku) {
        return $this->db->where('model_number', $sku)
                        ->get('warehousetoshop')->row('total_price');
    }

     public function get_vehicle_price($sku,$vehicle) {
        return $this->db->where('model_number', $sku)
                        ->where('vehicle_from_to',$vehicle)
                        ->get('vehicle_to_vehicle')->row('total_price');
    }
    public function get_product_name($id){
            return $this->db->where('invoice_no', $id)
                            ->get('sales')->row('product_name');

      }
    

}