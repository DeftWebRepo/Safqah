<?php
class Login_model extends CI_Model {
    public function __construct() {
        parent::__construct();
    }

    public function authenticate($username, $password) {
        $query = $this->db->get_where('login', array('username' => $username, 'password' => $password));
        return $query->row();
    }
}
