<?php
class Vehicle_model extends CI_Model {
    public function __construct() {
        parent::__construct();
    }

    public function save($data) {
		return $this->db->insert('vehicle',$data);
	}
    public function getVehicleData() {
        return $this->db->get('vehicle')->result();
    }


    public function getVehicleItem($id) {
        return $this->db->where('id', $id)
                        ->get('vehicle')
                        ->row();
    }

    public function updateVehicle($id , $updatedData ) {
        return $this->db->where('id', $id)
                        ->update('vehicle', $updatedData );
    }

    public function deleteVehicleItem($id) {
        $this->db->where('id', $id)
                 ->delete('vehicle');
    }

    
    public function vehicle_number($id) {
        $this->db->where('id', $id)
                 ->delete('vehicle_number');
    }

    public function getstocksqty($sku,$vnumber,$name){

          return $this->db->where('model_number', $sku)
                          ->where('vehicle_from_to', $vnumber)
                          ->where('product_name', $name)
                          ->get('vehicle_to_vehicle')
                          ->row("quantity");



    }


    public function getstocksqtyss($sku,$vnumber){

        return $this->db->where('product_sku', $sku)
                        ->where('item_name', $vnumber)
                        ->get('stock')
                        ->row("item_quantity");



  }
  public function getstocksqtysss($sku,$vnumber){

    return $this->db->where('product_sku', $sku)
                    ->where('item_name', $vnumber)
                    ->get('stock')
                    ->row("total_cost_price");



}



     public function getstock_price($sku,$vnumber,$name){

          return $this->db->where('model_number', $sku)
                          ->where('vehicle_from_to', $vnumber)
                          ->where('product_name', $name)
                          ->get('vehicle_to_vehicle')
                          ->row("total_price");



    }



    public function get_vehicle_to_qty($sku,$vnumber,$name){

          return $this->db->where('model_number', $sku)
                          ->where('vehicle_from_to', $vnumber)
                          ->where('product_name', $name)
                          ->get('vehicle_to_vehicle')
                          ->row("quantity");



    }

    public function get_vehicle_to_qtys($sku,$vnumber,$name){

        return $this->db->where('model_number', $sku)
                        ->where('vehicle_from_to', $vnumber)
                        ->where('product_name', $name)
                        ->get('vehicle_to_vehicle')
                        ->row("quantity");



  }
  public function get_vehicle_to_qtysss($sku,$vnumber,$name){

    return $this->db->where('model_number', $sku)
                    ->where('vehicle_from_to', $vnumber)
                    ->where('product_name', $name)
                    ->get('vehicle_to_vehicle')
                    ->row("quantity");



}


   public function get_vehicle_to_price($sku,$vnumber,$name){

          return $this->db->where('model_number', $sku)
                          ->where('vehicle_from_to', $vnumber)
                          ->where('product_name', $name)
                          ->get('vehicle_to_vehicle')
                          ->row("total_price");



    }

    public function get_vehicle_to_prices($sku,$vnumber,$name){

        return $this->db->where('model_number', $sku)
                        ->where('vehicle_from_to', $vnumber)
                        ->where('product_name', $name)
                        ->get('vehicle_to_vehicle')
                        ->row("total_price");



  }
  public function get_vehicle_to_pricesss($sku,$vnumber,$name){

    return $this->db->where('model_number', $sku)
                    ->where('vehicle_from_to', $vnumber)
                    ->where('product_name', $name)
                    ->get('vehicle_to_vehicle')
                    ->row("total_price");



}

    public function get_selling_price($sku,$vnumber,$name){

        return $this->db->where('model_number', $sku)
                        ->where('vehicle_from_to', $vnumber)
                        ->where('product_name', $name)
                        ->get('vehicle_to_vehicle')
                        ->row("selling_price");
    }

    public function get_selling_prices($sku,$vnumber,$name){

        return $this->db->where('model_number', $sku)
                        ->where('vehicle_from_to', $vnumber)
                        ->where('product_name', $name)
                        ->get('vehicle_to_vehicle')
                        ->row("selling_price");
    }

    public function get_cost_price($sku,$vnumber,$name){

        return $this->db->where('model_number', $sku)
                        ->where('vehicle_from_to', $vnumber)
                        ->where('product_name', $name)
                        ->get('vehicle_to_vehicle')
                        ->row("cost_price");
    }
    
    public function get_cost_prices($sku,$vnumber,$name){

        return $this->db->where('model_number', $sku)
                        ->where('vehicle_from_to', $vnumber)
                        ->where('product_name', $name)
                        ->get('vehicle_to_vehicle')
                        ->row("cost_price");
    }

    


    public function updateStockQty($sku,$vnumber,$name,$updatedata){

              return $this->db->where('model_number', $sku)
                              ->where('vehicle_from_to', $vnumber)
                              ->where('product_name', $name)
                              ->update('vehicle_to_vehicle',$updatedata);


    }

    public function updateStockQtyss($sku,$vnumber,$updatedatas){

        return $this->db->where('product_sku', $sku)
                        ->where('item_name', $vnumber)
                        ->update('stock',$updatedatas);


}

public function updateStockQtysss($sku,$vnumber,$updatedatasss){

    return $this->db->where('product_sku', $sku)
                    ->where('item_name', $vnumber)
                    ->update('stock',$updatedatasss);


}

     public function to_updateStockQty($sku,$vnumber,$name,$to_supdatedata){

              return $this->db->where('model_number', $sku)
                              ->where('vehicle_from_to', $vnumber)
                              ->where('product_name', $name)
                              ->update('vehicle_to_vehicle',$to_supdatedata);


    }

    public function to_updateStockQtyss($sku,$vnumber,$name,$to_supdatedata){

        return $this->db->where('model_number', $sku)
                        ->where('vehicle_from_to', $vnumber)
                        ->where('product_name', $name)
                        ->update('vehicle_to_vehicle',$to_supdatedata);


}
public function to_updateStockQtyssss($sku,$vnumber,$name,$to_supdatedatass){

    return $this->db->where('model_number', $sku)
                    ->where('vehicle_from_to', $vnumber)
                    ->where('product_name', $name)
                    ->update('vehicle_to_vehicle',$to_supdatedatass);


}

    

//     public function getproductnames(){
//         return $this->db->get('stock_to_vehicle')
//                         ->row("product_name");



//   }

  public function getproductnames($id){
    return $this->db->where('model_number', $id)
                    ->get('vehicle_to_vehicle')
                    ->row('product_name');
}


public function getproductnamess($id){
    return $this->db->where('product_sku', $id)
                    ->get('stock')
                    ->row('item_name');
}


}