<?php
class SupplierProduct_model extends CI_Model {
    public function __construct() {
        parent::__construct();
    }

    public function save($data) {
		return $this->db->insert('supplierproducts',$data);
	}
    public function getProductData() {
        return $this->db->get('supplierproducts')->result();
    }
    public function getProductItem($Pid) {
        return $this->db->where('Pid', $Pid)
                        ->get('supplierproducts')
                        ->row();
    }

    public function updateProduct($Pid , $updatedData ) {
        return $this->db->where('Pid', $Pid)
                        ->update('supplierproducts', $updatedData );
    }

    public function deleteProductItem($pid) {
        $this->db->where('pid', $pid)
                 ->delete('supplierproducts');
    }
}