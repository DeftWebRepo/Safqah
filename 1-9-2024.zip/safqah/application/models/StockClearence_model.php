<?php
class StockClearence_model extends CI_Model {
    public function __construct() {
        parent::__construct();
    }

   public function save($data) {
		return $this->db->insert('clearance',$data);
	}
    public function getClearenceData() {
        return $this->db->get('clearance')->result();
    }
    public function getClearenceItem($sc_id) {
        return $this->db->where('sc_id', $sc_id)
                        ->get('clearance')
                        ->row();
    }
    public function updateClearence($sc_id , $updatedData ) {
        return $this->db->where('sc_id', $sc_id)
                        ->update('clearance', $updatedData );
    }

    public function deleteClearenceItem($sc_id) {
        $this->db->where('sc_id', $sc_id)
                 ->delete('clearance');
    }
}