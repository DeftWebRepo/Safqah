<?php
class Product_Return_model extends CI_Model {
    public function __construct() {
        parent::__construct();
    }
    public function getstocksqty($sku) {
        return $this->db->where('product_sku', $sku)
                        ->get('stock')->row('item_quantity');
    }

    public function updateStockQty($sku, $updatedata) {
        $this->db->where('product_sku', $sku)
                 ->update('stock', $updatedata);
    }


    public function getstocksqtyss($po_number) {
        return $this->db->where('po_number', $po_number)
                        ->get('lpo')->row('item_quantity');
    }

    public function updateStockQtyss($po_number, $updatedatass) {
        $this->db->where('po_number', $po_number)
                 ->update('lpo', $updatedatass);
    }

    public function getstockspricess($po_number) {
        return $this->db->where('po_number', $po_number)
                        ->get('lpo')->row('total_cost_price');
    }
    
    

}