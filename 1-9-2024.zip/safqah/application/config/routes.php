<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$route['default_controller'] = 'Home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
$route['auth/login'] = 'auth/login';
$route['auth/register'] = 'auth/register';
$route['login'] = 'login';
$route['dashboard'] = 'Dashboard'; // Create a Dashboard controller if needed

$route['logout'] = 'UserController/logout';

/* Re defined routes for safqa */

$route['stock-management'] = 'StockManagement';

$route['stock-management/add'] = 'StockManagement/add';


$route['stock-management/view'] = 'StockManagement/view';


$route['product-management'] = 'ProductManagement';

$route['product-management/add'] = 'ProductManagement/add';


$route['product-management/view'] = 'ProductManagement/view';


$route['stock-clearence'] = 'StockClearence';

$route['stock-clearence/add'] = 'StockClearence/add';


$route['stock-clearence/view'] = 'StockClearence/view';

$route['supplier-management']='SupplierManagement';

$route['supplier-management/add'] = 'SupplierManagement/add';


$route['supplier-management/view'] = 'SupplierManagement/view';

$route['SupplierProducts']='SupplierProducts';

$route['SupplierProducts/add'] = 'SupplierProducts/add';


$route['SupplierProducts/view'] = 'SupplierProducts/view';


$route['sales'] = 'Sales';

$route['sales/add'] = 'Sales/add';


$route['sales/view'] = 'Sales/view';

$route['warehuse_lpo'] = 'Lpo';

$route['warehuse_lpo/add'] = 'Lpo/add';

$route['warehuse_lpo/view'] = 'Lpo/view';

 $route['shoplpo'] = 'Shoplpo';

 $route['shoplpo/add'] = 'Shoplpo/add';

 $route['shoplpo/view'] = 'Shoplpo/view';


$route['vehicle'] = 'Vehicle';

$route['vehicle/add'] = 'Vehicle/add';


$route['vehicle/view'] = 'Vehicle/view';

//VehilceToVehicle
//$route['VehilceToVehicle'] = 'vehilce-to-vehicle';

$route['vehilce-to-vehicle'] = 'VehilceToVehicle';

$route['add-stock-return'] = 'StockClearence/add_stock_return';

$route['add-sales-return'] = 'SalesReturn/add';

$route['sales'] = 'Sales/view';


$route['api'] = 'ApiController';

$route['sales_invoice(:num)']['get'] = 'ApiController/generate_invoice/$1';


$route['add-stock-return'] = 'StockReturn/add';

$route['view-stock-return'] = 'StockReturn/view';


