
            <!-- Layout container -->
            <div class="layout-page">
                <!-- Navbar -->
                <div class="content-wrapper">
                    <!-- Content -->
                    <div class="container-xxl flex-grow-1 container-p-y">
                        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Supplier </span> Products</h4>

                        <!-- Basic Layout & Basic with Icons -->
                        <div class="row">
                            <!-- Basic Layout -->
                            <div class="col-xxl">
                                <div class="card mb-4" style="max-width: 50%;">
                                    <div class="card-header d-flex align-items-center justify-content-between">
                                        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Add </span> Products</h4>
                                    </div>
                                    <div class="card-body">
                                        <form action="<?php echo base_url();?>SupplierProducts/save" method="post">
                                            <div class="row mb-3" >
                                                <label class="col-sm-4 col-form-label" for="basic-default-email">Supplier Name</label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control" id="suppliername" name="supplier_name" placeholder="" required />
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <label class="col-sm-4 col-form-label" for="basic-default-email">Product Category</label>
                                                <div class="col-sm-8">
                                                     <select class="form-select" aria-label="Default select example" name="product_category" required>
                                                        <option selected>Select Category</option>
                                                        <?php foreach ($categories as $category): ?>
                                                    <option value="<?= $category->name ?>"><?= $category->name ?></option>
                                                <?php endforeach; ?>
                                                    </select>
                                                </div>
                                            </div>
                                            
                                            <div class="row mb-3">
                                                <label class="col-sm-4 col-form-label" for="basic-default-company">Product Name</label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control" id="basic-default-company" name="product_name" placeholder="" required />
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-sm-4 col-form-label" for="basic-default-email">Product Code</label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control" id="basic-default-company" name="product_code" placeholder="" required />
                                                </div>
                                            </div>
                                            
                    

                                            

                                            <div class="row mb-3">
                                                <label class="col-sm-4 col-form-label" for="basic-default-email">Product Cost</label>
                                                <div class="col-sm-8">
                                                    <input type="number" step="0.01" class="form-control" id="basic-default-company" name="product_price" placeholder="" required />
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-sm-4 col-form-label" for="basic-default-email">Product Quantity</label>
                                                <div class="col-sm-8">
                                                    <input type="number" class="form-control" id="basic-default-company" name="product_qty" placeholder="" required />
                                                </div>
                                            </div>

                                            
                                            

                                            <!-- <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-email">Product Status</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" id="basic-default-company" name="product_status" placeholder="" required />
                                                </div>
                                            </div> -->


                                            

                                            
                                            <div class="row mt-4">
                                        
                                                <div class="col-sm-3">
                                                    <input type="submit" class="form-control btn btn-primary" id="submit" value="Submit" />
                                                </div>
                                            </div>

                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xxl">

                            </div>
                        </div>
                    </div>
                    <!-- / Content -->
                    <!-- Footer -->
 <script>
$(document).ready(function() {
  $('#supplier_id').change(function() {
    var supplierid = $(this).val();


    $.ajax({
      url: 'suppliername.php',
      type: 'POST',
      data: { supplerproducts: supplierid },
      dataType: 'json',
      success: function(data) {
        $('#suppliername').val(data.suppliername);
        
        
      }
    });
  });
});
</script>                   