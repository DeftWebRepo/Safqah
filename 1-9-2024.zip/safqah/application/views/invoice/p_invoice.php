
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" />

    <title>Invoice</title>

    <style>



@page{
            size: A4;
            margin: 0;
        }

     
        @media print {

            

            html,
            body {
                width: 210mm;
                height: 297mm;
            }

            .main-page {
        margin: 0;
        border: initial;
        border-radius: initial;
        width: initial;
        min-height: initial;
        box-shadow: initial;
        background: initial;
        /* page-break-after: always; Remove this line */
    }

    .print_button{
        display: none;;
    }
            
        }
       
        body {
            width: 230mm;
            height: 100%;
            margin: 0 auto;
            padding: 0;
            font-size: 12pt;
            background: rgb(204, 204, 204);
        }

        * {
            box-sizing: border-box;
            -moz-box-sizing: border-box;
        }

        h1,
        h2,
        h3,
        h4,
        h5,
        h6,
        a,
        li,
        p,
        button,
        label,
        input,
        textarea,
        select,
        td {
            font-family: poppins, sans-serif;
        }

        .head_color {
            background: black;
            height: 6px;
        }

        .main-page {
            width: 210mm;
            min-height: 297mm;
            margin: 10mm auto;
            background: white;
        }

        .sub-page {
            padding: 1cm;
            padding-bottom: 7px;
        }

        table.table.report_tab td {
            font-size: 15px;
            color: #000;
            font-weight: 500;
        }

        th {
            font-weight: 600;
            font-family: poppins, sans-serif;
        }

    
    </style>
</head>

<?php 




$lpo = $this->db->query("SELECT * FROM `stock_return` WHERE `po_number`='$invoice_number'");



    
?>

<body>

    <div class="main-page">
        <div class="head_color"></div>
        <div class="sub-page pt-3">
            <div class="d-flex">
                <div class="">
                    <!-- <img src="<?php //echo base_url();?>invoice_api/images/report/logo.png" style="width: 150px;"> -->
                </div>
                <div class="ms-auto">
                    <div style="text-align: end;">
                        <h3>Safqah</h3>
                        <h6 class="mb-1">Jeddah</h6>
                        <div class="d-flex align-items-center justify-content-end">
                            <div class="me-2">
                                <p>Tel: 9874 563 210</p>
                            </div>
                            <div>
                                <p>Mobile: 9874 563 210</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="border-bottom border-dark"></div>
            <h2 class="text-center mt-3">Purchase Return</h2>
            <br>
            <div class="d-flex">
                <div class="">
                    <h6>To,</h6>
                    <p class="mb-1" style="color: #535353;"><b style="font-weight: 500;">Supplier: <?php echo $lpo->row()->supplier_name; ?></b></p>
                    <!-- <p class="mb-1" style="color: #535353;"><b style="font-weight: 500;">Address:</b> Test</p>
                    <p class="mb-1" style="color: #535353;"><b style="font-weight: 500;">Tel:</b> 9874 563 210</p> -->
                </div>
                <div class="ms-auto" style="text-align: end;">
                    <h6></h6>
                    <p class="mb-2" style="color: #535353;"><b style="font-weight: 500;">PO Number:</b> <?php  echo $lpo->row()->po_number; ?>
                    </p>
                    <!-- <p class="mb-2" style="color: #535353;"><b style="font-weight: 500;">Date: </b> <?php // echo $lpo->row()->_date; ?></p> -->
                    <!-- <p class="mb-2" style="color: #535353;"><b style="font-weight: 500;">Payment Terms:</b> -->
                    <!-- <?php  //echo ucfirst($sales->row()->payment_terms); ?></p> -->
                 
                </div>
            </div>

            <div class="mt-4 pb-2">
            <br><br>
            <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th scope="col">SINO:</th>
                            <th scope="col">Product Details</th>
                            <th scope="col">Qty</th>
                            <th scope="col">Amount</th>
                            <th scope="col">Total Amount</th>
                        </tr>
                    </thead>
                    <tbody>


                    <?php 

                    $id=1;

                    $totalAmountSum = 0; 
                  
                  foreach ($lpo2 as $row){ 
                                        
                    
                    ?>

                        <tr>
                            <td><?php echo $id++;?></td>
                            <td><?php echo $row->product;?></td>
                            <td><?php echo $row->product_qty;?></td>
                            <td><?php echo $row->selling_price;?></td>
                            <td><?php echo $row->total_selling_pricing;
                            
                            $totalAmountSum += $row->total_selling_pricing; // Add to the sum

                            
                            ?>/-</td>
                        </tr>


                    <?php } ?>
                    
                        <tr>
                        <?php

                            $number = $totalAmountSum;

                            // Create a NumberFormatter object for the English language
                            $formatter = new NumberFormatter('en', NumberFormatter::SPELLOUT);

                            // Convert the number to words
                            $words = $formatter->format($number);

                        ?>
                            <td colspan="3">Sub Total (In Words) : <?php echo ucwords($words); ?> <?php echo "Only" ?>  </td>
                            <td colspan="2">SAR (In Numbers) : <?php echo $totalAmountSum; ?>/-</td>
                        </tr>
                    </tbody>
                </table>



            </div>
            <div class="border-bottom border-dark mb-3"></div>
            <div class="mt-1" style="max-width: 40%; margin: 0 0 0 auto; text-align: end;">
            <p style="margin-top: 20px;"></p>
                <p class="mb-1" style="color: #000; font-size: 16px; font-weight: 500;margin-top:20px;">
                <br><br>
                Managing Director</p>
                <p class="mb-1" style="color: #000; font-size: 16px; font-weight: 500;">_____________________</p>
                <p class="mb-0" style="color: #000; font-size: 16px; font-weight: 500;">Safqah</p>
            </div>
        </div>


        <div class="row print_button mb-4" style="margin-top:50px;">
        <div class="col-md-4">
        <a href="<?php echo base_url();?>StockClearence/view_return" class="form-control btn" 
        style="color:white;background-color:black;width:100%;margin-left:50px;" id="submit" value="Submit" target="_blank"> View Purchase Return</a>
    
   
    </div>
        <div class="col-md-4">

        <a href="<?php echo base_url();?>StockClearence/add_sales_return" class="form-control btn" 
        style="color:white;background-color:black;width:100%;margin-left:50px;" id="submit" value="Submit" target="_blank"> Add Purchase Return </a>
      

        </div>
        <div class="col-md-2">
        <button class="form-control btn " style="color:white;background-color:black;width:100%;margin-left:50px;" onclick="printPage()">Print</button>
        </div>
    </div>



    </div>

 

    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    function printPage() {
        window.print();
    }
    </script>
</body>

</html>

