<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function () {
        // Get the current date in the format YYYY-MM-DD
        var currentDate = new Date().toISOString().split('T')[0];

        // Set the value of the input field with id "datepicker" to the current date
        $("#transferred_on_inpit").val(currentDate);
    });
</script>

<div class="layout-page">
                <!-- Navbar -->
                <nav class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme" id="layout-navbar" style="">
                    <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
                        <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                            <i class="bx bx-menu bx-sm"></i>
                        </a>
                    </div>

                    <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
                        <!-- Search -->
                        <!-- <div class="navbar-nav align-items-center">
                            <div class="nav-item d-flex align-items-center">
                                <i class="bx bx-search fs-4 lh-0"></i>
                                <input type="text" class="form-control border-0 shadow-none ps-1 ps-sm-2" placeholder="Search..." aria-label="Search..." />
                            </div>
                        </div> -->
                        <!-- /Search -->
                        <div style="font-size:18px;">
                            Stock Management
                        </div>

                        <ul class="navbar-nav flex-row align-items-center ms-auto">
                            <!-- User -->
                            <li class="nav-item navbar-dropdown dropdown-user dropdown">
                                <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                                    <div class="avatar avatar-online">
                                        <img src="<?php echo base_url()?>theme/assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle" />
                                    </div>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <a class="dropdown-item" href="#">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 me-3">
                                                    <div class="avatar avatar-online">
                                                        <img src="<?php echo base_url()?>theme/assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle" />
                                                    </div>
                                                </div>
                                                <div class="flex-grow-1">
                                                    <span class="fw-medium d-block">Safqah</span>
                                                    <small class="text-muted">Admin</small>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <div class="dropdown-divider"></div>
                                    </li>
                                
                                    <li>
                                        <a class="dropdown-item" href="<?php echo base_url();?>logout">
                                            <i class="bx bx-power-off me-2"></i>
                                            <span class="align-middle">Log Out</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <!--/ User -->
                        </ul>
                    </div>
                </nav>
                <div class="content-wrapper">
                    <!-- Content -->
                    <div class="container-xxl flex-grow-1 container-p-y">
                      

                        <!-- Basic Layout & Basic with Icons -->
                        <div class="row" style="width:100%;">
                            <!-- Basic Layout -->
                            <div class="col-12" style="width:100%;">
                                <div class="card mb-4">
                                    <div class="card-header d-flex align-items-center justify-content-between">
                                        <h4 class="py-3 mb-4" style="display:flex;align-items:center;justify-content:center;width:100%;"><div> Add </div> Vehicle</h4>
                                    </div>
                                    <div class="card-body">
                                    <?php
                                        if ($this->session->flashdata('success')) {
                                            echo '<div id="success-alert" class="alert alert-success">' . $this->session->flashdata('success') . '</div>';
                                        }elseif ($this->session->flashdata('error')){
                                            echo '<div id="success-alert" class="alert alert-danger">' . $this->session->flashdata('error') . '</div>';
                                           
                                        }
                                    ?>
                                        <form action="<?php echo base_url();?>Vehicle/save" method="post" style="display:flex; width:100%;align-item:center;justify-content:center;">
                                           <div class="form-group" style="margin-left:80px;"> 
                                           <div class="items1" style="display:flex;align-items:center;">
                                            <div class="row mb-3" style="width:100%;">
                                                <label class="col-sm-6 col-form-label" for="basic-default-company">Vehicle Number</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="vehicle_number" id="basic-default-company" placeholder="" />
                                                </div>
                                            </div>

                                            <div class="row mb-3" style="width:100%;">
                                                <label class="col-sm-6 col-form-label" for="basic-default-email">Vehicle Route</label>
                                                <div class="col-sm-10"> 
                                                    <input type="text" class="form-control" name="vehicle_route" id="basic-default-company" placeholder="" />
                                                </div>
                                            </div>
                                            </div>
                                            <div class="items2" style="display:flex;align-items:center;" >
                                            <div class="row mb-3" style="width:100%;">
                                                <label class="col-sm-6 col-form-label" for="basic-default-email">Driver Name/ID</label>
                                                <div class="col-sm-10">
                                                    <input type="text" step="0.01" name="driver" class="form-control" id="basic-default-company" placeholder="" />
                                                </div>
                                            </div>

                                            <div class="row mb-3" style="width:100%;">
                                                <label class="col-sm-6 col-form-label" for="basic-default-email">Driver Contact</label>
                                                <div class="col-sm-10">
                                                    <input type="tel" class="form-control" name="driver_contact" id="basic-default-company" placeholder="" />
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                           
                                                <div class="col-sm-10">
                                                    <input type="hidden" class="form-control" id="transferred_on_inpit"
                                                        name="date" placeholder="" />
                                                </div>
                                            </div>
                                            </div>
                                            </div>

                                            <div class="row mt-3" style="width:500px;margin-top:50px !important ;margin-left:120px;">
                                                
                                                <div class="col-sm-9">
                                                    <input type="submit" class="form-control btn btn-primary" id="submit" value=" Save Vehicle Details " />
                                                </div>
                                                <div class="col-sm-9">
                                                    <a href="<?php echo base_url();?>Vehicle/view" class="form-control btn" style="color:white;background-color:black;" id="submit" value="Submit" > View Vehicle Details </a>
                                                </div>
                                            </div>

                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xxl">

                            </div>
                        </div>
                    </div>
                    <!-- / Content -->
                    <!-- Footer -->
                    <footer class="content-footer footer bg-footer-theme">
                        <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                        <a href="https://deftinnovations.in/" target="blank" class="mb-2 mb-md-0 hellos">
                                © Deft Innovations
</a>

                        </div>
                    </footer>
                    <!-- / Footer -->

                    <div class="content-backdrop fade"></div>
                </div>
                <!-- Content wrapper -->
            </div>
            <!-- / Layout page -->
        </div>

        <!-- Overlay -->
        <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->

    <script>
// Hide the success message after 5 seconds
setTimeout(function() {
    document.getElementById('success-alert').style.display = 'none';
}, 1500);
</script>

