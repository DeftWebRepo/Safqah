<style>

.nice-select,
.nice-select.open .list {
  width: 100%;
  width: 445px;
  border-radius: 8px;
}

.nice-select .list::-webkit-scrollbar {
    width: 0
}

.nice-select .list {
    margin-top: 5px;
    top: 100%;
    border-top: 0;
    border-radius: 0 0 5px 5px;
    max-height: 210px;
    overflow-y: scroll;
    padding: 52px 0 0
}

.nice-select.has-multiple {
    white-space: inherit;
    height: auto;
    padding: 7px 12px;
    min-height: 53px;
    line-height: 22px
}

.nice-select.has-multiple span.current {
    border: 1px solid #CCC;
    background: #EEE;
    padding: 0 10px;
    border-radius: 3px;
    display: inline-block;
    line-height: 24px;
    font-size: 14px;
    margin-bottom: 3px;
    margin-right: 3px
}

.nice-select.has-multiple .multiple-options {
    display: block;
    line-height: 37px;
    margin-left: 30px;
    padding: 0
}

.nice-select .nice-select-search-box {
    box-sizing: border-box;
    position: absolute;
    width: 100%;
    margin-top: 5px;
    top: 100%;
    left: 0;
    z-index: 8;
    padding: 5px;
    background: #FFF;
    opacity: 0;
    pointer-events: none;
    border-radius: 5px 5px 0 0;
    box-shadow: 0 0 0 1px rgba(68, 88, 112, .11);
    -webkit-transform-origin: 50% 0;
    -ms-transform-origin: 50% 0;
    transform-origin: 50% 0;
    -webkit-transform: scale(.75) translateY(-21px);
    -ms-transform: scale(.75) translateY(-21px);
    transform: scale(.75) translateY(-21px);
    -webkit-transition: all .2s cubic-bezier(.5, 0, 0, 1.25), opacity .15s ease-out;
    transition: all .2s cubic-bezier(.5, 0, 0, 1.25), opacity .15s ease-out
}

.nice-select .nice-select-search {
    box-sizing: border-box;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 3px;
    box-shadow: none;
    color: #333;
    display: inline-block;
    vertical-align: middle;
    padding: 7px 12px;
    margin: 0 10px 0 0;
    width: 100%!important;
    min-height: 36px;
    line-height: 22px;
    height: auto;
    outline: 0!important
}

.nice-select.open .nice-select-search-box {
    opacity: 1;
    z-index: 10;
    pointer-events: auto;
    -webkit-transform: scale(1) translateY(0);
    -ms-transform: scale(1) translateY(0);
    transform: scale(1) translateY(0)
}

.remove:hover {
  color: red
}
    </style>

<?php 

function get_customer_name($cid) {

//$query="SELECT `customer_name` FROM `customers` WHERE `cid`='$cid';"

$ci = &get_instance();

// Run the query
$query = $ci->db->get_where('customers', array('cid' => $cid));
$result = $query->row();

// Check if result exists
if ($result) {
    $customer_name = $result->customer_name;
    echo $customer_name;
} else {
    echo "Customer not found.";
}

}

?>
            <div class="layout-page">
                <!-- Navbar --><nav class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme" id="layout-navbar" style="">
                    <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
                        <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                            <i class="bx bx-menu bx-sm"></i>
                        </a>
                    </div>

                    <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
                        <!-- Search -->
                        <!-- <div class="navbar-nav align-items-center">
                            <div class="nav-item d-flex align-items-center">
                                <i class="bx bx-search fs-4 lh-0"></i>
                                <input type="text" class="form-control border-0 shadow-none ps-1 ps-sm-2" placeholder="Search..." aria-label="Search..." />
                            </div>
                        </div> -->
                        <!-- /Search -->

                        <ul class="navbar-nav flex-row align-items-center ms-auto">
                            <!-- User -->
                            <li class="nav-item navbar-dropdown dropdown-user dropdown">
                                <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                                    <div class="avatar avatar-online">
                                        <img src="<?php echo base_url()?>theme/assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle" />
                                    </div>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <a class="dropdown-item" href="#">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 me-3">
                                                    <div class="avatar avatar-online">
                                                        <img src="<?php echo base_url()?>theme/assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle" />
                                                    </div>
                                                </div>
                                                <div class="flex-grow-1">
                                                    <span class="fw-medium d-block">Safqah</span>
                                                    <small class="text-muted">Admin</small>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <div class="dropdown-divider"></div>
                                    </li>
                                
                                    <li>
                                        <a class="dropdown-item" href="<?php echo base_url();?>logout">
                                            <i class="bx bx-power-off me-2"></i>
                                            <span class="align-middle">Log Out</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <!--/ User -->
                        </ul>
                    </div>
                </nav>
                <div class="content-wrapper">
                    <!-- Content -->
                    <div class="container-xxl flex-grow-1 container-p-y">
                        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Sales</span> Management</h4>

                        <!-- Basic Layout & Basic with Icons -->
                        <div class="row">
                            <!-- Basic Layout -->
                            <div class="col-xxl">
                                <div class="card mb-4">
                                    <div class="card-header d-flex align-items-center justify-content-between">
                                        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Edit</span> Sales</h4>
                                    </div>
                                    <div class="card-body">
                                        <form action="<?= base_url('Sales/update/' . $item->s_id) ?>" method="post">
                                            
                                            
                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-company">Product Name</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="product_name" id="basic-default-company" value="<?= $item->product_name ?> " />
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-email">Product Code</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="product_code" id="basic-default-company" value="<?= $item->product_code ?> " />
                                                </div>
                                            </div>
                                            
                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-email">Product Details</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="product_details" id="basic-default-company" value="<?= $item->product_details ?> " />
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-email" >Category</label>
                                                <div class="col-sm-10">
                                                    <select class="form-select" aria-label="Default select example" name="category">
                                                        <?php foreach ($categories as $category): ?>
                                                            <?php $selected = ($category->name == $selectedCategory) ? 'selected' : ''; ?>
                                                            <option value="<?= $category->name ?>" <?= $selected ?>><?= $category->name ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-email">Product Cost</label>
                                                <div class="col-sm-10">
                                                    <input type="text" step="0.01" class="form-control" name="product_cost" id="basic-default-company" value="<?= $item->product_cost ?> " />
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-email">Product Quantity</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="product_qty" id="basic-default-company" value="<?= $item->product_qty?>"/>
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-email">Purchase Source</label>
                                                <div class="col-sm-10">
                                                    <select class="mySelects" id="mySelects" aria-label="Default select example" name="source">
                                                        <option value="0">Select Source</option>
                                                        <option value="Our Shop" <?= ($item->source == "Our Shop") ? 'selected' : '' ?>>Our Shop</option>
                                                        <?php foreach ($suppliers as $supplier): ?>
                                                            <option value="<?= $supplier->supplier_name . ' (' . $supplier->company_name . ')' ?>" <?= ($item->source == $supplier->supplier_name . ' (' . $supplier->company_name . ')') ? 'selected' : '' ?>>
                                                                <?= $supplier->supplier_name ?> (<?= $supplier->company_name ?>)
                                                            </option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                            </div>


                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-email">Product Status</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="status" id="basic-default-company" value="<?= $item->status?> " />
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-email">Sku</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="sku" id="basic-default-company" value="<?= $item->sku?> " />
                                                </div>
                                            </div>

                                                    <div class="row mb-3">
                                                    <label class="col-sm-2 col-form-label" for="basic-default-email">Customer name</label>
                                                    <div class="col-sm-10">
                                                       

                                                        <input type="text" class="form-control" name="customer_name" readonly id="basic-default-company" value="<?= get_customer_name($item->customer_name)?> " />
                                                    </div>
                                                </div>
                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-email">Company Name</label>
                                                <div class="col-sm-10">
                                                  
                                                    <input type="text" id="basic-default-company" class="form-control basic-default-company" name="company" value="<?= $item->company?>"  />
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                             
                                                <div class="col-sm-10">
                                                    <input type="submit" class=" btn btn-primary" name="company" id="basic-default-company" value="Submit" />
                                                </div>
                                            </div>


                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xxl">

                            </div>
                        </div>
                    </div>
                    <!-- / Content -->
                    <!-- Footer -->
                    <footer class="content-footer footer bg-footer-theme">
                        <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                            <div class="mb-2 mb-md-0">
                                © Deft Innovations
                            </div>

                        </div>
                    </footer>
                    <!-- / Footer -->

                    <div class="content-backdrop fade"></div>
                </div>
                <!-- Content wrapper -->
            </div>
            <!-- / Layout page -->
        </div>

        <!-- Overlay -->
        <div class="layout-overlay layout-menu-toggle"></div>
    </div>