<style>
 .input-group-addon {
        padding: 0.5rem 0.75rem;
        margin-bottom: 0;
        font-size: 1rem;
        font-weight: 400;
        line-height: 1.25;
        color: #ffffff;
        text-align: center;
        background-color: #696cff;
        border: 1px solid rgb(105 108 255);
        border-radius: 0.375rem 0 0 0.375rem;
}

.nice-select,
.nice-select.open .list {
  width: 100%;
 
  border-radius: 8px;
}

.nice-select .list::-webkit-scrollbar {
    width: 0
}

.nice-select .list {
    margin-top: 5px;
    top: 100%;
    border-top: 0;
    border-radius: 0 0 5px 5px;
    max-height: 210px;
    overflow-y: scroll;
    padding: 52px 0 0
}

.nice-select.has-multiple {
    white-space: inherit;
    height: auto;
    padding: 7px 12px;
    min-height: 53px;
    line-height: 22px
}

.nice-select.has-multiple span.current {
    border: 1px solid #CCC;
    background: #EEE;
    padding: 0 10px;
    border-radius: 3px;
    display: inline-block;
    line-height: 24px;
    font-size: 14px;
    margin-bottom: 3px;
    margin-right: 3px
}

.nice-select.has-multiple .multiple-options {
    display: block;
    line-height: 37px;
    margin-left: 30px;
    padding: 0
}

.nice-select .nice-select-search-box {
    box-sizing: border-box;
    position: absolute;
    width: 100%;
    margin-top: 5px;
    top: 100%;
    left: 0;
    z-index: 8;
    padding: 5px;
    background: #FFF;
    opacity: 0;
    pointer-events: none;
    border-radius: 5px 5px 0 0;
    box-shadow: 0 0 0 1px rgba(68, 88, 112, .11);
    -webkit-transform-origin: 50% 0;
    -ms-transform-origin: 50% 0;
    transform-origin: 50% 0;
    -webkit-transform: scale(.75) translateY(-21px);
    -ms-transform: scale(.75) translateY(-21px);
    transform: scale(.75) translateY(-21px);
    -webkit-transition: all .2s cubic-bezier(.5, 0, 0, 1.25), opacity .15s ease-out;
    transition: all .2s cubic-bezier(.5, 0, 0, 1.25), opacity .15s ease-out
}

.nice-select .nice-select-search {
    box-sizing: border-box;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 3px;
    box-shadow: none;
    color: #333;
    display: inline-block;
    vertical-align: middle;
    padding: 7px 12px;
    margin: 0 10px 0 0;
    width: 100%!important;
    min-height: 36px;
    line-height: 22px;
    height: auto;
    outline: 0!important
}

.nice-select.open .nice-select-search-box {
    opacity: 1;
    z-index: 10;
    pointer-events: auto;
    -webkit-transform: scale(1) translateY(0);
    -ms-transform: scale(1) translateY(0);
    transform: scale(1) translateY(0)
}

.remove:hover {
  color: red
}

</style>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function() {
        // Get the current date in the format YYYY-MM-DD
        var currentDate = new Date().toISOString().split('T')[0];

        // Set the value of the input field with id "datepicker" to the current date
        $("#transferred_on_inpit").val(currentDate);
    });
</script>

<style>
    .input-group-addon {
        padding: 0.5rem 0.75rem;
        margin-bottom: 0;
        font-size: 1rem;
        font-weight: 400;
        line-height: 1.25;
        color: #ffffff;
        text-align: center;
        background-color: #696cff;
        border: 1px solid rgb(105 108 255);
        border-radius: 0.375rem 0 0 0.375rem;
    }
</style>

<!-- Layout container -->
<div class="layout-page">
    <!-- Navbar --><nav class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme" id="layout-navbar" style="">
    <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
                        <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                            <i class="bx bx-menu bx-sm"></i>
                        </a>
                    </div>

                    <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
                        <!-- Search -->
                        <!-- <div class="navbar-nav align-items-center">
                            <div class="nav-item d-flex align-items-center">
                                <i class="bx bx-search fs-4 lh-0"></i>
                                <input type="text" class="form-control border-0 shadow-none ps-1 ps-sm-2" placeholder="Search..." aria-label="Search..." />
                            </div>
                        </div> -->
                        <!-- /Search -->
                        <div style="font-size:18px;">
                            Stock Management
                        </div>

                        <ul class="navbar-nav flex-row align-items-center ms-auto">
                            <!-- User -->
                            <li class="nav-item navbar-dropdown dropdown-user dropdown">
                                <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                                    <div class="avatar avatar-online">
                                        <img src="<?php echo base_url()?>theme/assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle" />
                                    </div>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <a class="dropdown-item" href="#">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 me-3">
                                                    <div class="avatar avatar-online">
                                                        <img src="<?php echo base_url()?>theme/assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle" />
                                                    </div>
                                                </div>
                                                <div class="flex-grow-1">
                                                    <span class="fw-medium d-block">Safqah</span>
                                                    <small class="text-muted">Admin</small>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <div class="dropdown-divider"></div>
                                    </li>
                                
                                    <li>
                                        <a class="dropdown-item" href="<?php echo base_url();?>logout">
                                            <i class="bx bx-power-off me-2"></i>
                                            <span class="align-middle">Log Out</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <!--/ User -->
                        </ul>
                    </div>
                </nav>
    <div class="content-wrapper">
        <!-- Content -->
        <div class="container-xxl flex-grow-1 container-p-y">
            <!-- <h4 class="py-3 mb-4"><span class="text-muted fw-light"></span> Customers</h4> -->

            <!-- Basic Layout & Basic with Icons -->
            <div class="row">
                <!-- Basic Layout -->
                <div class="col-md-12">
                    <div class="card mb-4">
                        <div class="card-header d-flex align-items-center justify-content-between">
                            <h4 class="py-3 mb-4"  style="display:flex;align-items:center;justify-content:center;width:100%;" ><div>Stock</div> Transfer</h4>
                        </div>
                        <div class="card-body">

                            <?php

                            if ($this->session->flashdata('success')) {
                                echo '<div class="alert alert-success">' . $this->session->flashdata('success') . '</div>';
                            }
                            else if($this->session->flashdata('danger')){
                                echo '<div class="alert alert-danger">' . $this->session->flashdata('danger') . '</div>';
                            }
                            ?>
                            <br>

                            <form action="<?php echo base_url(); ?>VehilceToVehicle/save" method="POST">


                                <div class="row mb-3">
                                    <div class="col-sm-6">
                                        <div class="row">
                                            <label class="col-sm-4 col-form-label" for="vehicle_from">From</label>
                                            <div class="col-sm-8">
                                                <select class="form-select vehicle_from_name" aria-label="vehicle_from vehicle_from_name" name="vehicle_from_name" required>
                                                    <option>Tranfer from</option>
                                                    <option value="SAFQAH">SAFQAH</option>
                                                    <?php foreach ($vehicle as $row) { ?>
                                                        <option value="<?php echo $row->vehicle_number; ?>"><?php echo $row->vehicle_number; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="row">
                                            <label class="col-sm-4 col-form-label" for="vehicle_to">
                                                To</label>
                                            <div class="col-sm-8">

                                                <select class="form-select" aria-label="vehicle_from" name="vehicle_from_to" required>
                                                    <option>Tranfer to</option>
                                                    <option value="SAFQAH">SAFQAH</option>
                                                    <?php foreach ($vehicle as $row) { ?>
                                                        <option value="<?php echo $row->vehicle_number; ?>"><?php echo $row->vehicle_number; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label class="col-sm-2 col-form-label" for="product_category_Select">Product
                                        Category</label>
                                    <div class="col-sm-10">
                                        <!-- <input type="text" class="form-control" id="product_category" name="product_category_select"  placeholder="" /> -->
                                        <select class="form-select " onchange="get_product_list(this.value)" aria-label="product_category_Select" name="product_category" required>
                                            <option selected>Select Category</option>
                                            <?php foreach ($category as $row2) { ?>
                                                <option value="<?php echo $row2->name; ?>"><?php echo $row2->name; ?></option>
                                            <?php } ?>

                                        </select>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-sm-12">
                                        <h6 class="mb-0" style="font-family: &quot;Public Sans&quot;, -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, &quot;Oxygen&quot;, &quot;Ubuntu&quot;, &quot;Cantarell&quot;, &quot;Fira Sans&quot;, &quot;Droid Sans&quot;, &quot;Helvetica Neue&quot;, sans-serif; color: #000; font-weight: 600;">
                                            Product Details</h6>
                                    </div>
                                </div>

                                <div class="ms-0">

                                    <div class="row mb-3">
                                        <div class="col-sm-6">
                                            <div class="row">
                                                <label class="col-sm-4 col-form-label" for="product_name_select">Product
                                                    Name</label>
                                                <div class="col-sm-8">
                                                <div class="plist">
                                                    <select class="selectpicker form-control" id="productNamesSelect" data-live-search="true">
                                                        <option value="">Select Product</option>
                                                      
                                                    </select>
                                                </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="row">
                                                <label class="col-sm-4 col-form-label" for="model_number">Product SKU</label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control" id="model_number_input" name="model_number" placeholder="" required />
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-sm-6">
                                            <div class="row">
                                                <label class="col-sm-4 col-form-label" for="cost_price">Cost
                                                    Price</label>
                                                <div class="col-sm-8">
                                                    <div class="input-group">
                                                        <div class="input-group-addon">SAR</div>
                                                        <input type="text" class="form-control cost_price" id="cost_price_input" name="cost_price" placeholder="" required />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="row">
                                                <label class="col-sm-4 col-form-label" for="selling_price">Selling
                                                    Price</label>
                                                <div class="col-sm-8">

                                                    <div class="input-group">
                                                        <div class="input-group-addon">SAR</div>
                                                        <input type="text" class="form-control selling_price" id="selling_price_input" name="selling_price" placeholder="" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-sm-6">
                                            <div class="row">
                                                <label class="col-sm-4 col-form-label" for="quantity">Quantity</label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control quantity_input" id="quantity_input" name="quantity" placeholder="" oninput="change_total_price_input(this.value)" required />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="row">
                                                <label class="col-sm-4 col-form-label" for="total_price">Total
                                                    Price</label>
                                                <div class="col-sm-8">
                                                    <div class="input-group">
                                                        <div class="input-group-addon">SAR</div>
                                                        <input type="text" class="form-control total_price_input" id="total_price_input" name="total_price" placeholder="" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label class="col-sm-2 col-form-label" for="transferred_on">Transferred On</label>
                                    <div class="col-sm-10">
                                        <input type="date" class="form-control transferred_on_input" id="transferred_on_inpit" name="transferred_on" placeholder="" />
                                    </div>
                                </div>



                                <div class="row justify-content-end">
                                    <div class="col-md-4"></div>
                                    <div class="col-md-4"><button type="submit" class="form-control btn btn-primary">Submit</button></div>
                                    <div class="col-md-4"></div>

                                </div>
                        </div>



                        </form>
                    </div>
                </div>
            </div>
            <div class="col-xxl">
                <div class="col-sm-12">
                    <a href="<?php echo base_url(); ?>VehilceToVehicle/view" class="form-control btn" style="color:white;background-color:black;width:100%;" id="submit" value="Submit"> View Stock Transfer Details</a>
                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->
    <!-- Footer -->
    <footer class="content-footer footer bg-footer-theme">
            <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
            <a href="https://deftinnovations.in/"  target="blank" class="mb-2 mb-md-0 hellos">
                                © Deft Innovations
            </a>

            </div>
        </footer>
    <!-- / Footer -->

    <div class="content-backdrop fade"></div>
</div>
<!-- Content wrapper -->
</div>
<!-- / Layout page -->
</div>

<!-- Overlay -->
<div class="layout-overlay layout-menu-toggle"></div>
</div>

<script>
    function get_product_list(query) {


        var product_category = query;

        var vehicle_from_name=$(".vehicle_from_name").val();

        if (vehicle_from_name=="SAFQAH"){
            $.post('<?php echo base_url(); ?>VehilceToVehicle/get_product_namess?product_category='+product_category, function(response) {




                $('.plist').html(response);

                $(".temp1").addClass("mySelect");








                }); 

                
        }
        else{
        $.post('<?php echo base_url(); ?>VehilceToVehicle/get_product_names?product_category='+product_category+"&vehicle_from_name="+vehicle_from_name, function(response) {




             $('.plist').html(response);

             $(".temp1").addClass("mySelect");





        


            });

            



    }


   }


    

    function product_name_select(query) {

        var query = query;

        console.log(query);

        $.post('<?php echo base_url(); ?>VehilceToVehicle/get_stock_product_sku?query=' + query, function(response) {

            $("#model_number_input").val(response);

        });


        $.post('<?php echo base_url(); ?>VehilceToVehicle/get_stock_item_price?query=' + query, function(response) {

            $("#cost_price_input").val(response);

        });


        $.post('<?php echo base_url(); ?>VehilceToVehicle/get_stock_item_selling_price?query=' + query, function(response) {

            $("#selling_price_input").val(response);

        });



    }
    function get_vehicle_to_vehicle_product(id){

                
$("#model_number_input").val(id);


$.post('<?php echo base_url(); ?>VehilceToVehicle/cost_price?query=' + id, function(response) {

$(".cost_price").val(response);

});

$.post('<?php echo base_url(); ?>VehilceToVehicle/selling_price_input?query=' + id, function(response) {

$(".selling_price").val(response);

});


}

    function get_vehicle_to_vehicle_product(id){

                    
            $("#model_number_input").val(id);


            $.post('<?php echo base_url(); ?>VehilceToVehicle/cost_prices?query=' + id, function(response) {

            $(".cost_price").val(response);

            });

            $.post('<?php echo base_url(); ?>VehilceToVehicle/selling_price_inputs?query=' + id, function(response) {

            $(".selling_price").val(response);

            });


            }

    function change_total_price_input(query) {


        var quantity_input = $("#quantity_input").val()

        var selling_price_input = $("#selling_price_input").val();


        $("#total_price_input").val(quantity_input * selling_price_input)

        // selling_price_input.val(quantity_input)



        // alert(quantity_input)

        //total_price_input





    }
</script>