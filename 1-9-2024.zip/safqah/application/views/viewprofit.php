<style>
    .table th {
        min-width: 100px !important;
    }

    .table th:nth-child(1) {
        min-width: 25px !important;
    }
    /* .dataTables_filter{
    display:none;
} */

</style>

<div class="layout-page">
    <!-- Navbar -->
    <nav class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme" id="layout-navbar" style="">
        <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
            <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                <i class="bx bx-menu bx-sm"></i>
            </a>
        </div>

        <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
            <!-- Search -->
            <div class="navbar-nav align-items-center">
                <div class="nav-item d-flex align-items-center">
                    <i class="bx bx-search fs-4 lh-0"></i>
                    <input type="text" class="form-control border-0 shadow-none ps-1 ps-sm-2" placeholder="Search..." aria-label="Search..."  id="SearchBy"/>
                </div>
            </div>
            <!-- /Search -->

            <ul class="navbar-nav flex-row align-items-center ms-auto">
                <!-- User -->
                <li class="nav-item navbar-dropdown dropdown-user dropdown">
                    <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                        <div class="avatar avatar-online">
                            <img src="<?php echo base_url() ?>theme/assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle" />
                        </div>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li>
                            <a class="dropdown-item" href="#">
                                <div class="d-flex">
                                    <div class="flex-shrink-0 me-3">
                                        <div class="avatar avatar-online">
                                            <img src="<?php echo base_url() ?>theme/assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle" />
                                        </div>
                                    </div>
                                    <div class="flex-grow-1">
                                        <span class="fw-medium d-block">Safqah</span>
                                        <small class="text-muted">Admin</small>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <div class="dropdown-divider"></div>
                        </li>

                        <li>
                            <a class="dropdown-item" href="<?php echo base_url(); ?>logout">
                                <i class="bx bx-power-off me-2"></i>
                                <span class="align-middle">Log Out</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <!--/ User -->
            </ul>
        </div>
    </nav>
    <div class="content-wrapper" style="width: 100%;">
        <!-- Content -->
        <div class="container-xxl flex-grow-1 container-p-y">


            <!-- Basic Layout & Basic with Icons -->
            <div class="row ">
                <!-- Basic Layout -->
                <div class="col-md-12">
                    <div class="card mb-4">
                        <div class="card-header d-flex align-items-center justify-content-between">
                            <h4 class="py-3 mb-4" style="display:flex;align-items:center;justify-content:center;width:100%;">
                                <div> View</div> Profit <div style="margin-left:7px;">Precentage</div>
                            </h4>
                            <div class="btn" style="width:500px;"><a href="<?php echo base_url(); ?>ProfitPercentage/add" style="background-color: #a79ae1;color: #fff;border-radius: 10px;padding: 9px;font-weight: 600 !important;letter-spacing:1px">Profit Precentage</a></div>
                            <a href="<?php echo base_url();?>profit_export_to_pdf" id="pdf"  style="width:350px;" class="btn btn-primary">Export to Pdf</a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="myTable" class="table table-striped  profitTable" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Invoice Number</th>
                                            <th>Customer Name </th>
                                            <th>Product Name</th>
                                            <th>Product SKU</th>
                                            <!-- <th>Product Cost</th> -->
                                            <th>Selling Price</th>
                                            <th>Quantity</th>
                                            <th>Total Selling Price</th>
                                            <th>Profit</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $i = 1;

                                        foreach ($finance as $row) : ?>


                                            <tr>
                                                <td><?= $i++ ?></td>
                                                <td><?= $row->invoice_number ?></td>
                                                <td><?= $row->customer_name ?></td>
                                                <td><?= $row->product_name ?></td>
                                                <td><?= $row->sku ?></td>
                                                <!-- <td><?= $row->product_cost ?></td> -->
                                                <td><?= $row->selling_price ?></td>
                                                <td><?= $row->product_qty ?></td>
                                                <td><?= $row->total_price ?></td>
                                                <td><?= $row->profit ?></td>
                                                <td>
                                                    <!-- Edit button -->

                                                    <!-- Delete button -->
                                                    <a style="margin-top:10px;" href="<?= base_url('ProfitPercentage/delete_profit/' . $row->id) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this item?')">Delete</a>

                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xxl">

                </div>
            </div>
        </div>
        <!-- / Content -->
        <!-- Footer -->
        <footer class="content-footer footer bg-footer-theme">
            <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                <a href="https://deftinnovations.in/" class="mb-2 mb-md-0 hellos">
                    © Deft Innovations
                </a>

            </div>
        </footer>
        <!-- / Footer -->

        <div class="content-backdrop fade"></div>
    </div>
    <!-- Content wrapper -->
</div>
<!-- / Layout page -->
</div>

<!-- Overlay -->
<div class="layout-overlay layout-menu-toggle"></div>
</div>


<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.0.1/css/buttons.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/2.0.1/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.html5.min.js"></script>


<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
   <script>
 
 var table = $('#myTable').DataTable({
            "paging": true,
            "ordering": true,
            "info": true,
            
        });

     
    
        $('#SearchBy').on('change', function () {
    var searchBy = this.value;
    table.column(2).search(searchBy).draw();
        });
  
</script>