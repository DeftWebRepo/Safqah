
<style>
  @import url('https://fonts.googleapis.com/css2?family=Poppins&display=swap');
</style>
<body style="background-image: linear-gradient(
  45deg,
  hsl(240deg 72% 11%) 0%,
  hsl(221deg 100% 11%) 11%,
  hsl(215deg 100% 11%) 22%,
  hsl(209deg 100% 11%) 33%,
  hsl(204deg 100% 11%) 44%,
  hsl(197deg 100% 10%) 56%,
  hsl(188deg 100% 9%) 67%,
  hsl(177deg 100% 8%) 78%,
  hsl(167deg 100% 9%) 89%,
  hsl(155deg 75% 11%) 100%
);">
  <!-- Content -->
  <div class="container-xxl">
    <div class="authentication-wrapper authentication-basic container-p-y">
      <div class="authentication-inner">
        <!-- Register -->
        <div class="card">
          <div class="card-body">
            <!-- Logo -->
            <div class="app-brand justify-content-center">
              <a href="#" class="app-brand-link gap-2">
                <span style="font-size: 25px;font-family: 'Poppins', sans-serif;"> Safqah  Login</span>
              </a>
            </div>
            <!-- /Logo -->
            <form class="mb-3" action="<?php echo base_url();?>login/login_action" method="POST">
              <div class="mb-3">
                <label for="email" class="form-label">Username</label>
                <input type="text" class="form-control email" name="username" placeholder="Username" autofocus />
              </div>
              <div class="mb-3 form-password-toggle">
                <div class="d-flex justify-content-between" >
                  <label class="form-label" for="password">Password</label>
                  <a href="forgot-password.php" style="display: none;">
                    <small>Forgot Password?</small>
                  </a>
                </div>
                <div class="input-group input-group-merge">
                  <input type="password" id="password" class="form-control password" name="password" placeholder="Password" aria-describedby="password" />
                  <span class="input-group-text cursor-pointer"><i class="bx bx-hide"></i></span>
                </div>
              </div>
              <div class="mb-3" style="display: none;">
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" id="remember-me" />
                  <label class="form-check-label" for="remember-me">
                    Remember Me
                  </label>
                </div>
              </div>
              <div class="alert alert-success msg" role="alert" style="display:none;">
                This is a success alert — check it out!
              </div>

              <div class="mb-3">
                <button class="btn btn-primary d-grid w-100" type="submit">
                  Sign in
                </button>
              </div>
            </form>
          </div>
        </div>
        <!-- /Register -->
      </div>
    </div>
  </div>