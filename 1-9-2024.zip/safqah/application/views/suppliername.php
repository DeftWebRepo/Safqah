<?php


// Retrieve the selected course from the AJAX request
$supplierid = $_POST['supplier'];

// Perform database query


// Prepare and execute the query
$query = "SELECT supplier_name FROM supplierproducts WHERE s_id = '$supplierid'";
$result = mysqli_query($conn, $query);

// Fetch the data and send as a JSON response
if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $response = [
        'suppliername' => $row['supplier_name']
        

    ];
    echo json_encode($response);
} else {
    // Course not found
    echo json_encode(['error' => 'Supplier not found']);
}

// Close the database connection
mysqli_close($conn);
?>
