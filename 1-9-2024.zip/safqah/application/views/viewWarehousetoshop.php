<style>
    .input-group-addon {
        padding: 0.5rem 0.75rem;
        margin-bottom: 0;
        font-size: 1rem;
        font-weight: 400;
        line-height: 1.25;
        color: #ffffff;
        text-align: center;
        background-color: #696cff;
        border: 1px solid rgb(105 108 255);
        border-radius: 0.375rem 0 0 0.375rem;
}
.dataTables_filter{
    display:none;
}
    .table th{
        min-width:200px !important;
    }
    .table th:nth-child(1) {
        min-width:50px !important;
}
</style>

<div class="layout-page">
                <!-- Navbar -->
                <nav class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme" id="layout-navbar" style="">
                    <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
                        <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                            <i class="bx bx-menu bx-sm"></i>
                        </a>
                    </div>

                    <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
                        <!-- Search -->
                        <div class="navbar-nav align-items-center">
                            <div class="nav-item d-flex align-items-center">
                                <i class="bx bx-search fs-4 lh-0"></i>
                                <input type="text" class="form-control border-0 shadow-none ps-1 ps-sm-2" placeholder="Search..." aria-label="Search..." id="SearchBy" />
                            </div>
                        </div>
                        <!-- /Search -->

                        <ul class="navbar-nav flex-row align-items-center ms-auto">
                            <!-- User -->
                            <li class="nav-item navbar-dropdown dropdown-user dropdown">
                                <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                                    <div class="avatar avatar-online">
                                        <img src="<?php echo base_url()?>theme/assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle" />
                                    </div>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <a class="dropdown-item" href="#">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 me-3">
                                                    <div class="avatar avatar-online">
                                                        <img src="<?php echo base_url()?>theme/assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle" />
                                                    </div>
                                                </div>
                                                <div class="flex-grow-1">
                                                    <span class="fw-medium d-block">Safqah</span>
                                                    <small class="text-muted">Admin</small>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <div class="dropdown-divider"></div>
                                    </li>
                                
                                    <li>
                                        <a class="dropdown-item" href="<?php echo base_url();?>logout">
                                            <i class="bx bx-power-off me-2"></i>
                                            <span class="align-middle">Log Out</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <!--/ User -->
                        </ul>
                    </div>
                </nav>
                <div class="content-wrapper" style="width: 100%;">
                    <!-- Content -->
                    <div class="container-xxl flex-grow-1 container-p-y">
                        

                        <!-- Basic Layout & Basic with Icons -->
                        <div class="row ">
                            <!-- Basic Layout -->
                            <div class="col-md-12">
                                <div class="card mb-4">
                                    <div class="card-header d-flex align-items-center justify-content-between">
                                        <h4 class="py-3 mb-4" style="display:flex;align-items:center;justify-content:center;width:100%;"><div> View</div>  Warehouse <div style="margin-left:7px;">To</div> Shop Details</h4>
                                        <div class="btn" style="width:300px;" ><a href="<?php echo base_url();?>StockTransfer/warehousetoshop" style="background-color: #a79ae1;color: #fff;border-radius: 10px;padding: 9px;font-weight: 600 !important;letter-spacing:1px">Add Warehouse To Shop</a></div>
                                    </div>
                                    <div class="card-body">
                                    <div class="search-box" style="display:flex;align-items:center;justify-content:center;width:100%; margin-bottom:30px;">
                                        <div class="input-group" style="width:800px;">
                                            <div class="input-group-addon">Search</div>
                                            <input type="text" class="select-form form-control" id="myInput" placeholder="Search Product Name..." oninput="updateDataTable()">
                                        </div>
                                    </div>
                                        <div class="table-responsive">    
                                    <table class="table table-striped" style="width:100%" id="myTable">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Product Category </th>
                    <th>Product Name</th>
                    <th>Product Sku </th>
                    <th>Product Cost</th>
                    <th>Selling Price</th>
                    <th>Quantity</th>
                    <th>Total Selling Price</th>
                    <th>Transfer Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $i=1;
                
                foreach ($warehouse as $row): ?>


                    <tr>
                        <td><?= $i++ ?></td>
                        <td><?= $row->product_category ?></td>
                        <td><?= $row->product_name ?></td>
                        <td><?= $row->model_number ?></td>
                        <td><?= $row->cost_price ?></td>
                        <td><?= $row->selling_price ?></td>
                        <td><?= $row->quantity ?></td>
                        <td><?= $row->total_price ?></td>
                        <td><?= $row->transferred_on ?></td>
                        <td>
                    <!-- Edit button -->
                  
                    <!-- Delete button -->
                    <a  style="margin-top:10px;" href="<?= base_url('StockTransfer/warehousetoshop_delete/' . $row->id) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this item?')">Delete</a>
                  
                     </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
                </div>
                            </div>
                                </div>
                            </div>
                            <div class="col-xxl">

                            </div>
                        </div>
                    </div>
                    <!-- / Content -->
                    <!-- Footer -->
                    <footer class="content-footer footer bg-footer-theme">
                        <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                        <a href="https://deftinnovations.in/" class="mb-2 mb-md-0 hellos">
                                © Deft Innovations
</a>

                        </div>
                    </footer>
                    <!-- / Footer -->

                    <div class="content-backdrop fade"></div>
                </div>
                <!-- Content wrapper -->
            </div>
            <!-- / Layout page -->
        </div>

        <!-- Overlay -->
        <div class="layout-overlay layout-menu-toggle"></div>
    </div>

    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
   <script>
 
 var table = $('#myTable').DataTable({
            "paging": false,
            "ordering": true,
            "info": false,
            
        });

        window.updateDataTable = function () {
            var searchBy = $('#myInput').val();
            table.column(2).search(searchBy).draw(); // Assuming "Product Name" is the fourth column (index 3)
        };

        $('#SearchBy').on('change', function () {
    var searchBy = this.value;
    table.column(2).search(searchBy).draw();

});
    
       
  
</script>