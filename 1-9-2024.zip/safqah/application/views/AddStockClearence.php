<div class="layout-page">
                <!-- Navbar -->
                <div class="content-wrapper">
                    <!-- Content -->
                    <div class="container-xxl flex-grow-1 container-p-y">

                        <h4 class="py-3 mb-4 d-none"><span class="text-muted fw-light">Stock </span> Clearence  </h4>

                        <!-- Basic Layout & Basic with Icons -->
                        <div class="row">
                            <!-- Basic Layout -->
                            <div class="col-xxl">
                                <div class="card mb-4">
                                    <div class="card-header d-flex align-items-center justify-content-center">
                                        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Product </span>Return</h4>
                                    </div>
                                    <div class="card-body">
                                        <form action="<?php echo base_url();?>StockClearence/save" method="post">
                                        <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-company">Product</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="product" id="basic-default-company" placeholder="" />
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-company">SKU</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="sku" id="basic-default-company" placeholder="" />
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-company">Product Quantity</label>
                                                <div class="col-sm-10">
                                                    <input type="number" class="form-control" name="product_qty" id="basic-default-company" placeholder="" />
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-company">PO date</label>
                                                <div class="col-sm-10">
                                                    <input type="date" class="form-control" name="date" id="basic-default-company" placeholder="" />
                                                </div>
                                            </div>
                                            
                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-email">Invoice Number</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="invoice_no" id="basic-default-company" placeholder="" />
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-email">Amount</label>
                                                <div class="col-sm-10">
                                                    <input type="number" step="0.01" class="form-control" name="amount"  id="basic-default-company" placeholder="" />
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-email">Status</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="status" id="basic-default-company" placeholder="" />
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label"  for="basic-default-email">Remarks</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="remark" id="basic-default-company" placeholder="" />
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-email">Return date</label>
                                                <div class="col-sm-10">
                                                    <input type="date" class="form-control" name="today_date" id="basic-default-company" placeholder="" />
                                                </div>
                                            </div>

                                            <div class="row mt-4">
                                        
                                        <div class="col-sm-3">
                                            <input type="submit" class="form-control btn btn-primary" id="submit" value="Submit" />
                                        </div>
                                    </div>

                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xxl">

                            </div>
                        </div>
                    </div>