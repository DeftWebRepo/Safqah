<!-- <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function () {
        // Get the current date in the format YYYY-MM-DD
        var currentDate = new Date().toISOString().split('T')[0];

        // Set the value of the input field with id "datepicker" to the current date
        $("#transferred_on_inpit").val(currentDate);
    });
</script> -->
<style>
    .input-group-addon {
        padding: 0.5rem 0.75rem;
        margin-bottom: 0;
        font-size: 1rem;
        font-weight: 400;
        line-height: 1.25;
        color: #ffffff;
        text-align: center;
        background-color: #696cff;
        border: 1px solid rgb(105 108 255);
        border-radius: 0.375rem 0 0 0.375rem;
}

.nice-select,
.nice-select.open .list {
  width: 100%;
  width: 100%;
  border-radius: 8px;
}

.nice-select .list::-webkit-scrollbar {
    width: 0
}

.nice-select .list {
    margin-top: 5px;
    top: 100%;
    border-top: 0;
    border-radius: 0 0 5px 5px;
    max-height: 210px;
    overflow-y: scroll;
    padding: 52px 0 0
}

.nice-select.has-multiple {
    white-space: inherit;
    height: auto;
    padding: 7px 12px;
    min-height: 53px;
    line-height: 22px
}

.nice-select.has-multiple span.current {
    border: 1px solid #CCC;
    background: #EEE;
    padding: 0 10px;
    border-radius: 3px;
    display: inline-block;
    line-height: 24px;
    font-size: 14px;
    margin-bottom: 3px;
    margin-right: 3px
}

.nice-select.has-multiple .multiple-options {
    display: block;
    line-height: 37px;
    margin-left: 30px;
    padding: 0
}

.nice-select .nice-select-search-box {
    box-sizing: border-box;
    position: absolute;
    width: 100%;
    margin-top: 5px;
    top: 100%;
    left: 0;
    z-index: 8;
    padding: 5px;
    background: #FFF;
    opacity: 0;
    pointer-events: none;
    border-radius: 5px 5px 0 0;
    box-shadow: 0 0 0 1px rgba(68, 88, 112, .11);
    -webkit-transform-origin: 50% 0;
    -ms-transform-origin: 50% 0;
    transform-origin: 50% 0;
    -webkit-transform: scale(.75) translateY(-21px);
    -ms-transform: scale(.75) translateY(-21px);
    transform: scale(.75) translateY(-21px);
    -webkit-transition: all .2s cubic-bezier(.5, 0, 0, 1.25), opacity .15s ease-out;
    transition: all .2s cubic-bezier(.5, 0, 0, 1.25), opacity .15s ease-out
}

.nice-select .nice-select-search {
    box-sizing: border-box;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 3px;
    box-shadow: none;
    color: #333;
    display: inline-block;
    vertical-align: middle;
    padding: 7px 12px;
    margin: 0 10px 0 0;
    width: 100%!important;
    min-height: 36px;
    line-height: 22px;
    height: auto;
    outline: 0!important
}

.nice-select.open .nice-select-search-box {
    opacity: 1;
    z-index: 10;
    pointer-events: auto;
    -webkit-transform: scale(1) translateY(0);
    -ms-transform: scale(1) translateY(0);
    transform: scale(1) translateY(0)
}

.remove:hover {
  color: red
}
.mySelecting .form-control{
    padding: 0 !important;
    margin-top:-20px;
}
 </style>

            <!-- Layout container -->
            <div class="layout-page">
                <!-- Navbar --><nav class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme" id="layout-navbar" style="">
    <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
                        <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                            <i class="bx bx-menu bx-sm"></i>
                        </a>
                    </div>

                    <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
                        <!-- Search -->
                        <!-- <div class="navbar-nav align-items-center">
                            <div class="nav-item d-flex align-items-center">
                                <i class="bx bx-search fs-4 lh-0"></i>
                                <input type="text" class="form-control border-0 shadow-none ps-1 ps-sm-2" placeholder="Search..." aria-label="Search..." />
                            </div>
                        </div> -->
                        <!-- /Search -->
                        <div style="font-size:18px;">
                            Stock Management
                        </div>

                        <ul class="navbar-nav flex-row align-items-center ms-auto">
                            <!-- User -->
                            <li class="nav-item navbar-dropdown dropdown-user dropdown">
                                <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                                    <div class="avatar avatar-online">
                                        <img src="<?php echo base_url()?>theme/assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle" />
                                    </div>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <a class="dropdown-item" href="#">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 me-3">
                                                    <div class="avatar avatar-online">
                                                        <img src="<?php echo base_url()?>theme/assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle" />
                                                    </div>
                                                </div>
                                                <div class="flex-grow-1">
                                                    <span class="fw-medium d-block">Safqah</span>
                                                    <small class="text-muted">Admin</small>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <div class="dropdown-divider"></div>
                                    </li>
                                
                                    <li>
                                        <a class="dropdown-item" href="<?php echo base_url();?>logout">
                                            <i class="bx bx-power-off me-2"></i>
                                            <span class="align-middle">Log Out</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <!--/ User -->
                        </ul>
                    </div>
                </nav>
                <div class="content-wrapper">
                    <!-- Content -->
                    <div class="container-xxl flex-grow-1 container-p-y">
                        <!-- Basic Layout & Basic with Icons -->
                        <div class="row">
                            <!-- Basic Layout -->
                            <div class="col-xxl">
                                <div class="card mb-4">
                                    <div class="card-header d-flex align-items-center justify-content-between">
                                        <h4 class="py-3 mb-4"style="display:flex;align-items:center;justify-content:center;width:100%;"><div>Add </div> Purchase</h4>
                                    </div>
                                    <div class="card-body">
                                    <?php
                                        if ($this->session->flashdata('success')) {
                                            echo '<div id="success-alert" class="alert alert-success">' . $this->session->flashdata('success') . '</div>';
                                        }elseif ($this->session->flashdata('error')){
                                            echo '<div id="success-alert" class="alert alert-danger">' . $this->session->flashdata('error') . '</div>';
                                        }
                                    ?>
                                        <form action="<?php echo base_url();?>StockManagement/save" method="post" style="margin-bottom:20px;">
                                        <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-email">PO Number</label>
                                                <div class="col-sm-10">
                                                    <?php 
                                                        $hellos=rand(1,99999);

                                                    ?>
                                                    <input type="text" id="basic-default-company" class="form-control" name="po_number" value="SAFQ-P<?php echo $hellos;?> " readonly />
                                                </div>
                                        </div>
                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-email">Supplier name</label>
                                                <div class="col-sm-10">

                                                    <select class=" mySelect " id="mySelect"  name="supplier_name" >
                                                        <option selected>Select Supplier</option>
                                                        <?php foreach ($suppliers as $supplier): ?>
                                                    <option value="<?= $supplier->supplier_name ?>"><?= $supplier->supplier_name ?></option>
                                                   <?php endforeach; ?>
                                                    </select> 
                                                    <!-- <input type="text" class="form-control" name="cid" id="basic-default-company" placeholder="" /> -->
                                                </div>
                                            </div>

                                              <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-email">Category</label>
                                                <div class="col-sm-10">
                                                    <select class="form-select" aria-label="Default select example" id="category_select" name="category" required>
                                                        <option selected>Select Category</option>
                                                        <?php foreach ($categories as $category): ?>
                                                    <option value="<?= $category->name ?>"><?= $category->name ?></option>
                                                <?php endforeach; ?>
                                                    </select>
                                                </div>
                                            </div>

                                             <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-company">Product Name</label>
                                                <div class="col-sm-10">

                                                    <select class=" mySelecting form-control"  id="mySelecting" name="item_name" placeholder=""  required >

                                                    </select>
                                                    <!-- <input type="text" class="form-control mySelect" id="mySelect product_name" name="product_name" placeholder=""  required /> -->
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-company">Product SKU</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control sku" id="product_sku" name="product_sku" placeholder=""  required />
                                                </div>
                                            </div>

                                           
                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-company">Cost Price / Unit</label>
                                                <div class="col-sm-10">
                                                <div class="input-group">
                                                        <div class="input-group-addon">SAR</div>
                                                    <input type="text" class="form-control sell" id="cost_price" name="item_price" required placeholder="" readonly/>
                                                        </div>
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-email">Selling Price / Unit</label>
                                                <div class="col-sm-10">
                                                    <div class="input-group">
                                                        <div class="input-group-addon">SAR</div>
                                                        <input type="text" class="form-control  selling" id="basic-default-company" name="item_selling_price" placeholder="" />
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-company">Quantity</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control quantity_input" id="quantity_input" name="item_quantity" required placeholder="" />
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-company">Total Cost Price</label>
                                                <div class="col-sm-10">
                                                <div class="input-group">
                                                        <div class="input-group-addon">SAR</div>
                                                    <input type="text" class="form-control total " id="total" name="total_cost_price" required placeholder="" readonly />
                                                        </div>
                                                </div>
                                            </div>



                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-company">Purchase Invoice </label>
                                                <div class="col-sm-10">
                                               
                                                    <input type="text" class="form-control " id="invoice" name="invoice_number" required placeholder="" />
                                            
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-company">Purchase Date</label>
                                                <div class="col-sm-10">
                                                    <input type="date" class="form-control" id="transferred_on_inpit" name="purchace_date" placeholder="" required />
                                                </div>
                                            </div>

                                            

                                           <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="pterms">Payment Terms</label>
                                                <div class="col-sm-10">
                                                    <select  class="form-control" id="payment" name="payment">
                                                    <option value="">Select Payment</option>
                                                    <option value="cash">Cash</option>
                                                     <option value="credit">Credit</option>
                                                    </select>
                                                </div>
                                            </div>
                                            </div>
                                            <div class="row justify-content-end">
                                                <div class="col-sm-10" style="padding-bottom:20px;">
                                                    <button type="submit" style="display:flex;align-item:center;justify-content:center;width:30%;margin-left:14px;" class="btn btn-primary">Submit</button>
                                                </div>
                                            </div>
                                        </form >
                                    </div>
                                </div>
                            </div>
                            <div class="col-xxl">
                                <div class="col-sm-12" style="margin-bottom: 7px;padding:0 70px 0 70px;">
                               <a href="<?php echo base_url();?>Lpo/view" class="form-control btn" style="color:white;background-color:black;width:100%;" id="submit" value="Submit" > View Purchase </a>
                           </div>
                            </div>
                        </div>
                    </div>
 <!-- Footer -->
                    <footer class="content-footer footer bg-footer-theme">
                        <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                        <a href="https://deftinnovations.in/" target="blank" class="mb-2 mb-md-0 hellos">
                                © Deft Innovations
                        </a>

                        </div>
                    </footer>
                    <!-- / Footer -->

                    <div class="content-backdrop fade"></div>
                </div>
                <!-- Content wrapper -->
            </div>
            <!-- / Layout page -->
        </div>

        <!-- Overlay -->
        <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->

                    <!-- / Content -->
<!-- Include jQuery -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<!-- Include NiceSelect library -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-nice-select/1.1.0/js/jquery.nice-select.min.js"></script>

<!-- Your JavaScript code -->
<script>
$(document).ready(function() {

    // Function to initialize NiceSelect
    function initializeNiceSelect() {
        $('.mySelecting').niceSelect('destroy'); // Destroy existing NiceSelect
        $('.mySelecting').niceSelect(); // Reinitialize NiceSelect
    }

    // Set current date to the "transferred_on_inpit" input field
    var currentDate = new Date().toISOString().split('T')[0];
    $("#transferred_on_inpit").val(currentDate);

    // NiceSelect change event for category selection
    $('#category_select').change(function() {
        var category = $(this).val();
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url();?>Lpo/getcategorypurchase',
            data: { category: category },
            success: function(response) {
                var product = JSON.parse(response);

                // Clear existing options
                $('.mySelecting').empty();

                // Add a default option
                $('.mySelecting').append('<option selected>Select Product Name</option>');

                // Iterate through the products and add options
                product.forEach(function(product) {
                    $('.mySelecting').append('<option value="' + product.Pid + '">' + product.product_name + '</option>');
                });

                // Update NiceSelect
                initializeNiceSelect();
            }
        });
    });

    // NiceSelect change event for product selection
    $('#mySelecting').change(function() {
        var selectedValue = $(this).val();
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url();?>Lpo/getProductpurchasedetails',
            data: { selectedValue: selectedValue },
            success: function(response) {
                var product = JSON.parse(response);
                console.log(product);
                if (product) {
                    $('.sku').val(product.product_sku);
                    $('.sell').val(product.cost_price);
                    $('.selling').val(product.selling_price);
                }
            }
        });
    });

    // Click event for calculating total cost price
    $('#quantity_input').on('input', function() {
        var productQty = $('#quantity_input').val();
        var productCost = $('.sell').val();
        var productTotalPrice = productQty * productCost;
        $('.total').val(productTotalPrice);
    });

    // Hide success alert after 3 seconds
    setTimeout(function() {
        $('#success-alert').hide();
    }, 3000);
});

</script>
          