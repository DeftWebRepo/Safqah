
<style>
 .input-group-addon {
        padding: 0.5rem 0.75rem;
        margin-bottom: 0;
        font-size: 1rem;
        font-weight: 400;
        line-height: 1.25;
        color: #ffffff;
        text-align: center;
        background-color: #696cff;
        border: 1px solid rgb(105 108 255);
        border-radius: 0.375rem 0 0 0.375rem;
}

.nice-select,
.nice-select.open .list {
  width: 100%;
 
  border-radius: 8px;
}

.nice-select .list::-webkit-scrollbar {
    width: 0
}

.nice-select .list {
    margin-top: 5px;
    top: 100%;
    border-top: 0;
    border-radius: 0 0 5px 5px;
    max-height: 210px;
    overflow-y: scroll;
    padding: 52px 0 0
}

.nice-select.has-multiple {
    white-space: inherit;
    height: auto;
    padding: 7px 12px;
    min-height: 53px;
    line-height: 22px
}

.nice-select.has-multiple span.current {
    border: 1px solid #CCC;
    background: #EEE;
    padding: 0 10px;
    border-radius: 3px;
    display: inline-block;
    line-height: 24px;
    font-size: 14px;
    margin-bottom: 3px;
    margin-right: 3px
}

.nice-select.has-multiple .multiple-options {
    display: block;
    line-height: 37px;
    margin-left: 30px;
    padding: 0
}

.nice-select .nice-select-search-box {
    box-sizing: border-box;
    position: absolute;
    width: 100%;
    margin-top: 5px;
    top: 100%;
    left: 0;
    z-index: 8;
    padding: 5px;
    background: #FFF;
    opacity: 0;
    pointer-events: none;
    border-radius: 5px 5px 0 0;
    box-shadow: 0 0 0 1px rgba(68, 88, 112, .11);
    -webkit-transform-origin: 50% 0;
    -ms-transform-origin: 50% 0;
    transform-origin: 50% 0;
    -webkit-transform: scale(.75) translateY(-21px);
    -ms-transform: scale(.75) translateY(-21px);
    transform: scale(.75) translateY(-21px);
    -webkit-transition: all .2s cubic-bezier(.5, 0, 0, 1.25), opacity .15s ease-out;
    transition: all .2s cubic-bezier(.5, 0, 0, 1.25), opacity .15s ease-out
}

.nice-select .nice-select-search {
    box-sizing: border-box;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 3px;
    box-shadow: none;
    color: #333;
    display: inline-block;
    vertical-align: middle;
    padding: 7px 12px;
    margin: 0 10px 0 0;
    width: 100%!important;
    min-height: 36px;
    line-height: 22px;
    height: auto;
    outline: 0!important
}

.nice-select.open .nice-select-search-box {
    opacity: 1;
    z-index: 10;
    pointer-events: auto;
    -webkit-transform: scale(1) translateY(0);
    -ms-transform: scale(1) translateY(0);
    transform: scale(1) translateY(0)
}

.remove:hover {
  color: red
}
    </style>

            <!-- Layout container -->
            <div class="layout-page">
                <!-- Navbar -->
                <nav class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme" id="layout-navbar" style="">
                    <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
                        <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                            <i class="bx bx-menu bx-sm"></i>
                        </a>
                    </div>

                    <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
                        <!-- Search -->
                        <!-- <div class="navbar-nav align-items-center">
                            <div class="nav-item d-flex align-items-center">
                                <i class="bx bx-search fs-4 lh-0"></i>
                                <input type="text" class="form-control border-0 shadow-none ps-1 ps-sm-2" placeholder="Search..." aria-label="Search..." />
                            </div>
                        </div> -->
                        <!-- /Search -->
                        <div style="font-size:18px;">
                            Stock Management
                        </div>

                        <ul class="navbar-nav flex-row align-items-center ms-auto">
                            <!-- User -->
                            <li class="nav-item navbar-dropdown dropdown-user dropdown">
                                <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                                    <div class="avatar avatar-online">
                                        <img src="<?php echo base_url()?>theme/assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle" />
                                    </div>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <a class="dropdown-item" href="#">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 me-3">
                                                    <div class="avatar avatar-online">
                                                        <img src="<?php echo base_url()?>theme/assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle" />
                                                    </div>
                                                </div>
                                                <div class="flex-grow-1">
                                                    <span class="fw-medium d-block">Safqah</span>
                                                    <small class="text-muted">Admin</small>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <div class="dropdown-divider"></div>
                                    </li>
                                
                                    <li>
                                        <a class="dropdown-item" href="<?php echo base_url();?>logout">
                                            <i class="bx bx-power-off me-2"></i>
                                            <span class="align-middle">Log Out</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <!--/ User -->
                        </ul>
                    </div>
                </nav>
                <div class="content-wrapper">
                    <!-- Content -->
                    <div class="container-xxl flex-grow-1 container-p-y">
                        <h4 class="py-3 mb-4"><span class="text-muted fw-light"></span></h4>

                        <!-- Basic Layout & Basic with Icons -->
                        <div class="row">
                            <!-- Basic Layout -->
                            <div class="col-md-6" >
                                <div class="card mb-4" >
                                    <div class="card-header d-flex align-items-center justify-content-between">
                                        <h4 class="py-3 mb-4" style="display:flex;align-items:center;justify-content:center;width:100%;" > <div>Purchase </div>Due </h4>
                                    </div>
                                    <div class="card-body">
                                    <?php
                                        if ($this->session->flashdata('success')) {
                                            echo '<div id="success-alert" class="alert alert-success">' . $this->session->flashdata('success') . '</div>';
                                        }elseif ($this->session->flashdata('error')) {
                                            echo '<div id="success-alert" class="alert alert-danger">' . $this->session->flashdata('error') . '</div>';
                                           
                                        }
                                    ?>
                                        <form action="<?php echo base_url();?>DueAmount/purchasedue_save" method="post">
                                          
                                            
                                        <div class="row mb-3" >
                                                <label class="col-sm-4 col-form-label" for="basic-default-email">Supplier Name</label>
                                                <div class="col-sm-8">
                                                    <select class="mySelect supplier" id="mySelect supplier" onchange="supplierDetails()" name="supplier_name" required >
                                                    <option value="Select Supplier" selected>Select Supplier</option>
                                                        <?php foreach ($suppliers as $supplier): ?>
                                                    <option value="<?= $supplier->supplier_name?>"><?= $supplier->supplier_name?></option>
                                                   <?php endforeach; ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-sm-4 col-form-label" for="basic-default-email">Total Amount </label>
                                                <div class="col-sm-8">
                                                <div class="input-group">
                                                        <div class="input-group-addon">SAR</div>
                                                    <input type="text" name="total_price" value="0" id="company_name" class="form-control cost" id="basic-default-company" placeholder="" required readonly />
                                                </div>
                                              </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-sm-4 col-form-label" for="basic-default-email">Amount Paid</label>
                                                <div class="col-sm-8">
                                                <div class="input-group">
                                                        <div class="input-group-addon">SAR</div>
                                                    <input type="text" name="total_price" value="0" id="company_name" class="form-control sell" id="basic-default-company" placeholder="" required readonly />
                                                </div>
                                              </div>
                                            </div>
                                         
                                            <div class="row mb-3">
                                                <label class="col-sm-4 col-form-label" for="basic-default-email">Current Pay Amount</label>
                                                <div class="col-sm-8">
                                                <div class="input-group">
                                                        <div class="input-group-addon">SAR</div>
                                                    <input type="number" name="price_transfer" value="0" id="quantity_inputs" class="form-control" id="basic-default-company" placeholder="" required />
                                                </div>
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-sm-4 col-form-label" for="basic-default-email"> Pending Due</label>
                                                <div class="col-sm-8">
                                                <div class="input-group">
                                                        <div class="input-group-addon">SAR</div>
                                                    <input type="number" name="due" id="phone_number" value="0" class="form-control total" id="basic-default-company" required  readonly/>
                                                </div>
                                                </div>
                                            </div>
                                            <input type="hidden" class="form-control credits"  id="credits" name="credits" value="credit" placeholder="" required />
                                           <div class=" mb-3" style="margin-bottom: 7px;"> <button type="submit" style="display:flex;align-item:center;justify-content:center;width:64%;margin-left:216px;" class="btn btn-primary ">Submit</button></div>
                                            
                                        </form>
                                    </div>
                                </div>

                                
                            </div>
                            <div class="col-md-6">
                                    <div class="card mb-4" >
                                    <div class="card-header d-flex align-items-center justify-content-between">
                                        <h4 class="py-3 mb-4" style="display:flex;align-items:center;justify-content:center;width:100%;" ><div>Sales</div> Due</h4>
                                        
                                    </div>
                                    <div class="card-body">
                                    <?php
                                        if ($this->session->flashdata('hello')) {
                                            echo '<div id="success-alert" class="alert alert-success">' . $this->session->flashdata('hello') . '</div>';
                                        }elseif ($this->session->flashdata('error')){
                                            echo '<div id="success-alert" class="alert alert-danger">' . $this->session->flashdata('error') . '</div>';
                                        }
                                    ?>
                                        <form action="<?php echo base_url();?>DueAmount/salesdue_save" method="post">
                                            <div class="row mb-3">
                                                <label class="col-sm-4 col-form-label" for="basic-default-email">Customer name</label>
                                                <div class="col-sm-8">

                                                    <select class="mySelect" id="mySelect customer" onchange="customerDetails()" name="customer_name" required>
                                                        <option value="Select Customer" selected>Select Customer</option>
                                                        <?php foreach ($customers as $customer): ?>
                                                    <option value="<?= $customer->customer_name ?>"><?= $customer->customer_name ?></option>
                                                    <?php endforeach; ?>
                                                    </select> 
                                                    <!-- <input type="text" class="form-control" name="cid" id="basic-default-company" placeholder="" /> -->
                                                </div>
                                            </div>
                                            
                                            <div class="row mb-3">
                                                <label class="col-sm-4 col-form-label" for="basic-default-email">Total Amount</label>
                                                <div class="col-sm-8">
                                                    <div class="input-group">
                                                        <div class="input-group-addon">SAR</div>
                                                        <input type="number" class="form-control amount" id="cost_price_input"
                                                            name="total_price" placeholder="" value="0" required readonly />
                                                    </div>
                                                </div>
                                            </div>

                                            

                                            
                                            

                                          

                                            <div class="row mb-3">
                                                <label class="col-sm-4 col-form-label" for="basic-default-email">Received Amount</label>
                                                <div class="col-sm-8">
                                                    <div class="input-group">
                                                        <div class="input-group-addon">SAR</div>
                                                        <input type="number" class="form-control recive" id="cost_price_input"
                                                             placeholder="" value="0" required readonly />
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-sm-4 col-form-label" for="basic-default-email"> Paying Amount </label>
                                                <div class="col-sm-8">
                                                    <div class="input-group">
                                                        <div class="input-group-addon">SAR</div>
                                                        <input type="number" class="form-control " id="quantity_changes"
                                                            name="transfer_price" value="0"  placeholder="" required />
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-sm-4 col-form-label" for="basic-default-email">Pending Due Amount </label>
                                                <div class="col-sm-8">
                                                    <div class="input-group">
                                                        <div class="input-group-addon">SAR</div>
                                                        <input type="number" class="form-control price " id="cost_price_input"
                                                            name="due" placeholder="" value="0" required  readonly/>
                                                    </div>
                                                </div>
                                            </div>
                                            <input type="hidden" class="form-control credit"  id="credit" name="credit" value="credit" placeholder="" required />


                                        

                                           <button type="submit" style="display:flex;align-item:center;justify-content:center;width:64%;margin-left:216px;" class="btn btn-primary ">Submit</button>
                                        

                                        </form>
                                    </div>
                                </div>
                               
                              
                            </div>
                            </div>
                            
                        </div>
                    </div>
                    <!-- / Content -->
                    <!-- Footer -->
                    <footer class="content-footer footer bg-footer-theme">
                        <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                        <a href="https://deftinnovations.in/" target="blank" class="mb-2 mb-md-0 hellos">
                                © Deft Innovations
                        </a>

                        </div>
                    </footer>
                    <!-- / Footer -->

                    <div class="content-backdrop fade"></div>
                </div>
                <!-- Content wrapper -->
            </div>
            <!-- / Layout page -->
        </div>

        <!-- Overlay -->
        <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->


    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

    <script>
function supplierDetails() {
    var supplier = document.getElementById("mySelect supplier").value;
    var suppliers = document.getElementById("mySelect supplier").value;

    var payss = document.getElementById("credits").value;
    console.log(payss);
    
    $.ajax({
        type: 'POST',
        url: '<?php echo base_url();?>DueAmount/getsupllierdetailss',
        data: {
             supplier: supplier,
             payss: payss,
         },
        success: function(response) {
            var products = JSON.parse(response);
            console.log(products);
            if (products && products.length > 0) {
                var totalPriceSum = 0;

                for (var i = 0; i < products.length; i++) {
                    var product = products[i];
                    console.log("Total Price for Product " + (i + 1) + ": " + product.total_cost_price);
                    totalPriceSum += parseFloat(product.total_cost_price);
                }

                console.log("Sum of Total Price: " + totalPriceSum);
                $('.cost').val(totalPriceSum);

                // Trigger the getPriceTransfer function after getting supplier details
            
            }
        }
    });


$.ajax({
    type: 'POST',
    url: 'DueAmount/getpricetransfer',
    data: { suppliers: suppliers },
    success: function(response) {
        // Handle the response from the getpricetransfer function
        var products = JSON.parse(response);
        console.log(products);

        if (products && products.length > 0) {
            var totalpricetransfer = 0;
           

            for (var i = 0; i < products.length; i++) {
                var product = products[i];
                console.log("Total Price for Product " + (i + 1) + ": " + product.price_transfer);
                totalpricetransfer += parseFloat(product.price_transfer);
            }

            console.log("Sum of Total Price Transfer: " + totalpricetransfer);
            
            

            $('#quantity_inputs').change(function() {
                var price_transfer = $(this).val();
                var total_price = $('.cost').val();

                       
           
                    var totaltransfer = totalpricetransfer + parseFloat(price_transfer);

                // Calculate the purchase_due
                var purchase_due = total_price - totaltransfer;

                // Update the .total input with the calculated purchase_due
                $('.total').val(purchase_due);
                console.log(purchase_due);
               
                // Calculate the total transfer by adding the new price_transfer to the existing totalpricetransfer
         

                // Calculate the purchase_due
               
            });
        }
        $('.sell').val(totalpricetransfer);
        if(products && products.length === 0){
            $('#quantity_inputs').change(function() {
                var price_transfer = $(this).val();
                var total_price = $('.cost').val();

                       
           
                var purchase_due = total_price - parseFloat(price_transfer);

                // Update the .total input with the calculated purchase_due
                $('.total').val(purchase_due);
                console.log(purchase_due);
                                // Calculate the total transfer by adding the new price_transfer to the existing totalpricetransfer
         

                // Calculate the purchase_due
               
            });
           
        }
    },
    error: function(jqXHR, textStatus, errorThrown) {
        console.error("AJAX Error:", textStatus, errorThrown);
    }
});
}

function customerDetails(){

    var customer = document.getElementById("mySelect customer").value;
    var customers = document.getElementById("mySelect customer").value;
    var pay = document.getElementById("credit").value;

    console.log(customer);
    console.log(pay);
    console.log(customers);
    

    $.ajax({
        type: 'POST',
        url: '<?php echo base_url();?>DueAmount/getcustomerdetailss',
        data: { 
            customer: customer,
            pay: pay,
        },
        success: function(response) {
            var products = JSON.parse(response);
            console.log(products);
            if (products && products.length > 0) {
                var totalamountSum = 0;

                for (var i = 0; i < products.length; i++) {
                    var product = products[i];
                    console.log("Total Price for Product " + (i + 1) + ": " + product.total_price);
                    totalamountSum += parseFloat(product.total_price);
                }
                console.log("Sum of Total Price: " + totalamountSum);
                $('.amount').val(totalamountSum);

                // Trigger the getPriceTransfer function after getting supplier details
            
            }
        }
    });

    $.ajax({
    type: 'POST',
    url: 'DueAmount/getamounttransfer',
    data: { customers : customers },
    success: function(response) {
        // Handle the response from the getpricetransfer function
        var products = JSON.parse(response);
        console.log(products);

        if (products && products.length > 0) {
            var totalamounttransfer = 0;
        

            for (var i = 0; i < products.length; i++) {
                var product = products[i];
                console.log("Total Price for Product " + (i + 1) + ": " + product.transfer_price);
                totalamounttransfer += parseFloat(product.transfer_price);
            }

            console.log("Sum of Total Price Transfer: " + totalamounttransfer);
          
               $('#quantity_changes').change(function() {
                var price_transfer = $(this).val();
                var total_price = $('.amount').val();

                // Calculate the total transfer by adding the new price_transfer to the existing totalpricetransfer
                var totaltransfer = totalamounttransfer + parseFloat(price_transfer);

                // Calculate the purchase_due
                var purchase_due = total_price - totaltransfer;

                // Update the .total input with the calculated purchase_due
                $('.price').val(purchase_due);
                console.log(purchase_due);
            });

        }
        $('.recive').val(totalamounttransfer);
        if(products && products.length === 0){
            $('#quantity_changes').change(function() {
                var price_transfer = $(this).val();
                var total_price = $('.amount').val();

                       
           
                var purchase_due = total_price - parseFloat(price_transfer);

                // Update the .total input with the calculated purchase_due
                $('.price').val(purchase_due);
                console.log(purchase_due); 
                                // Calculate the total transfer by adding the new price_transfer to the existing totalpricetransfer
         

                // Calculate the purchase_due
               
            });
        }
    },
    error: function(jqXHR, textStatus, errorThrown) {
        console.error("AJAX Error:", textStatus, errorThrown);
    }
});

}




// Add this part to make an AJAX request to the getpricetransfer function

setTimeout(function() {
    document.getElementById('success-alert').style.display = 'none';
}, 3000);
</script>