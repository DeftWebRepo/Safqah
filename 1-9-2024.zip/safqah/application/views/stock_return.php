<style>
 .input-group-addon {
        padding: 0.5rem 0.75rem;
        margin-bottom: 0;
        font-size: 1rem;
        font-weight: 400;
        line-height: 1.25;
        color: #ffffff;
        text-align: center;
        background-color: #696cff;
        border: 1px solid rgb(105 108 255);
        border-radius: 0.375rem 0 0 0.375rem;
}

.nice-select,
.nice-select.open .list {
  width: 100%;
 
  border-radius: 8px;
}

.nice-select .list::-webkit-scrollbar {
    width: 0
}

.nice-select .list {
    margin-top: 5px;
    top: 100%;
    border-top: 0;
    border-radius: 0 0 5px 5px;
    max-height: 210px;
    overflow-y: scroll;
    padding: 52px 0 0
}

.nice-select.has-multiple {
    white-space: inherit;
    height: auto;
    padding: 7px 12px;
    min-height: 53px;
    line-height: 22px
}

.nice-select.has-multiple span.current {
    border: 1px solid #CCC;
    background: #EEE;
    padding: 0 10px;
    border-radius: 3px;
    display: inline-block;
    line-height: 24px;
    font-size: 14px;
    margin-bottom: 3px;
    margin-right: 3px
}

.nice-select.has-multiple .multiple-options {
    display: block;
    line-height: 37px;
    margin-left: 30px;
    padding: 0
}

.nice-select .nice-select-search-box {
    box-sizing: border-box;
    position: absolute;
    width: 100%;
    margin-top: 5px;
    top: 100%;
    left: 0;
    z-index: 8;
    padding: 5px;
    background: #FFF;
    opacity: 0;
    pointer-events: none;
    border-radius: 5px 5px 0 0;
    box-shadow: 0 0 0 1px rgba(68, 88, 112, .11);
    -webkit-transform-origin: 50% 0;
    -ms-transform-origin: 50% 0;
    transform-origin: 50% 0;
    -webkit-transform: scale(.75) translateY(-21px);
    -ms-transform: scale(.75) translateY(-21px);
    transform: scale(.75) translateY(-21px);
    -webkit-transition: all .2s cubic-bezier(.5, 0, 0, 1.25), opacity .15s ease-out;
    transition: all .2s cubic-bezier(.5, 0, 0, 1.25), opacity .15s ease-out
}

.nice-select .nice-select-search {
    box-sizing: border-box;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 3px;
    box-shadow: none;
    color: #333;
    display: inline-block;
    vertical-align: middle;
    padding: 7px 12px;
    margin: 0 10px 0 0;
    width: 100%!important;
    min-height: 36px;
    line-height: 22px;
    height: auto;
    outline: 0!important
}

.nice-select.open .nice-select-search-box {
    opacity: 1;
    z-index: 10;
    pointer-events: auto;
    -webkit-transform: scale(1) translateY(0);
    -ms-transform: scale(1) translateY(0);
    transform: scale(1) translateY(0)
}

.remove:hover {
  color: red
}

</style>

<div class="layout-page">
                <!-- Navbar -->
                <nav class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme" id="layout-navbar" style="">
                    <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
                        <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                            <i class="bx bx-menu bx-sm"></i>
                        </a>
                    </div>

                    <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
                        <!-- Search -->
                        <!-- <div class="navbar-nav align-items-center">
                            <div class="nav-item d-flex align-items-center">
                                <i class="bx bx-search fs-4 lh-0"></i>
                                <input type="text" class="form-control border-0 shadow-none ps-1 ps-sm-2" placeholder="Search..." aria-label="Search..." />
                            </div>
                        </div> -->
                        <!-- /Search -->

                        <ul class="navbar-nav flex-row align-items-center ms-auto">
                            <!-- User -->
                            <li class="nav-item navbar-dropdown dropdown-user dropdown">
                                <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                                    <div class="avatar avatar-online">
                                        <img src="<?php echo base_url()?>theme/assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle" />
                                    </div>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <a class="dropdown-item" href="#">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 me-3">
                                                    <div class="avatar avatar-online">
                                                        <img src="<?php echo base_url()?>theme/assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle" />
                                                    </div>
                                                </div>
                                                <div class="flex-grow-1">
                                                    <span class="fw-medium d-block">Safqah</span>
                                                    <small class="text-muted">Admin</small>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <div class="dropdown-divider"></div>
                                    </li>
                                
                                    <li>
                                        <a class="dropdown-item" href="<?php echo base_url();?>logout">
                                            <i class="bx bx-power-off me-2"></i>
                                            <span class="align-middle">Log Out</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <!--/ User -->
                        </ul>
                    </div>
                </nav>
                <div class="content-wrapper">
                    <!-- Content -->
                    <div class="container-xxl flex-grow-1 container-p-y" style="display:flex;align-item:center;justify-content:center;width:100%;">

                       

                        <!-- Basic Layout & Basic with Icons -->
                        <div class="row mt-5" style="display:flex;align-item:center;justify-content:center;width:80%;">
                            <!-- Basic Layout -->
                            <div class="col-md-11">
                                <div class="card mb-4">
                                    <div class="card-header d-flex align-items-center justify-content-center">
                                    <h4 class="py-3 mb-4 " style="display:flex;align-items:center;justify-content:center;width:100%;"> <div> Purchase </div> Return  </h4>
                                    </div>
                                    <div class="card-body">
                                    <?php
                                        if ($this->session->flashdata('success')) {
                                            echo '<div id="success-alert" class="alert alert-success">' . $this->session->flashdata('success') . '</div>';
                                        }elseif ($this->session->flashdata('error')){
                                            echo '<div id="success-alert" class="alert alert-danger">' . $this->session->flashdata('error') . '</div>';
                                           
                                        }
                                    ?>

                                        <form action="<?php echo base_url();?>StockClearence/save_stock_return" method="post">
                                        <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-company">Product</label>
                                                <div class="col-sm-10">
                                                    <!-- <input type="text" class="form-control" name="product" id="basic-default-company" placeholder="" /> -->
                                                    <select class="mySelect product_name_select" name="product"  onchange="product_name_select(this.value)" aria-label="product_name_select"
                                                        name="product_name" required>
                                                        <option selected>Select Product</option>
                                                        <?php foreach ($stock as $row3){ ?>
                                                    <option value="<?php echo $row3->pid;?>"><?php echo $row3->item_name;?></option>
                                                    <?php } ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-company">SKU</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control sku" name="sku" id="basic-default-company" placeholder="" readonly/>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-company">Product Quantity</label>
                                                <div class="col-sm-10">
                                                    <input type="number" class="form-control product_qty" oninput="get_sum(this.value)"  name="product_qty" id="basic-default-company" placeholder="" />
                                                </div>
                                            </div>
                                            <!-- <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-company">PO date</label>
                                                <div class="col-sm-10">
                                                    <input type="date" class="form-control purchace_date" name="podate" id="basic-default-company" placeholder="" />
                                                </div>
                                            </div> -->
                                            
                                            <!-- <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-email">Invoice Number</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="invoice_no" id="basic-default-company" placeholder="" />
                                                </div>
                                            </div> -->

                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-email">Product Cost</label>
                                                <div class="col-sm-10">
                                                    <input type="number" step="0.01" class="form-control item_selling_price" name="selling_price"  id="basic-default-company" placeholder="" readonly />
                                                </div>
                                            </div>

                                            <!-- <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-email">Total Price</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control " name="total_price" id="basic-default-company" placeholder="" readonly/>
                                                </div>
                                            </div> -->

                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label"  for="basic-default-email">Remarks</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="remark" id="basic-default-company" placeholder="" />
                                                </div>
                                            </div>

                                            <!-- <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-email">Return date</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control datepicker" name="return_date" id="basic-default-company today_date" placeholder="" />
                                                </div>
                                            </div> -->

                                              <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-email">Total Selling Price</label>
                                                <div class="col-sm-10">
                                                    <input type="text"  class="form-control total_selling_pricing" name="total_selling_pricing"  id="basic-default-company" placeholder="" />
                                                </div>
                                            </div>

                                            <div class="row mt-4">
                                         <div class="col-sm-2">
                                         </div>
                                        <div class="col-sm-4 justify-content-center">
                                            <button type="submit" class="form-control btn btn-primary" id="submit">
                                                  <i class="tf-icons bx bx-save"></i>&nbsp;Save
                                            </button>

                                            
                                        </div>
                                            <div class="col-sm-4">
                                                    <a href="<?php echo base_url();?>StockClearence/view_return" class="form-control btn btn-primary" id="submit">
                                                  <i class="tf-icons bx bx-save"></i>&nbsp;View Purchase Return
                                                     </a>
                                         </div>
                                    </div>

                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xxl">

                            </div>
                        </div>
                        </div>
                    <!-- / Content -->
                    <!-- Footer -->
                    <footer class="content-footer footer bg-footer-theme">
                        <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                        <a href="https://deftinnovations.in/" target="blank" class="mb-2 mb-md-0 hellos">
                                © Deft Innovations
                        </a>

                        </div>
                    </footer>
                    <!-- / Footer -->

                    <div class="content-backdrop fade"></div>
                </div>
                <!-- Content wrapper -->
            </div>
            <!-- / Layout page -->
        </div>

        <!-- Overlay -->
        <div class="layout-overlay layout-menu-toggle"></div>
    </div>

<script>

    function get_sum(qry){


     var product_qty=$(".product_qty").val();

     var item_selling_price=$(".item_selling_price").val();


     $(".total_selling_pricing").val(product_qty*item_selling_price);


    }

function product_name_select(query) {

    var query = query;

    $.post('<?php echo base_url();?>StockClearence/sku?query='+query,function(response) {
       
       $(".sku").val(response);

    });

    $.post('<?php echo base_url();?>StockClearence/purchace_date?query='+query,function(response) {
       
       $(".purchace_date").val(response);

    });


     $.post('<?php echo base_url();?>StockClearence/item_price?query='+query,function(response) {
       
       $(".item_selling_price").val(response);

    });

    
    
}

</script>

<script>
// Hide the success message after 5 seconds
setTimeout(function() {
    document.getElementById('success-alert').style.display = 'none';
}, 4000);
</script>

