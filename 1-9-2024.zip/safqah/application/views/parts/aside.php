<style>
    .menu-icon {
        flex-grow: 0;
        flex-shrink: 0;
        margin-right: 0.5rem;
        font-size: 26px;
        color: #fff;
    }

    .dash {
        color: #fff;
    }

    .badge {
        color: #000 !important;
        font-weight: 600 !important;
        font-size: 14px !important;
        border-radius: 5px !important;

    }

    .menu-link:hover {
        background-color: rgb(224 224 224 / 20%) !important;

    }
</style>

<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme" style="background: linear-gradient(90deg, black, #000000);">
    <div class="app-brand demo">
        <a href="<?php echo base_url(); ?>dashboard" class="app-brand-link">
            <span class="app-brand-logo demo">

            </span>
            <span class="app-brand-text demo menu-text fw-bold ms-2" style="font-size:30px;text-transform:uppercase;font-weight:700;color:#fff;letter-spacing:2px;">Safqah</span>
        </a>

        <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
            <i class="bx bx-chevron-left bx-sm align-middle"></i>
        </a>
    </div>

    <div class="menu-inner-shadow"></div>

    <ul class="menu-inner py-1">
        <!-- Dashboards -->


        <li class="menu-item">
            <a href="<?php echo base_url(); ?>dashboard" class="menu-link ">
                <i class="menu-icon tf-icons bx bx-home-circle" style="color:#fff;"></i>
                <div data-i18n="Dashboards" class="dash" style="color:#fff;">Dashboard</div>
            </a>

        </li>


        <li class="menu-item">
            <a href="<?php echo base_url(); ?>category" class=" menu-link ">
                <i class="menu-icon tf-icons bx bx-category-alt"></i>
                <div data-i18n="Dashboards" class="dash">Category</div>

            </a>
        </li>
        <li class="menu-item">
            <a href="<?php echo base_url(); ?>Products/view" class="menu-link">
                <i class="menu-icon tf-icons bx bx-bus"></i>
                <div data-i18n="Dashboards" class="dash">Products</div>

            </a>

        </li>

        <li class="menu-item">
            <a href="<?php echo base_url(); ?>supplier-management/add" class="menu-link">
                <i class="menu-icon tf-icons bx bx-grid"></i>
                <div data-i18n="Dashboards" class="dash">Supplier</div>

            </a>
        </li>
        <li class="menu-item">
            <a href="<?php echo base_url(); ?>CustomerManagement/addCustomer" class="menu-link ">
                <i class="menu-icon tf-icons bx bx-grid"></i>
                <div data-i18n="Dashboards" class="dash">Customer </div>

            </a>
            <ul class="menu-sub">
                <li class="menu-item">
                    <a href="<?php echo base_url(); ?>CustomerManagement/addCustomer" class="menu-link">
                        <div data-i18n="CRM">Add Customer</div>
                        <div class="badge bg-label-primary fs-tiny rounded-pill ms-auto">Counts</div>
                    </a>
                </li>
                <li class="menu-item">
                    <a href="<?php echo base_url(); ?>CustomerManagement/viewCustomer" class="menu-link">
                        <div data-i18n="Analytics">View Customer</div>
                    </a>
                </li>
            </ul>

        </li>
        <li class="menu-item">
            <a href="<?php echo base_url(); ?>Vehicle/add" class="menu-link">
                <i class="menu-icon tf-icons bx bx-bus"></i>
                <div data-i18n="Dashboards" class="dash">Vehicle</div>

            </a>

        </li>

        <li class="menu-item">
            <a href="<?php echo base_url(); ?>Lpo/add" class="menu-link">
                <i class="menu-icon tf-icons bx bx-grid"></i>
                <div data-i18n="Dashboards" class="dash">Purchase</div>

            </a>

        </li>

        <li class="menu-item">
            <a href="<?php echo base_url(); ?>stock-management/view" class="menu-link ">
                <i class="menu-icon tf-icons bx bx-grid"></i>
                <div data-i18n="Dashboards" class="dash">Warehouse </div>

            </a>

        </li>


        <!-- <li class="menu-item">
            <a href="<?php //echo base_url(); ?>StockTransfer/warehousetoshop" class="menu-link">
                <i class="menu-icon tf-icons bx bx-bus"></i>
                <div data-i18n="Dashboards" class="dash">Warehouse to Shop</div>

            </a>
        </li> -->

        <!-- <li class="menu-item">
            <a href="<?php //echo base_url(); ?>StockTransfer/View_Shop_Stock" class="menu-link">
                <i class="menu-icon tf-icons bx bx-bus"></i>
                <div data-i18n="Dashboards" class="dash">View Shop Stock</div>

            </a>
        </li> -->

        <!-- <li class="menu-item">
            <a href="<?php //echo base_url(); ?>Shoptowarehouse/add" class="menu-link">
                <i class="menu-icon tf-icons bx bx-bus"></i>
                <div data-i18n="Dashboards" class="dash">Shop to Warehouse</div>

            </a>
        </li> -->



        <!-- <li class="menu-item">
            <a href="<?php //echo base_url(); ?>StockTransfer/warehousetovehicle" class="menu-link">
                <i class="menu-icon tf-icons bx bx-bus"></i>
                <div data-i18n="Dashboards" class="dash">Warehouse to Vehicle</div>

            </a>
        </li> -->
        <!-- <li class="menu-item">
            <a href="<?php //echo base_url(); ?>VehicletoWarehouse/vehicletowarehouse" class="menu-link">
                <i class="menu-icon tf-icons bx bx-bus"></i>
                <div data-i18n="Dashboards" class="dash">Vehicle to Warehouse </div>

            </a>
        </li> -->
        <!-- <li class="menu-item">
            <a href="<?php //echo base_url(); ?>Shoptovehicle/add" class="menu-link">
                <i class="menu-icon tf-icons bx bx-bus"></i>
                <div data-i18n="Dashboards" class="dash">Shop to Vehicle</div>

            </a>
        </li> -->
        <!-- <li class="menu-item">
            <a href="<?php //echo base_url(); ?>VehicletoWarehouse/vehicletoshop" class="menu-link">
                <i class="menu-icon tf-icons bx bx-bus"></i>
                <div data-i18n="Dashboards" class="dash">Vehicle to Shop </div>

            </a>
        </li> -->

        <!-- <li class="menu-item">
            <a href="<?php //echo base_url(); ?>StockTransfer/View_Vehicle_Stock" class="menu-link">
                <i class="menu-icon tf-icons bx bx-bus"></i>
                <div data-i18n="Dashboards" class="dash">View Vehicle Stock</div>

            </a>
        </li> -->


        <li class="menu-item">
            <a href="<?php echo base_url(); ?>StockTransfer/vehicletovehicle" class="menu-link">
                <i class="menu-icon tf-icons bx bx-bus"></i>
                <div data-i18n="Dashboards" class="dash">Stock Transfer</div>

            </a>
        </li>

        <li class="menu-item">
            <a href="<?php echo base_url(); ?>Sales/add" class="menu-link ">
                <i class="menu-icon tf-icons bx bx-grid"></i>
                <div data-i18n="Dashboards" class="dash">Sales</div>

            </a>
        </li>

        <li class="menu-item">
            <a href="<?php echo base_url(); ?>StockClearence/add_stock_return" class="menu-link ">
                <i class="menu-icon tf-icons bx bx-store-alt"></i>
                <div data-i18n="Dashboards" class="dash">Purchase Return </div>

            </a>

        </li>


        <li class="menu-item">
            <a href="<?php echo base_url(); ?>add-stock-return" class="menu-link ">
                <i class="menu-icon tf-icons bx bx-grid"></i>
                <div data-i18n="Dashboards" class="dash">Sales Return </div>

            </a>
        </li>
        <li class="menu-item">
            <a href="<?php echo base_url(); ?>add-sales-return" class="menu-link ">
                <i class="menu-icon tf-icons bx bx-store-alt"></i>
                <div data-i18n="Dashboards" class="dash">Damaged Sales Return </div>

            </a>

        </li>

        <!-- <li class="menu-item">
            <a href="javascript:void(0);" class="menu-link ">
                <i class="menu-icon tf-icons bx bx-grid"></i>
                <div data-i18n="Dashboards" class="dash" >Delivery Vehicle Stock</div>
                <div class="badge bg-label-primary fs-tiny rounded-pill ms-auto">1</div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item">
                    <a href="#"  class="menu-link">
                        <div data-i18n="CRM">Add Delivery Vehicle Stock</div>
                        <div class="badge bg-label-primary fs-tiny rounded-pill ms-auto">Counts</div>
                    </a>
                </li>
                <li class="menu-item">
                    <a href="#" class="menu-link">
                        <div data-i18n="Analytics">View Delivery Vehicle Stock</div>
                    </a>
                </li> 
            </ul>
        </li> -->

        <li class="menu-item">
            <a href="<?php echo base_url(); ?>ProfitPercentage/add" class="menu-link ">
                <i class="menu-icon tf-icons bx bx-grid"></i>
                <div data-i18n="Dashboards" class="dash">Profit Percentage</div>
            </a>

        </li>
        <li class="menu-item">
            <a href="<?php echo base_url(); ?>DueAmount" class="menu-link ">
                <i class="menu-icon tf-icons bx bx-grid"></i>
                <div data-i18n="Dashboards" class="dash">Due Amount</div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item">
                    <a href="#" class="menu-link">
                        <div data-i18n="CRM">Add Job card</div>
                        <div class="badge bg-label-primary fs-tiny rounded-pill ms-auto">Counts</div>
                    </a>
                </li>
                <li class="menu-item">
                    <a href="#" class="menu-link">
                        <div data-i18n="Analytics">View Job card</div>
                    </a>
                </li>
            </ul>
        </li>

        <li class="menu-item">
            <a href="<?php echo base_url(); ?>logout" class="menu-link ">
                <i class="menu-icon bx bx-power-off me-2"></i>
                <div data-i18n="Dashboards" class="dash">Logout</div>
            </a>

        </li>



    </ul>
</aside>