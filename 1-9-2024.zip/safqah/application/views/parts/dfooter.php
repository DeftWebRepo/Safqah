    <script src="theme/assets/vendor/libs/jquery/jquery.js"></script>
    <script src="theme/assets/vendor/libs/popper/popper.js"></script>
    <script src="theme/assets/vendor/js/bootstrap.js"></script>
    <script src="theme/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="theme/assets/vendor/js/menu.js"></script>
    <script src="theme/assets/vendor/libs/apex-charts/apexcharts.js"></script>
    <!-- Main JS -->
    <script src="theme/assets/js/main.js"></script>
    <!-- Page JS -->
    <script src="theme/assets/js/dashboards-analytics.js"></script>

 

</body>

</html>