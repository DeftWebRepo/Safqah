
 <style>
 .input-group-addon {
        padding: 0.5rem 0.75rem;
        margin-bottom: 0;
        font-size: 1rem;
        font-weight: 400;
        line-height: 1.25;
        color: #ffffff;
        text-align: center;
        background-color: #696cff;
        border: 1px solid rgb(105 108 255);
        border-radius: 0.375rem 0 0 0.375rem;
}

.nice-select,
.nice-select.open .list {
  width: 100%;
 
  border-radius: 8px;
}

.nice-select .list::-webkit-scrollbar {
    width: 0
}

.nice-select .list {
    margin-top: 5px;
    top: 100%;
    border-top: 0;
    border-radius: 0 0 5px 5px;
    max-height: 210px;
    overflow-y: scroll;
    padding: 52px 0 0
}

.nice-select.has-multiple {
    white-space: inherit;
    height: auto;
    padding: 7px 12px;
    min-height: 53px;
    line-height: 22px
}

.nice-select.has-multiple span.current {
    border: 1px solid #CCC;
    background: #EEE;
    padding: 0 10px;
    border-radius: 3px;
    display: inline-block;
    line-height: 24px;
    font-size: 14px;
    margin-bottom: 3px;
    margin-right: 3px
}

.nice-select.has-multiple .multiple-options {
    display: block;
    line-height: 37px;
    margin-left: 30px;
    padding: 0
}

.nice-select .nice-select-search-box {
    box-sizing: border-box;
    position: absolute;
    width: 100%;
    margin-top: 5px;
    top: 100%;
    left: 0;
    z-index: 8;
    padding: 5px;
    background: #FFF;
    opacity: 0;
    pointer-events: none;
    border-radius: 5px 5px 0 0;
    box-shadow: 0 0 0 1px rgba(68, 88, 112, .11);
    -webkit-transform-origin: 50% 0;
    -ms-transform-origin: 50% 0;
    transform-origin: 50% 0;
    -webkit-transform: scale(.75) translateY(-21px);
    -ms-transform: scale(.75) translateY(-21px);
    transform: scale(.75) translateY(-21px);
    -webkit-transition: all .2s cubic-bezier(.5, 0, 0, 1.25), opacity .15s ease-out;
    transition: all .2s cubic-bezier(.5, 0, 0, 1.25), opacity .15s ease-out
}

.nice-select .nice-select-search {
    box-sizing: border-box;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 3px;
    box-shadow: none;
    color: #333;
    display: inline-block;
    vertical-align: middle;
    padding: 7px 12px;
    margin: 0 10px 0 0;
    width: 100%!important;
    min-height: 36px;
    line-height: 22px;
    height: auto;
    outline: 0!important
}

.nice-select.open .nice-select-search-box {
    opacity: 1;
    z-index: 10;
    pointer-events: auto;
    -webkit-transform: scale(1) translateY(0);
    -ms-transform: scale(1) translateY(0);
    transform: scale(1) translateY(0)
}

.remove:hover {
  color: red
}
    </style>

            <!-- Layout container -->
            <div class="layout-page">
                <!-- Navbar -->
                <nav class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme" id="layout-navbar" style="">
                    <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
                        <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                            <i class="bx bx-menu bx-sm"></i>
                        </a>
                    </div>

                    <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
                        <!-- Search -->
                        <!-- <div class="navbar-nav align-items-center">
                            <div class="nav-item d-flex align-items-center">
                                <i class="bx bx-search fs-4 lh-0"></i>
                                <input type="text" class="form-control border-0 shadow-none ps-1 ps-sm-2" placeholder="Search..." aria-label="Search..." />
                            </div>
                        </div> -->
                        <!-- /Search -->
                        <div style="font-size:18px;">
                            Stock Management
                        </div>

                        <ul class="navbar-nav flex-row align-items-center ms-auto">
                            <!-- User -->
                            <li class="nav-item navbar-dropdown dropdown-user dropdown">
                                <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                                    <div class="avatar avatar-online">
                                        <img src="<?php echo base_url()?>theme/assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle" />
                                    </div>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <a class="dropdown-item" href="#">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 me-3">
                                                    <div class="avatar avatar-online">
                                                        <img src="<?php echo base_url()?>theme/assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle" />
                                                    </div>
                                                </div>
                                                <div class="flex-grow-1">
                                                    <span class="fw-medium d-block">Safqah</span>
                                                    <small class="text-muted">Admin</small>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <div class="dropdown-divider"></div>
                                    </li>
                                
                                    <li>
                                        <a class="dropdown-item" href="<?php echo base_url();?>logout">
                                            <i class="bx bx-power-off me-2"></i>
                                            <span class="align-middle">Log Out</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <!--/ User -->
                        </ul>
                    </div>
                </nav>
                <div class="content-wrapper">
                    <!-- Content -->
                    <div class="container-xxl flex-grow-1 container-p-y">
                        <h4 class="py-3 mb-4"><span class="text-muted fw-light"></span></h4>

                        <!-- Basic Layout & Basic with Icons -->
                        <div class="row" style="display:flex;justify-content:center;">
                            <!-- Basic Layout -->
                            <div class="col-md-9" >
                                <div class="card mb-4" >
                                    <div class="card-header d-flex align-items-center justify-content-between">
                                        <h4 class="py-3 mb-4" style="display:flex;align-items:center;justify-content:center;width:100%;" > <div>Add </div> Suppliers</h4>
                                    </div>
                                    <div class="card-body">
                                    <?php
                                        if ($this->session->flashdata('hello')) {
                                            echo '<div id="success-alert" class="alert alert-success">' . $this->session->flashdata('hello') . '</div>';
                                        }elseif ($this->session->flashdata('error')) {
                                            echo '<div id="success-alert" class="alert alert-danger">' . $this->session->flashdata('error') . '</div>';
                                           
                                        }
                                    ?>
                                        <form action="<?php echo base_url();?>SupplierManagement/save" method="POST">
                                          
                                            
                                            <div class="row mb-3">
                                                     <label class="col-sm-4 col-form-label" for="supplier_name">Supplier Name</label>
                                                     <div class="col-sm-8">
                                                         <input type="text" name="supplier_name" id="supplier_name" class="form-control" required placeholder="" />
                                                     </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-sm-4 col-form-label" for="basic-default-email">Company Name</label>
                                                <div class="col-sm-8">
                                                    <input type="text" name="company_name" id="company_name" class="form-control" id="basic-default-company" placeholder="" required />
                                                </div>
                                            </div>
                                            
                                            <div class="row mb-3">
                                                <label class="col-sm-4 col-form-label" for="basic-default-email">Address</label>
                                                <div class="col-sm-8">
                                                    <input type="text" name="address" id="address" class="form-control" id="basic-default-company" placeholder="" required />
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-sm-4 col-form-label" for="basic-default-email">Phone Number</label>
                                                <div class="col-sm-8">
                                                    <input type="text" name="phone_number" id="phone_number" class="form-control" id="basic-default-company" required placeholder="Phone Number" />
                                                </div>
                                            </div>
                                           <div class="row mb-3" style="margin-bottom: 10px;"> <div class="col-sm-4"></div><div class="col-sm-8"> <button type="submit" style="display:flex;align-item:center;justify-content:center;width:100%;" class="btn btn-primary">Submit</button></div></div>
                                            
                                        </form>
                                    </div>
                                </div>
                                <div class="col-sm-12" style="margin-bottom: 7px;padding:0 70px 0 70px;">
                               <a href="<?php echo base_url();?>SupplierManagement/view" class="form-control btn" style="color:white;background-color:black;width:100%;" id="submit" value="Submit" > View Suppliers </a>
                           </div>
                                
                            </div>
                            <div class="col-md-6" style="display:none;">
                                    <div class="card mb-4" >
                                    <div class="card-header d-flex align-items-center justify-content-between">
                                        <h4 class="py-3 mb-4" style="display:flex;align-items:center;justify-content:center;width:100%;" ><div>Add </div> Products</h4>
                                        
                                    </div>
                                    <div class="card-body">
                                    <?php
                                        if ($this->session->flashdata('success')) {
                                            echo '<div id="success-alert" class="alert alert-success">' . $this->session->flashdata('success') . '</div>';
                                        }elseif ($this->session->flashdata('error')){
                                            echo '<div id="success-alert" class="alert alert-danger">' . $this->session->flashdata('error') . '</div>';
                                           
                                        }
                                    ?>
                                        <form action="<?php echo base_url();?>SupplierProducts/save" method="post">
                                            <div class="row mb-3" >
                                                <label class="col-sm-4 col-form-label" for="basic-default-email">Supplier Name</label>
                                                <div class="col-sm-8">
                                                    <select class="mySelect " id="mySelect"  name="supplier_name" >
                                                        <option selected>Search Supplier</option>
                                                        <?php foreach ($suppliers as $supplier): ?>
                                                    <option value="<?= $supplier->supplier_name?>"><?= $supplier->supplier_name .'(' . $supplier->company_name .')'?></option>
                                                   <?php endforeach; ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <label class="col-sm-4 col-form-label" for="basic-default-email">Product Category</label>
                                                <div class="col-sm-8">
                                                     <select class="form-select" aria-label="Default select example" name="product_category" required>
                                                        <option selected>Select Category</option>
                                                        <?php foreach ($categories as $category): ?>
                                                    <option value="<?= $category->name ?>"><?= $category->name ?></option>
                                                <?php endforeach; ?>
                                                    </select>
                                                </div>
                                            </div>
                                        
                                            <div class="row mb-3">
                                                <label class="col-sm-4 col-form-label" for="basic-default-company">Product Name</label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control" id="basic-default-company" name="product_name" placeholder="" required />
                                                </div>
                                            </div>

                                        
                                            
                    
                                            <div class="row mb-3">
                                                <label class="col-sm-4 col-form-label" for="basic-default-email">Product SKU</label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control" id="basic-default-company" name="product_sku" placeholder="" required />
                                                </div>
                                            </div>
                                            


                                            <div class="row mb-3">
                                                <label class="col-sm-4 col-form-label" for="basic-default-email">Product Cost</label>
                                                <div class="col-sm-8">
                                                    <div class="input-group">
                                                        <div class="input-group-addon">SAR</div>
                                                        <input type="number" class="form-control cost" id="cost_price_input"
                                                            name="product_price" placeholder="" required />
                                                    </div>
                                                </div>
                                            </div>

                                            

                                            
                                            

                                            <!-- <div class="row mb-3">
                                                <label class="col-sm-4 col-form-label" for="basic-default-email">Product Quantity</label>
                                                <div class="col-sm-8">
                                                    <input type="number" class="form-control" id="quantity_input" name="product_qty" placeholder="" required />
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-sm-4 col-form-label" for="basic-default-email">Total Price </label>
                                                <div class="col-sm-8">
                                                    <div class="input-group">
                                                        <div class="input-group-addon">SAR</div>
                                                        <input type="number" class="form-control total" id="cost_price_input"
                                                            name="total_price" placeholder="" required />
                                                    </div>
                                                </div>
                                            </div> -->


                                        

                                           <button type="submit"  style="display:flex;align-item:center;justify-content:center;width:63%;margin-left:195px;" class="btn btn-primary">Submit</button>
                                        

                                        </form>
                                    </div>
                                </div>
                                <div class="col-sm-12" style="margin-bottom: 7px;padding:0 70px 0 70px;">
                               <a href="<?php echo base_url();?>SupplierProducts/view" class="form-control btn" style="color:white;background-color:black;width:100%;" id="submit" value="Submit" > View Supplier Products </a>
                           </div>
                              
                            </div>
                            </div>
                            
                        </div>
                    </div>
                    <!-- / Content -->
                    <!-- Footer -->
                    <footer class="content-footer footer bg-footer-theme">
                        <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                        <a href="https://deftinnovations.in/" target="blank" class="mb-2 mb-md-0 hellos">
                                © Deft Innovations
                        </a>

                        </div>
                    </footer>
                    <!-- / Footer -->

                    <div class="content-backdrop fade"></div>
                </div>
                <!-- Content wrapper -->
            </div>
            <!-- / Layout page -->
        </div>

        <!-- Overlay -->
        <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->


    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

    <script>
     

        // $('#quantity_input').change(function(){
        // var product_Qty = $(this).val();
        // var product_cost = $('.cost').val();
        // console.log(product_Qty);

        // console.log(product_cost);

        // var product_total_price = product_Qty * product_cost;
        // console.log(product_total_price);

        // $('.total').val(product_total_price);


// });
// Hide the success message after 5 seconds
setTimeout(function() {
    document.getElementById('success-alert').style.display = 'none';
}, 4000);
</script>
  