<div class="layout-page">
                <!-- Navbar -->
                <div class="content-wrapper">
                    <!-- Content -->
                    <div class="container-xxl flex-grow-1 container-p-y">
                        <h4 class="py-3 mb-4"><span class="text-muted fw-light"></span>Delivery Vehicle Stock</h4>

                        <!-- Basic Layout & Basic with Icons -->
                        <div class="row">
                            <!-- Basic Layout -->
                            <div class="col-md-12">
                                <div class="card mb-4">
                                    <div class="card-header d-flex align-items-center justify-content-between">
                                        <h4 class="py-3 mb-4"><span class="text-muted fw-light">View </span>Delivery Vehicle Stock</h4>
                                    </div>
                                    <div class="card-body">
                                    <table class="table table-striped">
            <thead>
                <tr>
                <th>Id</th>
                    <th>Name</th>
                    <th>Slug</th>
                    <th>Description</th>
                    <th>Position</th>
                
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $i=1;
                
                foreach ($stock as $row): ?>
                    <tr>
                        <td><?= $i++ ?></td>
                        <td><?= $row->name ?></td>
                        <td><?= $row->slug ?></td>
                        <td><?= $row->description ?></td>
                        <td><?= $row->position ?></td>
                      
                        <td>
                    <!-- Edit button -->
                    <a href="<?= base_url('category/edit/' . $row->cid) ?>" class="btn btn-primary btn-sm">Edit</a>
                    <!-- Delete button -->
                    <a   href="<?= base_url('category/delete/' . $row->cid) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this item?')">Delete</a>
                  
                     </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xxl">

                            </div>
                        </div>
                    </div>
                    <!-- / Content -->
                    <!-- Footer -->
                    <footer class="content-footer footer bg-footer-theme">
                        <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                            <div class="mb-2 mb-md-0">
                                © Deft Innovations
                            </div>

                        </div>
                    </footer>
                    <!-- / Footer -->

                    <div class="content-backdrop fade"></div>
                </div>
                <!-- Content wrapper -->
            </div>
            <!-- / Layout page -->
        </div>

        <!-- Overlay -->
        <div class="layout-overlay layout-menu-toggle"></div>
    </div>