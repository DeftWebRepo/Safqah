
            <!-- Layout container -->
            <div class="layout-page">
                <!-- Navbar -->
                <div class="content-wrapper">
                    <!-- Content -->
                    <div class="container-xxl flex-grow-1 container-p-y">
                        <h4 class="py-3 mb-4"><span class="text-muted fw-light"></span>Delivery Vehicle Stock</h4>

                        <!-- Basic Layout & Basic with Icons -->
                        <div class="row">
                            <!-- Basic Layout -->
                            <div class="col-md-7">
                                <div class="card mb-4">
                                    <div class="card-header d-flex align-items-center justify-content-between">
                                        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Add </span>Delivery Vehicle Stock</h4>
                                    </div>
                                    <div class="card-body">
                                    <form action="<?php echo base_url();?>DeliveryVehicleStock/save" method="POST">
                                            

                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-name">Vehicle Name</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" id="basic-default-name" name="vehicle_name" required/>
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-name">Products</label>
                                                <div class="col-sm-10">
                                                    <a class="btn btn-primary" id="add_mark" style="color:white;">
                                                        <i class="menu-icon tf-icons bx bx-grid"></i>&nbsp;
                                                    Add Products</a>

                                                    <div class="vdom" style="margin-top:10px;"></div>


                                                </div>
                                            </div>

                                               <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-name">No of Stocks</label>
                                                <div class="col-sm-10">
                                                    <input type="number" class="form-control" id="basic-default-name" name="no_of_stock" required/>
                                                </div>
                                            </div>

                                                <div class="row mb-3">
                                                <label class="col-sm-2 col-form-label" for="basic-default-name">Number of items</label>
                                                <div class="col-sm-10">
                                                    <input type="number" class="form-control" id="basic-default-name" name="number_of_item" required/>
                                                </div>
                                            </div>

                                       
                                         

                                            <div class="row justify-content-end">
                                                <div class="col-sm-10">
                                                    <button type="submit" class="btn btn-primary">Save</button>
                                                </div>
                                            </div>
                                        

                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xxl">

                            </div>
                        </div>
                    </div>
                    <!-- / Content -->
                    <!-- Footer -->
                    <footer class="content-footer footer bg-footer-theme">
                        <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                            <div class="mb-2 mb-md-0">
                                © Deft Innovations
                            </div>

                        </div>
                    </footer>
                    <!-- / Footer -->

                    <div class="content-backdrop fade"></div>
                </div>
                <!-- Content wrapper -->
            </div>
            <!-- / Layout page -->
        </div>

        <!-- Overlay -->
        <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
 <script>

$(document).ready(function(){


      let subjectCount = 0;

   document.getElementById("add_mark").addEventListener("click", function(event) {


        event.preventDefault(); // Prevent the default button behavior


  subjectCount++;
  let newSubjectField = `<div class="form-group row" id="subject-${subjectCount}" style="margin-bottom:10px;">
                            <label for="Product${subjectCount}" class="col-sm-2 col-form-label">Product ${subjectCount}</label>
                            <div class="col-sm-4">
                              <input type="text" class="form-control" name="product[]" placeholder="Enter Product Name">
                            </div>
                            <label for="Count${subjectCount}" class="col-sm-2 col-form-label">No of Stock</label>
                            <div class="col-sm-4">
                              <input type="number" class="form-control" name="product_stock[]" placeholder="No of Stock">
                            </div>
                          </div>`;
  document.querySelector(".vdom").insertAdjacentHTML("beforeend", newSubjectField);
});




})


</script>